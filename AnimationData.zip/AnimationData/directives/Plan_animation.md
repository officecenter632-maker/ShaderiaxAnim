# Scénario – Starlink bridé en Ukraine

Oct 29, 2026 · @jens steine

## 0. Charte visuelle et choix de production

Le scénario dure environ 5 min 17 s, en 64 plans de 3 à 8 s (5 s en moyenne), selon les règles solides et actives du registre maître. La voix off reprend le speech mot pour mot : rien n'est ajouté, rien n'est retiré.

### Palette (familles de couleurs du registre)

| Usage | Couleur | Code |
| --- | --- | --- |
| Cartons de texte et changements de partie | Violet à traînées rose, jaune, cyan | #5A1470 (traînées #E86FA8, #F2B01E, #7FD6F0) |
| Carton de conséquence ou d'accusation | Bordeaux, vert forêt, violet nuit | #4A0A28 · #1E3A14 · #2B1030 |
| Nuit, postes de contrôle | Violet très sombre, bleu nuit | #241E45 · #2A1A55 |
| Alerte, panne, danger | Rouge vif | #D81E1E · #FF3B1F |
| Validé, argent, financement | Vert | #22B35A · #39B54A |
| Infographies, foules, cartes | Bleu clair à capsules arrondies | #66C8F7 · #8DE3FA |
| Prises de parole officielles | Gris-vert | #7F9490 |
| Étiquettes de date | Blanc, calendrier orange | #FFFFFF · #F5A623 |
| Étiquette de source (bas d'écran) | Noir et blanc | #000000 · #FFFFFF |
| Peau des personnages | Rose, saumon | #F6A98B · #E9967A |
| Écran de fin | Bleu | #1277C4 |

Chaque nouveau décor change de teinte dominante par rapport au précédent. Tout est dessiné en aplats vectoriels, sans ombre portée, avec une petite ellipse sombre sous les pieds des personnages.

### Éléments qui reviennent

- Logo de la chaîne : immobile, coin bas gauche, sur tous les plans.
- Étiquettes de contexte : date (calendrier orange) et lieu (épingle rouge) en haut à gauche, nom et fonction au-dessus du personnage, source en bas, noire et blanche.
- Cartons : capitales blanches grasses centrées, écrites mot à mot, 11 mots au plus. Bulles : blanches, texte noir en casse mixte.
- Le propriétaire du réseau : personnage générique en costume sombre, sans ressemblance, identifié par son étiquette quand il s'agit de Musk.
- L'opérateur de drone, de dos devant ses écrans : ouvre l'accroche, revient dans la conclusion.
- La télécommande : objet fil rouge de l'accroche, de la partie 5 et de la conclusion.
- Un bâtiment générique à cinq côtés pour le gouvernement américain, introduit au plan 2.5.
- Réactions d'Internet : la voix off donne les chiffres et les commentaires, l'image les traduit en foules de silhouettes anonymes et en symboles (pouces, cœurs, couronne, balance, loupe). Seule exception : le carton d'accroche du plan 1.6, prévu par la note du speech.
- Aucun logo réel (SpaceX, Starlink, X, journaux, entreprises) : des étiquettes de texte et des icônes génériques.

### Contradictions du registre : mes arbitrages pour ce scénario

- Caméra : fixe sur les cartons, interfaces et écrans partagés ; zoom lent sur les personnages et recul qui révèle le décor.
- Fondu au noir : un seul voile sombre, entre les plans 3.8 et 4.1, avant le carton « Qui a donné l'ordre ? ». Ailleurs, coupes, masques et formes qui recouvrent l'écran.
- Prises de vues réelles : aucune photo, aucune vidéo, tout est dessiné.
- Parallaxe 3D : aucune, plans 2D frontaux.

### Ce que j'ai décidé à ta place

- Ton : ironique envers le jeu de pouvoir et les conditions d'utilisation, jamais envers les soldats ni les pertes. Pas de sang.
- Attributions : ce qui vient de Musk, du Wall Street Journal, de Trump ou de Zelensky passe par une étiquette « selon… » ou « version », jamais par une citation inventée. Les bulles ne servent qu'aux paroles de personnages (plan 7.4) : aucun commentaire d'internaute, aucun compteur de votes ni aucune page de forum n'est écrit à l'écran.
- Réactions d'Internet : retirées de l'écran sur les plans 4.8, 6.1 à 6.8, 7.6 et 8.6, car elles servent à régler le ton pour plaire au plus grand nombre, pas à être montrées telles quelles. La voix off reste identique.
- Badges de crédit d'ouverture (haut droite) : emplacement prévu aux plans 1.1 et 1.2, texte à fournir par toi.
- Écran de fin de 6 s : ajouté, il n'est pas dans le speech (6 des 8 vidéos de référence en ont un). À supprimer si tu n'en veux pas.

## 1. Accroche (22 s, 6 plans)

L'accroche enchaîne cinq décors contrastés, du calme à la panne, puis tombe sur la phrase d'Internet en carton violet. Les durées incluent la transition de sortie.

Recettes : accroche\_ouverture\_enchainement (série de décors courts, texte d'alerte à l'écran), badges de crédit d'ouverture, affirmation\_carton\_phrase\_cle.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 1.1 | Imagine. Tu pilotes un drone au-dessus d'une ligne de front. | Gros plan sur l'écran d'un poste de pilotage : vue du ciel d'un drone en aplats, ligne de front en pointillés rouges. Recul qui révèle l'opérateur de dos, en camouflage, décor vert olive #6C7A4A. | Badges de crédit en haut à droite (texte à fournir) | Coupe franche, 4 s |
| 1.2 | Soudain, ta connexion ralentit. | Même poste : l'image du drone se pixellise, les barres de signal passent de quatre à une, halo rouge pulsé autour de l'écran. L'opérateur se penche, une main sur la tête. | Badge rouge arrondi « CONNEXION LENTE » ; badges de crédit encore visibles | Coupe franche, 3 s |
| 1.3 | Pas à cause de l'ennemi. | Fond bleu nuit uni #241E45. Une icône d'antenne de brouillage entre en pop, puis une grande croix rouge #D81E1E la barre. Plan fixe. | Aucun | Masque d'encre vert menthe #86DDAB (couleur du plan suivant), 3 s |
| 1.4 | À cause de l'homme qui possède le réseau. | Bureau d'angle vitré, dominante vert menthe #86DDAB. Gros plan sur une télécommande géante à un seul bouton tenue par des mains rondes, puis recul : le propriétaire du réseau, silhouette en costume sombre, assis, un satellite miniature au-dessus de lui. | Aucun | Coupe franche, 4 s |
| 1.5 | Cette semaine, il l'a reconnu. | Fond jaune doré #F9C96B. Écran de téléphone générique au centre, une publication figurée par des barres grises, un pouce rond sans doigts appuie sur « publier ». Un tampon rouge incliné frappe l'écran. | Tampon incliné « RECONNU » | Disque violet #5A1470 qui grandit et recouvre l'écran, 3 s |
| 1.6 | Et sur Internet, les gens ont résumé l'affaire en une phrase. | Carton plein écran violet #5A1470 à traînées rose, jaune et cyan, sans personnage. Texte écrit mot à mot en capitales blanches grasses. Plan fixe. | CONDITIONS D'UTILISATION : SE RENDRE SANS CONDITION À LA RUSSIE. | Masque d'encre vert forêt #1E3A14 (couleur du carton suivant), 5 s |

Le texte du carton est celui de la note du speech : c'est le seul propos d'internaute écrit à l'écran, et il sert de chute à l'accroche.

## 2. Le contexte (32 s, 6 plans)

Le contexte se dit en trois temps visuels : un réseau, trois usages militaires, puis deux versions dont l'une serait « sous contrôle américain », selon Musk. Le détail glissé au plan 2.5 est repris au plan 4.2.

Recettes : explication\_mecanisme\_etapes, enumeration\_points\_un\_par\_un, comparaison\_deux\_etats.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 2.1 | Revenons en arrière. | Carton plein écran vert forêt #1E3A14 à motifs tonaux, sans personnage. Texte écrit mot à mot en capitales blanches grasses. Plan fixe. | REVENONS EN ARRIÈRE | Coupe franche, 3 s |
| 2.2 | Depuis le début de l'invasion à grande échelle, l'Ukraine s'appuie sur Starlink, le réseau de satellites de SpaceX. | Fond crème #FBF8EA à pictogrammes discrets. Carte plate du pays en bleu #1E6BB8. Une constellation de petits satellites génériques apparaît au-dessus, reliée au pays par des lignes pointillées. Zoom avant lent. | Étiquette de lieu à épingle rouge « UKRAINE » qui glisse depuis la gauche ; étiquette blanche reliée à la constellation par une flèche : « STARLINK · RÉSEAU DE SATELLITES DE SPACEX » | Masque d'encre bleu clair #66C8F7, 7 s |
| 2.3 | Il sert aux communications, aux frappes de drones, à la défense aérienne. | Fond bleu clair #66C8F7 à capsules arrondies. Trois cartes blanches entrent l'une après l'autre (glissement puis pop, environ 1,5 s d'écart), chacune avec une icône : combiné radio, drone, radar sous bouclier. Plan fixe. | COMMUNICATIONS · FRAPPES DE DRONES · DÉFENSE AÉRIENNE (une légende par carte) | Coupe franche, 6 s |
| 2.4 | Pour les soldats, c'est un nerf de la guerre. | Tranchée en aplats ocre #C98A4B. Un soldat générique, peau rose, tenue vert olive. Un câble épais blanc-bleu, comme un nerf, relie son casque à un satellite dans le ciel et pulse lentement. Recul progressif depuis le casque. | Aucun | Coupe franche, 4 s |
| 2.5 | Il existe deux versions : Starlink, civile, et Starshield, la version militaire, que Musk affirme sous contrôle du gouvernement américain. | Écran partagé 50/50, liséré blanc qui glisse depuis le bas. Gauche, bleu ciel #A9D6EE : parabole blanche au-dessus d'une maison. Droite, vert olive #6C7A4A : parabole camouflée. À « sous contrôle », un bâtiment générique à cinq côtés glisse depuis la droite et une flèche le relie à la parabole camouflée. Caméra fixe. | « STARLINK · CIVIL » à gauche ; « STARSHIELD · MILITAIRE » à droite ; « SELON MUSK : SOUS CONTRÔLE DU GOUVERNEMENT AMÉRICAIN » | Enchaîné sans coupe sur le plan 2.6, 8 s |
| 2.6 | Garde ce détail en tête. Il va devenir très important. | Zoom avant ciblé sur l'étiquette de droite. Un cercle rouge #D81E1E se trace autour de « SOUS CONTRÔLE DU GOUVERNEMENT AMÉRICAIN » ; la moitié gauche s'efface en fondu. Plan fixe en fin de plan. | Aucun nouveau texte | Masque d'encre violet nuit #2A1A55 (couleur du plan 3.1), 4 s |

## 3. La nuit où tout ralentit (38 s, 8 plans)

La panne se raconte avec une date, une source, puis trois chiffres posés sur une même règle de vitesse graduée de 0 à 450 km/h, qui revient aux plans 3.4, 3.5 et 3.6. Les conséquences arrivent en liste, une par une.

Recettes : histoire\_contexte\_date\_lieu, document\_rapport\_cite, statistique\_chiffre\_etiquette, alerte\_menace\_echec.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 3.1 | Mi-octobre. Du jour au lendemain, des unités ukrainiennes perdent leur connexion. | Poste de commandement de nuit, violet #2A1A55. Trois opérateurs de dos sur chaises à roulettes devant un mur d'écrans. Tous les écrans passent du vert au gris, halo rouge pulsé. Recul depuis un écran. | Étiquette blanche à calendrier orange, haut gauche, qui glisse depuis la gauche : « DATE : MI-OCTOBRE » | Coupe franche, 5 s |
| 3.2 | Selon des sources du ministère ukrainien de la Défense citées par le Kyiv Post, | Vue plongeante sur un bureau turquoise #2EA89E couvert de dossiers titrés. Un dossier « MINISTÈRE DE LA DÉFENSE », un journal plié titré « KYIV POST » (texte seul, sans logo). Des mains rondes glissent de document en document, puis dézoom. | Étiquette de source noire et blanche, bas d'écran : « Kyiv Post » | Coupe franche, 5 s |
| 3.3 | … SpaceX aurait instauré pendant la nuit une limite de vitesse, sans prévenir. | Nuit bleu violet #2B1F4F, lune derrière une fenêtre. Le propriétaire du réseau, silhouette, tourne un gros cadran « VITESSE » vers la gauche à une console. Un panneau rond de limitation, sans chiffre, surgit en pop. Zoom avant lent. | « LIMITE DE VITESSE · SANS PRÉVENIR » ; mention « SELON CES SOURCES » pour garder le conditionnel | Coupe franche, 4 s |
| 3.4 | Environ 160 kilomètres par heure. | Fond bleu clair #66C8F7 à capsules. Une règle de vitesse horizontale graduée de 0 à 450. Un marqueur rouge descend depuis la droite et s'arrête net sur 160. Plan fixe. | Étiquette blanche, chiffre en gros : « ≈ 160 KM/H » ; en petit : « LIMITE SELON CES SOURCES » | Même décor, pas de coupe, 3 s |
| 3.5 | Des soldats signalent des coupures entre 72 et 161 kilomètres par heure. | Même règle. Une zone rouge translucide #D81E1E se remplit entre 72 et 161, deux repères aux bornes. Plan fixe. | « 72–161 KM/H » ; en petit : « COUPURES SIGNALÉES PAR DES SOLDATS » | Coupe franche, 5 s |
| 3.6 | Or l'Ukraine voudrait pouvoir monter à 450, pour que ses drones intercepteurs poursuivent des engins à réaction plus rapides. | Sur la règle, un marqueur vert #22B35A pop à 450 (2 s). Puis ciel de nuit #1B1738 : un petit drone intercepteur poursuit un engin à réaction plus grand, traînées horizontales, l'écart grandit. Travelling latéral. | « 450 KM/H · VISÉ PAR L'UKRAINE » ; étiquettes reliées par flèches : « DRONE INTERCEPTEUR », « ENGIN À RÉACTION » | Coupe franche, 7 s |
| 3.7 | Résultat : des missions de drones perturbées, des drones perdus, la logistique et la reconnaissance ralenties. | Fond rouge sombre #5F0000. Quatre badges rouges arrondis entrent un par un en pop (environ 1,3 s d'écart), chacun avec une icône : drone, drone barré, camion, jumelles. Plan fixe. | MISSIONS PERTURBÉES · DRONES PERDUS · LOGISTIQUE RALENTIE · RECONNAISSANCE RALENTIE (un badge par ligne) | Coupe franche, 6 s |
| 3.8 | Et ça dure plus d'une semaine. | Calendrier orange #F5A623 sur fond rouge sombre. Sept cases se barrent d'une croix rouge, une par une et de plus en plus vite, puis une huitième apparaît, barrée aussi. Le plan s'immobilise. | « PLUS D'UNE SEMAINE » | Voile sombre qui monte jusqu'au carton du plan 4.1 (seul fondu sombre du scénario), 3 s |

## 4. Qui a donné l'ordre ? (42 s, 8 plans)

Trois versions se succèdent, chacune dans son décor et sa teinte, et le plan 4.7 revient volontairement au décor du plan 4.2 pour boucler la première version. Tout ce qui est attribué à Musk reste en étiquette « version » ou « selon lui », jamais en citation inventée.

Recettes : affirmation\_carton\_phrase\_cle, exemple\_cas\_concret\_nomme, transition\_changement\_de\_partie.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 4.1 | Qui a donné l'ordre ? | Carton plein écran violet #5A1470 à traînées rose, jaune et cyan, sans personnage. Texte écrit mot à mot en capitales blanches grasses. Plan fixe. | QUI A DONNÉ L'ORDRE ? | Coupe franche, 3 s |
| 4.2 | D'abord, Musk laisse entendre qu'il n'y est pour rien : Starshield dépendrait du Pentagone. | Décor vert sauge #9BA68A. Le propriétaire du réseau, mains levées paumes ouvertes (geste « pas moi »), à côté d'une parabole camouflée. Une flèche glisse de la parabole vers le bâtiment à cinq côtés du plan 2.5. Zoom avant lent sur le personnage. | Étiquette nom et fonction au-dessus du personnage : « SPACEX » en petit, « ELON MUSK » en gras ; étiquette « PREMIÈRE VERSION : STARSHIELD DÉPENDRAIT DU PENTAGONE » | Coupe franche, 6 s |
| 4.3 | Puis le Wall Street Journal publie, en citant des responsables américains, que c'est bien lui qui a ordonné le ralentissement. | Fond bordeaux #5E0510. Un journal vu de dessus avec le titre « WALL STREET JOURNAL » (texte seul, sans logo) ; à côté, deux silhouettes en costume sans visage. Une flèche rouge relie le journal au propriétaire du réseau, qui tient la télécommande géante du plan 1.4, bouton « RALENTIR ». Gros plan sur le titre, puis recul. | « DEUXIÈME VERSION : C'EST LUI, SELON LE WALL STREET JOURNAL » ; étiquette de source noire et blanche en bas : « Wall Street Journal » | Coupe franche, 7 s |
| 4.4 | Quelques jours plus tard, sur X, il l'admet : oui, SpaceX a bridé le service. | Fond orange #F28C3A. Un écran de téléphone générique avec une publication figurée par des barres. Un tampon rouge incliné « BRIDAGE CONFIRMÉ » frappe l'écran. Le propriétaire, au fond, hausse les épaules. Caméra fixe. | Étiquette blanche à calendrier orange : « QUELQUES JOURS PLUS TARD » ; étiquette « SUR X » ; « TROISIÈME VERSION : IL ADMET LE BRIDAGE » | Coupe franche, 6 s |
| 4.5 | Son argument : l'armée ukrainienne aurait violé les conditions d'utilisation en employant un service civil pour des frappes offensives. | Fond crème #FBF8EA à pictogrammes discrets. Vue du dessus : un contrat « CONDITIONS D'UTILISATION » au centre, une carte « SERVICE CIVIL » avec une parabole bleue, une flèche vers une carte « FRAPPES OFFENSIVES » avec un drone. Un badge rouge arrondi « VIOLATION, SELON LUI » se pose. Zoom avant ciblé sur la seconde carte. | « SON ARGUMENT : CONDITIONS D'UTILISATION VIOLÉES, SELON LUI » | Coupe franche, 7 s |
| 4.6 | Selon lui, une faille a été fermée. | Fenêtre logicielle à trois pastilles rouge, jaune, verte, fond bleu nuit #1B2A55, titre « CORRECTIF », contenu figuré en barres. Une barre rouge « faille » se barre et se remplace par une barre verte, coche verte à droite. Plan fixe. | « SELON LUI : FAILLE FERMÉE » | Coupe franche, 4 s |
| 4.7 | Il ajoute que les changements sur Starshield relevaient du gouvernement américain. | Retour au décor vert sauge #9BA68A du plan 4.2, même cadrage (écho voulu). Le propriétaire de profil, mains levées. La flèche va de la parabole camouflée au bâtiment à cinq côtés. | « STARSHIELD : DÉCISION DU GOUVERNEMENT AMÉRICAIN, SELON LUI » | Coupe franche, 5 s |
| 4.8 | Voilà sa version. Maintenant, regarde comment Internet l'a reçue. | Les trois étiquettes « PREMIÈRE VERSION », « DEUXIÈME VERSION », « TROISIÈME VERSION » s'empilent. Derrière, sur fond bleu clair #66C8F7, une vague de silhouettes anonymes en aplats, de dos, monte depuis le bas de l'écran et lève la tête vers la pile. Zoom avant lent sur la foule. | « SA VERSION » sur la pile | Masque d'encre vert forêt #1E3A14 (couleur du plan 5.1), 4 s |

Le plan 4.8 annonce la réaction d'Internet par une foule qui lève la tête, sans écran de forum. Le verdict détaillé arrive en partie 6, comme dans le speech.

## 5. Rétabli, vraiment ? (37 s, 7 plans)

Deux versions contradictoires s'opposent en écran partagé, une troisième tranche, puis le brouillard diplomatique se referme sur une phrase en carton. Les prises de parole officielles gardent le décor gris-vert du registre.

Recettes : comparaison\_deux\_etats, citation\_bulle\_acteur (version étiquettes, sans bulle), alerte\_menace\_echec, affirmation\_carton\_phrase\_cle.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 5.1 | Et le service est-il revenu à la normale ? Là encore, les versions divergent. | Carton plein écran vert forêt #1E3A14 à motifs tonaux, texte écrit mot à mot. À « les versions divergent », un liséré blanc vertical glisse depuis le bas et fend le carton en deux. Plan fixe. | REVENU À LA NORMALE ? | Le carton éclate en deux moitiés, 5 s |
| 5.2 | Donald Trump avait assuré que tout fonctionnait à pleine vitesse, | Écran partagé 50/50. Moitié gauche : salle de presse gris-vert #7F9490, un personnage en costume derrière un pupitre et une rangée de micros, une jauge pleine derrière lui. Moitié droite vide, bleu nuit, en attente. Plan fixe. | Étiquette nom et fonction : « AVAIT ASSURÉ » en petit, « DONALD TRUMP » en gras ; pastille verte arrondie avec coche « TOUT FONCTIONNE » | Même écran, la moitié droite s'anime ensuite, 4 s |
| 5.3 | … alors qu'un responsable ukrainien affirmait au Kyiv Independent que les restrictions restaient en place. | Moitié droite : poste de contrôle bleu nuit #232B4A. Un responsable générique sans visage détaillé, devant un écran aux barres de signal rouges. Une pastille rouge arrondie se pose. Écran partagé complet, caméra fixe. | Étiquette « RESPONSABLE UKRAINIEN » ; pastille « RESTRICTIONS EN PLACE » ; étiquette de source noire et blanche en bas : « Kyiv Independent » | Coupe franche, 5 s |
| 5.4 | Ensuite, le président Zelensky a annoncé que les vitesses étaient revenues à leur niveau d'avant. | Salle de presse gris-vert #7F9490 : un personnage en tenue sobre derrière un pupitre et des micros. Derrière lui, une barre de vitesse remonte jusqu'à un repère « AVANT », sans chiffre. Zoom avant sur le personnage, puis recul qui révèle les micros. | Étiquette nom et fonction : « PRÉSIDENT » en petit, « ZELENSKY » en gras ; pastille verte « VITESSES RÉTABLIES, SELON ZELENSKY » | Coupe franche, 6 s |
| 5.5 | Le tout se joue en pleine reprise diplomatique : la Russie a accepté de relancer des négociations à trois avec Washington et Kyiv le mois prochain. | Table de négociation ronde vue du dessus, fond bleu clair #8DE3FA. Trois jetons ronds étiquetés glissent chacun depuis un bord jusqu'à leur place, reliés par des flèches en triangle. Dézoom lent. | Étiquette blanche à calendrier orange : « LE MOIS PROCHAIN » ; jetons « RUSSIE », « WASHINGTON », « KYIV » ; « NÉGOCIATIONS À TROIS » | Fondu enchaîné, 8 s |
| 5.6 | Dans ce brouillard, une chose est sûre : | Les trois jetons s'enfoncent dans un brouillard gris #B8BEC4 fait de lobes arrondis. Seule reste visible, au centre, la carte plate de l'Ukraine du plan 2.2. Zoom avant lent. | Aucun | Fondu enchaîné, 3 s |
| 5.7 | … l'Ukraine vient de mesurer à quel point son réseau dépend d'une décision qu'elle ne contrôle pas. | Carton plein écran bordeaux #4A0A28. Dans un coin, un petit câble tiré depuis la carte de l'Ukraine vers un bouton hors cadre : la télécommande de l'accroche, hors de portée. Texte écrit mot à mot. | UNE DÉCISION QU'ELLE NE CONTRÔLE PAS | Masque d'encre bleu clair #66C8F7 (couleur du plan 6.1), 6 s |

## 6. Le verdict d'Internet (46 s, 9 plans)

Les chiffres et les commentaires du forum sont seulement dits par la voix off. À l'écran, ils deviennent des foules anonymes et des symboles : pouces, couronne, balance, contrat qui devient drapeau blanc, loupe. Les trois idées sont numérotées 1, 2, 3, et la partie se ferme sur un carton qui rappelle que ce sont des opinions, pas des faits établis.

Recettes : enumeration\_points\_un\_par\_un, affirmation\_carton\_phrase\_cle, foules en silhouettes (règle casting.foule\_silhouette\_premier\_plan).

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 6.1 | Sur un grand forum d'actualité en ligne, quatre discussions sur cette affaire ont dépassé 25 000 votes. | Fond bleu clair #66C8F7 à capsules. Vue du dessus d'une grande foule de silhouettes anonymes en aplats, répartie en quatre groupes. Les quatre groupes s'allument un par un avec un rebond, halo jaune doré #F9C96B ; des icônes de pouce et de bulle vide flottent au-dessus de chacun. Aucun chiffre, aucun nom de site. Plan fixe. | Aucun | Coupe franche, 6 s |
| 6.2 | La plus populaire : plus de 51 000 votes et plus de 8 000 commentaires. | L'un des quatre groupes grossit et occupe l'écran : la foule s'épaissit, des pouces levés et des bulles vides montent en grand nombre au-dessus d'elle, puis se stabilisent. Aucun compteur. Zoom avant ciblé sur le groupe. | Aucun | Coupe franche, 5 s |
| 6.3 | Trois idées reviennent. | Fond violet #4F1C80. Trois cases blanches numérotées entrent en pop l'une après l'autre (environ 0,8 s d'écart). Plan fixe. | « 1 », « 2 », « 3 » | Coupe franche, 3 s |
| 6.4 | Un : le pouvoir. Le commentaire le plus voté, plus de 20 000 votes, | Fond turquoise #3FD6B5. Légende « 1 · LE POUVOIR » avec une icône de couronne. Une petite silhouette seule porte une immense couronne et tient un levier géant, face à une foule minuscule qui la regarde. Plan fixe. | Légende « 1 · LE POUVOIR » | Coupe franche, 5 s |
| 6.5 | … dit simplement qu'une entreprise ou un individu ne devrait jamais avoir autant de pouvoir. | Même décor. Une balance géante : sur un plateau, la silhouette couronnée au levier ; sur l'autre, la foule entière, soulevée par le déséquilibre. Une bulle blanche sans texte, avec un point d'exclamation, gonfle en pop au-dessus de la foule. Zoom avant lent sur la balance. | « TROP DE POUVOIR » | Masque d'encre violet #8E5BD0 (couleur du plan 6.6), 5 s |
| 6.6 | Deux : l'ironie. Quand l'argument des conditions d'utilisation circule, | Fond violet #8E5BD0. Légende « 2 · L'IRONIE » avec une icône de masque comique. Le contrat « CONDITIONS D'UTILISATION » du plan 4.5 passe de silhouette en silhouette dans la foule, de gauche à droite ; chacune le lit puis lève les yeux au ciel. Plan fixe. | Légende « 2 · L'IRONIE » | Coupe franche, 4 s |
| 6.7 | … un internaute résume : les conditions d'utilisation, c'est se rendre à la Russie. Plus de 1 700 votes. | Le contrat « CONDITIONS D'UTILISATION » grossit au centre devant la foule, se plie en drapeau blanc et se hisse sur un mât ; la foule rit. Au pied du mât, une étiquette de texte sans drapeau réel. Zoom avant lent. | « CONDITIONS D'UTILISATION » sur le contrat ; « RUSSIE » au pied du mât | Coupe franche, 6 s |
| 6.8 | Trois : le soupçon. Beaucoup accusent Musk et Washington de faire le jeu de Moscou. | Fond rouge sombre #3D0A0E. Légende « 3 · LE SOUPÇON » avec une loupe. Trois étiquettes « MUSK », « WASHINGTON », « MOSCOU » reliées par des flèches en pointillés marquées d'un point d'interrogation. Au premier plan, des silhouettes anonymes de dos les regardent avec des loupes. Plan fixe. | Légende « 3 · LE SOUPÇON » ; bandeau blanc incliné « ACCUSATION D'INTERNAUTES » | Coupe franche, 5 s |
| 6.9 | Ce sont des opinions, pas des faits établis, et aucune des sources de cette vidéo ne le démontre. | Carton plein écran violet nuit #2B1030, sans personnage. Texte écrit mot à mot en capitales blanches grasses, avec une seconde ligne plus petite. Plan fixe. | DES OPINIONS, PAS DES FAITS ÉTABLIS ; en dessous : AUCUNE DES SOURCES DE CETTE VIDÉO NE LE DÉMONTRE | Masque d'encre bleu #2A74BF (couleur du plan 7.1), 7 s |

## 7. Les gouvernements s'en mêlent (32 s, 7 plans)

La position allemande se déroule dans un seul décor de prise de parole officielle, puis le débat bascule du cas Musk à une question de principe, posée en carton.

Recettes : citation\_bulle\_acteur, exemple\_cas\_concret\_nomme, affirmation\_carton\_phrase\_cle.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 7.1 | Les gouvernements aussi ont réagi. | Mur à panneaux moulurés, arches et rideaux drapés, teinté bleu #2A74BF. Trois silhouettes en costume, de dos, se tournent d'un même geste ; des points d'exclamation surgissent en pop. Plan fixe. | Aucun | Coupe franche, 3 s |
| 7.2 | L'Allemagne exige que les restrictions soient levées : | Salle de presse gris-vert #7F9490 : pupitre et rangée de micros. Un grand cadenas marqué « RESTRICTIONS » s'ouvre. Plan fixe. | Étiquette de lieu à épingle rouge, qui glisse depuis la gauche : « ALLEMAGNE » ; « EXIGE : LEVER LES RESTRICTIONS » | Même décor, pas de coupe, 4 s |
| 7.3 | … son ministre des Affaires étrangères, Johann Wadephul, rappelle que Berlin finance une partie de l'équipement. | Même salle. Un personnage en costume au pupitre. À droite, une pile de caisses « ÉQUIPEMENT » où tombent des billets verts #39B54A depuis un panneau « BERLIN ». Zoom avant lent sur le personnage, puis recul sur la pile. | Étiquette nom et fonction : « MINISTRE DES AFFAIRES ÉTRANGÈRES (ALLEMAGNE) » en petit, « JOHANN WADEPHUL » en gras ; « BERLIN FINANCE UNE PARTIE DE L'ÉQUIPEMENT » | Coupe franche, 6 s |
| 7.4 | En substance : si nous payons, ça doit fonctionner. | Même salle. Une bulle blanche gonfle au-dessus du pupitre. Plan fixe. | Bulle, casse mixte : « Si nous payons, ça doit fonctionner. » ; bandeau blanc incliné « EN SUBSTANCE » (reformulation, pas une citation) | Coupe franche, 4 s |
| 7.5 | Il reconnaît pourtant ne pas connaître toute l'histoire. | Gros plan sur le ministre, une main sur la tête. Derrière lui, un puzzle auquel manquent des pièces, un point d'interrogation en pop. Fond gris-vert #7F9490. | « IL NE CONNAÎT PAS TOUTE L'HISTOIRE » | Masque d'encre bleu clair #66C8F7 (couleur du plan 7.6), 4 s |
| 7.6 | Et là, le débat change de nature. Beaucoup d'internautes ne parlent plus de Musk, | Fond bleu clair #66C8F7 à capsules. Une foule de silhouettes anonymes regarde d'abord la petite silhouette du propriétaire du réseau, puis toutes se tournent d'un même geste : la silhouette rétrécit jusqu'à disparaître et un grand point d'interrogation en pop prend sa place au-dessus d'une caisse de matériel militaire. Plan fixe. | Aucun | Coupe franche, 5 s |
| 7.7 | … mais d'une question plus large : que vaut un équipement militaire qu'on peut ralentir à distance ? | Carton plein écran violet #5A1470 à traînées rose, jaune et cyan. Question écrite mot à mot en capitales blanches grasses. Plan fixe. | QUE VAUT UN ÉQUIPEMENT MILITAIRE QU'ON PEUT RALENTIR À DISTANCE ? | Masque d'encre bleu roi #3355B8 (couleur du plan 8.1), 6 s |

## 8. La réponse (33 s, 6 plans)

La réponse se montre en une signature, trois briques que l'Ukraine voudrait posséder, un rappel que tout reste à construire, puis la réaction d'Internet, en foule et en cœurs. Aucune coche verte : ce n'est qu'une lettre d'intention.

Recettes : exemple\_cas\_concret\_nomme, enumeration\_points\_un\_par\_un, affirmation\_carton\_phrase\_cle, foules en silhouettes.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 8.1 | Alors, que faire ? | Carton plein écran bleu roi #3355B8 à formes liquides ondulantes, sans personnage. Texte écrit mot à mot en capitales blanches grasses. Plan fixe. | ALORS, QUE FAIRE ? | Masque d'encre bleu glacier #A9EEE6 (couleur du plan 8.2), 3 s |
| 8.2 | Le 22 octobre, deux entreprises finlandaises, Nokia et ICEYE, signent avec le ministère ukrainien de la Défense une lettre d'intention | Vue du dessus d'une table, fond bleu glacier #A9EEE6. Un document « LETTRE D'INTENTION » au centre ; trois mains rondes signent, chacune devant une carte de texte posée sur la table (sans logo). Dézoom lent. | Étiquette blanche à calendrier orange : « DATE : 22 OCTOBRE » ; cartes « NOKIA », « ICEYE », « MINISTÈRE UKRAINIEN DE LA DÉFENSE » | Coupe franche, 7 s |
| 8.3 | … pour développer un système de communication par satellite propre à l'Ukraine. | Retour à la carte plate de l'Ukraine du plan 2.2, fond crème #FBF8EA. Cette fois, un satellite relié au pays par un fil plein, non plus par des pointillés. Zoom avant lent. | Étiquette blanche : « SYSTÈME PROPRE À L'UKRAINE » | Coupe franche, 5 s |
| 8.4 | L'idée : que le pays possède ses satellites, ses stations au sol et ses terminaux, pour ne plus dépendre des aléas d'un gouvernement étranger. | Fond bleu clair #66C8F7 à capsules. Trois cartes blanches entrent l'une après l'autre (environ 1,5 s d'écart) avec une icône : satellite, antenne au sol, terminal. Puis le câble qui relie l'Ukraine à la télécommande hors cadre (accroche) se tend et des ciseaux le coupent. Plan fixe, puis zoom sur le câble. | « SATELLITES » · « STATIONS AU SOL » · « TERMINAUX » (une carte chacun) ; « NE PLUS DÉPENDRE DES ALÉAS D'UN GOUVERNEMENT ÉTRANGER » | Coupe franche, 8 s |
| 8.5 | Pour l'instant, ce n'est qu'une lettre d'intention, et ce sera long. | Fond ocre #DDB07A. La feuille « LETTRE D'INTENTION » posée au pied d'un très long chemin en pointillés qui monte vers un satellite minuscule. Un petit sablier. Zoom arrière lent qui révèle la longueur du chemin. | « SEULEMENT UNE LETTRE D'INTENTION » | Coupe franche, 4 s |
| 8.6 | Mais sous l'annonce, le commentaire le plus populaire tient en trois mots : merci la Finlande. | Fond bleu #A9D6EE. Une carte « ANNONCE » en haut ; en dessous, une foule de silhouettes anonymes lève les bras, et des cœurs rouges montent en pop de la foule vers l'annonce, de plus en plus nombreux. Zoom avant lent sur la foule. | Étiquette « ANNONCE » | Coupe franche, 6 s |

## 9. Conclusion et écran de fin (35 s, 7 plans)

La conclusion revient à l'opérateur de l'accroche, pose sa question en trois panneaux dont le dernier montre la télécommande, puis ferme sur un écran de fin fixe de 6 s.

Recettes : conclusion\_bilan\_et\_chute, enumeration\_points\_un\_par\_un, affirmation\_carton\_phrase\_cle, fin\_renvoi\_autre\_video.

| Plan | Voix off | Visuel et caméra | Texte à l'écran | Transition et durée |
| --- | --- | --- | --- | --- |
| 9.1 | Au fond, cette histoire pose une question simple. | Retour au poste de pilotage du plan 1.1, décor vert olive #6C7A4A, un peu assombri. L'écran est redevenu net, l'opérateur est immobile. Recul lent. | Aucun | Coupe franche, 4 s |
| 9.2 | Quand un pays dépend d'un réseau privé pour se défendre, qui décide vraiment : | Fond bleu nuit #1B1738. Un disque « PAYS » relié par un câble à une grosse constellation de satellites. Un grand point d'interrogation rouge #D81E1E pulse au-dessus. Zoom arrière lent. | Étiquettes « PAYS » et « RÉSEAU PRIVÉ » ; « QUI DÉCIDE VRAIMENT ? » | Coupe franche, 5 s |
| 9.3 | … l'État, l'entreprise, ou celui qui tient la télécommande ? | Trois panneaux verticaux entrent l'un après l'autre (glissement, environ 1,2 s d'écart). Violet #5A1470 : le bâtiment à cinq côtés. Bleu #1E6BB8 : une tour de bureaux. Rouge sombre #5F0000 : une main ronde dans l'ombre tenant la télécommande géante de l'accroche. Zoom avant ciblé sur le troisième panneau, qui remplit l'écran. | « L'ÉTAT » · « L'ENTREPRISE » · « CELUI QUI TIENT LA TÉLÉCOMMANDE » (une légende par panneau) | Coupe franche, 5 s |
| 9.4 | Les faits restent en partie flous : qui a décidé quoi, et pourquoi ? | Brouillard gris #B8BEC4 du plan 5.6. Un dossier « ORDRE » dont des lignes sont noircies. Trois points d'interrogation entrent un par un, environ 1 s d'écart. Plan fixe. | « QUI ? » · « QUOI ? » · « POURQUOI ? » | Coupe franche, 5 s |
| 9.5 | Et toi, tu en penses quoi ? Dis-le en commentaire. | Carton plein écran violet #5A1470 à traînées rose, jaune et cyan. Texte écrit mot à mot ; une icône de bulle de commentaires gonfle en pop, un curseur clignote. Plan fixe. | ET TOI, TU EN PENSES QUOI ? | Masque d'encre bleu #1277C4 (couleur du plan 9.6), 4 s |
| 9.6 | Et si cette vidéo t'a appris quelque chose, un like aide plus que tu ne le crois. | Fond bleu #1277C4. Un pouce rond sans doigts gonfle en pop avec un rebond, puis un compteur « +1 » monte. Plan fixe. | « +1 » | Bandes horizontales bleues (effet glitch) qui envahissent l'image jusqu'à l'écran de fin, 6 s |
| 9.7 | Aucune voix off | Écran de fin : fond bleu uni en dégradé #0A97CE vers #0CD4F3, immobile. Zone centrale vide pour la miniature d'une autre vidéo. Logo de la chaîne en bas à gauche. Plan fixe. | Invitation en capitales blanches grasses : titre de la vidéo suivante, à fournir | Fin de la vidéo, 6 s |

## Annexes

### A. Contrôles effectués

- Voix off : les mots des 63 plans parlés sont identiques au speech. Aucun ajout, aucun retrait.
- Durées : chaque section correspond à la somme de ses plans. Total : 317 s, soit 5 min 17 s, en 64 plans de 3 à 8 s.
- Débit : environ 144 mots par minute en moyenne (hors écran de fin), confortable à l'oral.

| Partie | Plans | Durée |
| --- | --- | --- |
| 1. Accroche | 6 | 22 s |
| 2. Le contexte | 6 | 32 s |
| 3. La nuit où tout ralentit | 8 | 38 s |
| 4. Qui a donné l'ordre ? | 8 | 42 s |
| 5. Rétabli, vraiment ? | 7 | 37 s |
| 6. Le verdict d'Internet | 9 | 46 s |
| 7. Les gouvernements s'en mêlent | 7 | 32 s |
| 8. La réponse | 6 | 33 s |
| 9. Conclusion et écran de fin | 7 | 35 s |
| **Total** | **64** | **317 s** |

### B. Décisions prises

1. **Réactions d'Internet.** Plus aucun compteur de votes, aucune bulle de commentaire ni aucune page de forum à l'écran (plans 4.8, 6.1 à 6.8, 7.6, 8.6). La voix off garde tous les chiffres et toutes les citations. À l'image : foules anonymes, pouces, cœurs, couronne, balance, contrat qui devient drapeau blanc, loupe. Le seul propos d'internaute écrit est le carton d'accroche du plan 1.6, voulu par la note du speech.
2. **Raccord 4.8 vers 5.1.** Le speech est gardé tel quel. Le plan 4.8 montre une foule qui lève la tête vers les trois versions, sans promettre un forum, et la partie 5 enchaîne. Le verdict d'Internet arrive en partie 6, comme dans le speech.
3. **Plans serrés 3.3 et 5.5.** Ils sont les plus rapides (environ 180 et 188 mots par minute contre 144 en moyenne). Je les garde tels quels : le total reste à 5 min 17 s. Si la voix est posée, ajouter 1 s à chacun donne 5 min 19 s.
4. **Fondus enchaînés des plans 5.5 et 5.6, et fondu du plan 2.6.** Gardés pour l'effet de brouillard. Le seul fondu au noir reste celui entre 3.8 et 4.1.
5. **Personnes réelles (Musk, Trump, Zelensky, Wadephul).** Personnages génériques sans ressemblance, identifiés seulement par leur étiquette.
6. **Écran de fin de 6 s.** Gardé. Sans lui, la vidéo dure 5 min 11 s.

### C. À fournir de ton côté

- Le texte des badges de crédit d'ouverture (plans 1.1 et 1.2).
- Le titre de la vidéo suivante, pour l'écran de fin (plan 9.7).

### D. Rappel sur les faits

Les événements d'octobre 2026 du speech (Kyiv Post, Wall Street Journal, déclarations, lettre d'intention du 22 octobre, chiffres du forum) sont repris tels quels : je ne les ai pas recoupés avec des sources.
