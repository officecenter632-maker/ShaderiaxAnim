# Procédure de création des assets de l'animation

## Principe

L'animation est faite d'**assets** : décors, personnages, objets, icônes. On ne les dessine pas de zéro. Pour chaque asset :

1. on trouve dans la bibliothèque d'images de **Lexiax** une image de **référence** proche (même sujet, même forme, même composition) ;
2. une IA générative **transforme** cette référence en l'asset exact voulu.

Pour économiser les fichiers à générer, on distingue deux sortes d'assets :

- **Les éléments clés** (grands, importants, récurrents) : chacun a **sa propre génération**, avec sa propre image de référence et son propre prompt.
- **Les petits éléments** (un panier, une petite icône, un objet qui n'occupe pas beaucoup d'espace) : on les **regroupe dans une même génération**. Une seule image est générée avec plusieurs éléments dedans, mais on fournit **une image de référence par élément**, pour que chaque élément garde sa propre inspiration et que la créativité ne soit pas diluée.

Cette procédure prépare tout ce dont l'IA générative a besoin : des images de référence et des prompts, organisés par génération. Une fois les images générées, elle se termine par la **collecte** de toutes les images finales dans un seul dossier, avec des noms sans ambiguïté (étape 5).

**Règle d'or : la collecte se fait en UNE SEULE PASSE.** Lexiax est lancé **une seule fois** pour **tous** les assets (éléments clés et petits éléments). Le résultat est **un seul zip** qui contient déjà toutes les images candidates, rangées par asset puis par mot. Le tri (étape 3) se fait ensuite dans ce zip, sans retourner dans Lexiax. On ne relance jamais Lexiax asset par asset.

**Règle absolue : aucun travail manuel pour moi.** Tu fais **tout** toi-même et tu **automatises** tout ce qui peut l'être. Je ne copie, ne déplace, ne renomme et ne range **aucun fichier** à la main ; je ne crée aucun dossier ; je ne remplis aucun champ ; je ne lance **jamais** un outil auxiliaire. Quand une étape a besoin d'un fichier (documentation du logiciel, liste, manifeste, archive…), **c'est le script qui le produit ou le trouve**. Mon seul geste autorisé : **lancer le script** que tu m'as livré depuis mon éditeur, et te dire que c'est fait. Si tu ne vois aucun moyen d'éviter un geste manuel, tu me le dis **avant** de me le demander, en une phrase, avec la raison. Avant chaque livraison, tu te demandes : « est-ce que je lui demande de faire quelque chose à la main ? » ; si oui, tu corriges ton script ou ta méthode, **tu ne me renvoies pas le travail**.

**Règle absolue pour TOUS les envois sur Git : le script fait tout.** Chaque envoi (références Lexiax, `assetsBrute1.zip`, `Storyboard.zip`, assets d'animation, `AnimationData.zip`, et tout nouvel envoi après une correction) est fait **par le script que tu m'as écrit**, du début à la fin : il **sélectionne** les fichiers, **contrôle** la structure, **crée le zip**, puis **le pousse lui-même** sur GitHub avec la méthode du modèle `envoyer_storyboard.py` (dépôt neuf, un seul commit, push forcé, vérification de la branche distante, jeton jamais affiché) et **affiche le résultat et le lien direct**. Cette méthode d'envoi est **recopiée telle quelle dans chaque script** ; tu ne la réécris pas. **Je ne glisse aucun zip dans Lexiax, je ne clique sur aucun bouton « Push sur GitHub », je ne tape aucune commande `git`, je ne crée aucun dépôt ni dossier à la main.** Si un dépôt n'existe pas encore, c'est le script qui s'en charge quand c'est possible ; si ce n'est pas possible (identifiants), tu me le dis **avant** de livrer le script, en une phrase, et tu m'indiques la seule chose nécessaire. Après un échec ou une correction, je **relance le même script** : il repousse tout seul. Je te dis seulement que c'est fait.

**Qui fait quoi**

| Acteur | Rôle |
| --- | --- |
| Moi | Je lance Lexiax **une fois**, j'exécute **un** script sur mon ordinateur, qui crée le zip **et l'envoie lui-même sur GitHub** (aucun clic), et je te signale que c'est fait. Plus tard, une fois les images générées et rangées dans chaque dossier, je t'envoie l'**arborescence réelle** de mon dossier `Assets` (chemin complet inclus) et je lance le script de collecte depuis mon éditeur. Ce script de collecte **pousse lui-même `assetsBrute1.zip` sur GitHub** ; je te signale que c'est fait. Quand le Storyboard est livré et que je veux générer les plans avec ImGen, je t'envoie l'**arborescence réelle** de `Storyboard` et de `Assets` (chemin complet inclus), et le **lien du dépôt GitHub** qui contient le zip des assets (étape 8). Quand les 64 plans sont générés, je t'envoie l'**arborescence réelle** du projet actuel (chemin complet inclus) ; tu m'écris un script `envoyer_storyboard.py` qui sélectionne seulement le storyboard (les plans), le zippe en `Storyboard.zip` et le pousse dans le dépôt `Storyboard` (distinct de `ImageReferenceData`) ; je le lance depuis mon éditeur et je te le signale (étape 9). Quand les images d'assets d'animation sont générées avec ImGen, je t'envoie l'**arborescence réelle** du dossier qui les contient (chemin complet inclus), je lance le script d'envoi depuis mon éditeur et je te le signale (étape 11). Quand tous les assets d'animation sont vectorisés (étape 12), je te donne l'**arborescence réelle** du projet (chemin complet inclus) et mes décisions sur les points à trancher, je lance le script d'envoi depuis mon éditeur et je te le signale (étape 13). Avant d'animer, je te donne l'**arborescence réelle** du projet et mes décisions de langue et de voix ; je lance le script `ecraser_speeches.py` depuis mon éditeur, puis je colle `projet_audiogen.json` dans AudioGen, qui génère la voix off de chaque plan (étape 13 bis) ; **je relance ensuite `envoyer_animation.py` pour que l'audio de chaque plan parte dans `AnimationData.zip`**. Ensuite l'animation se fait **directement en web, dans la conversation** : tu me montres chaque plan en page web, je le regarde et je te dis « ça marche » ou ce qui est faux (étape 14). |
| Toi (l'IA) | Tu listes et classes les assets **et tu m'envoies cette liste dans un fichier `Liste_assets.md`**, tu choisis les mots **pour tous les assets d'un coup**, tu écris **un seul** script, tu **télécharges le zip depuis GitHub et tu vérifies qu'il correspond à la recherche**, tu tries les images, tu écris les prompts, tu construis l'archive **par lots, en me livrant chaque lot au fur et à mesure** (le lot 1 avec l'outil `copier_assets.pyw`), puis, à partir de mon arborescence, tu m'écris le **script Python de collecte** des images générées, avec les chemins réels de mon arborescence. Enfin tu **télécharges `assetsBrute1.zip` au lien de l'étape 6 et tu contrôles les images générées**. Ensuite tu découpes le scénario en séquences, tu crées le dossier `Storyboard` et tu rédiges le prompt de chaque plan (étape 7). Enfin, à partir de mes arborescences et du lien du dépôt, tu écris le **fichier projet JSON d'ImGen** (`projet_imgen.json`) avec les noms de fichiers, les chemins, les images de référence et les liens GitHub réels, tous vérifiés (étape 8). Enfin, à partir de mon arborescence, tu écris le **script d'envoi** `envoyer_storyboard.py` ; puis, `Storyboard.zip` poussé, tu le télécharges, tu **parcours les 64 plans pour décider l'ajustement technique de chaque asset** et tu me livres le **registre** (`Registre_elements_animation.md`) ; tu le livres puis tu **enchaînes aussitôt, sans attendre ma validation**, en visualisant **chaque plan, un par un**, tu anticipes ce qui est dynamique ou statique, et tu livres, par lots, l'**archive de prompts** (`animation_lot_NN.zip` : un dossier par plan, un JSON par nouvelle génération seulement, avec l'image du plan source en référence sur GitHub) et la **liste détaillée** (`Liste_assets_animation.md`) (étape 9). Quand le contrôle du storyboard trouve des images à regénérer, tu me livres directement, dans la même réponse, **`reinitialisation_imgen.html`** : une page avec une zone de copie (et un bouton « Copier ») par vague de JSON de réinitialisation pour ImGen (étape 9). Enfin, à partir de cette arborescence, tu m'écris le **script d'envoi** vers le dépôt `Assets_Animation`, puis tu télécharges le zip et tu fais le **checkup** des images pour repérer celles qui ont une génération grave (étape 11). Enfin, tu m'écris le **script d'envoi** `envoyer_animation.py` qui pousse `AnimationData.zip` (SVG, directives, storyboard, scénario, `README.md`) dans le dépôt `ShaderiaxAnim` ; tu le télécharges et tu contrôles qu'il contient tout ce qu'il faut pour animer chaque plan (étape 13). Avant l'animation, tu **clones le dépôt `Storyboard`**, tu **traduis en anglais et tu balises les `speech.txt`** (un speech par plan), puis tu me livres `Speech_audio.zip`, le script `ecraser_speeches.py` et `projet_audiogen.json` pour AudioGen (étape 13 bis) ; une fois l'audio généré, tu contrôles qu'il est dans `AnimationData.zip` (`audio/`). **Dans l'animation, tu intègres l'audio de chaque plan directement dans son HTML (étape 14).** Enfin tu **animes chaque plan directement en web** et tu me montres le rendu dans la conversation, une page par plan, que tu as regardée toi-même avant de me la livrer (étape 14). |
| Lexiax | Il contient la bibliothèque d'images de référence, fabrique le zip d'images ; **l'envoi sur GitHub est fait par le script**, jamais par le bouton « Push sur GitHub » ni par glisser-déposer. |

## Erreurs de méthode à ne jamais refaire

Cette zone liste **les erreurs de méthode** (dépôts, fichiers, communication), distinctes des erreurs d'animation, qui sont dans `Registre_exigences_animation.md`, partie A. **Tu la relis avant chaque étape qui touche un dépôt ou un fichier.** Une erreur de méthode qui revient ne crée pas une nouvelle ligne : on ajoute une ★ et on complète « Signalée ». Chaque nouvelle erreur de méthode que je te signale est ajoutée ici par toi, **dans la même réponse**, une ligne par sujet.

| Priorité | Erreur vue | Règle + contrôle avant de répondre | Signalée |
| --- | --- | --- | --- |
| ★★★ | Un dépôt répond 404 ; tu conclus qu'il n'existe pas, puis tu prends un autre dépôt (l'ancien) qui n'a pas les bons fichiers | **Un 404 ne prouve rien** : le dépôt peut être privé ou porter un autre nom. Avant de conclure, tu testes les trois accès : `git ls-remote`, la page du dépôt et le lien direct du zip, et tu cites les codes obtenus. Si les trois échouent, tu t'arrêtes et tu me demandes **le lien exact, en une phrase**. **Tu ne remplaces jamais un dépôt par un autre** (même « l'ancien ») et tu n'avances pas sur un substitut sans me le dire **avant** d'agir. **Le dépôt de l'archive d'animation est `ShaderiaxAnim`** (`https://github.com/officecenter632-maker/ShaderiaxAnim`, `AnimationData.zip` à la racine) : si un nom de dépôt de ce document échoue, tu me demandes le bon lien tout de suite | Étape 14 ×3 |
| ★★ | Tu avances avec des données incomplètes sans t'en rendre compte (les `.webp` de `Assets_Animation` au lieu des SVG) | À la première ouverture d'un dépôt ou d'un zip, tu vérifies qu'il contient **le type de fichier attendu** (pour l'animation : les `.svg` de chaque plan, le `manifest.json`, `directives/`). S'il manque, c'est probablement le mauvais dépôt : tu le dis et tu demandes le lien, tu ne contournes pas | Étape 14 ×1 |
| ★ | Tu me poses une question en laissant entendre que le problème vient de moi (« ouvre la page dans ton navigateur ») alors que tu n'as pas épuisé tes propres essais | Avant de me demander quoi que ce soit, tu as épuisé tes propres moyens (les trois accès ci-dessus). Ensuite : **une phrase, la cause réelle, la seule chose demandée** | Étape 14 ×1 |

---

## Vue d'ensemble

| Étape | Qui | Résultat |
| --- | --- | --- |
| 1. Lister et classer les assets | Toi | Un fichier **`Liste_assets.md`** que tu m'envoies : une liste sans doublon, avec les éléments clés d'un côté et les petits éléments (déjà répartis en planches) de l'autre |
| 2. Chercher les références dans Lexiax (une seule passe) | Toi + moi | **Un seul zip** d'images candidates, rangé par asset puis par mot, envoyé sur GitHub |
| 2 bis. Vérifier le zip reçu | Toi | Un contrôle de structure : le zip correspond exactement à la recherche (assets, mots, images) |
| 3. Choisir la meilleure référence | Toi | Une image validée par asset, choisie dans ce zip, **par lots** |
| 4. Construire l'archive | Toi | Des archives `assets_lot_NN.zip` (un dossier par génération, avec ses références et son prompt), **livrées lot par lot** ; leur somme forme `assets.zip`. Le lot 1 contient aussi l'outil **`copier_assets.pyw`** (grille « label + Copier », bouton « Move » pour ranger les images générées) |
| 5. Rassembler les images générées | Moi + toi | Je génère les images (avec `copier_assets.pyw`) et t'envoie l'arborescence réelle de `Assets` ; tu me donnes **un script Python** (chemins réels, à lancer depuis un éditeur, à placer dans `Assets`) qui **copie** toutes les images finales dans un seul dossier `assetsBrute1`, renommées sans ambiguïté, écrit un `index.csv` avec les chemins des copies, et les range dans un zip du même nom, `assetsBrute1.zip` ; **le même script pousse ensuite `assetsBrute1.zip` sur GitHub** (dépôt `ImageReferenceData`), sans aucun geste de ma part |
| 6. Envoyer et vérifier les images générées | Moi + toi | `assetsBrute1.zip` a **déjà été poussé sur GitHub par le script de l'étape 5** (je n'ai rien à glisser ni à cliquer) ; tu le télécharges au lien indiqué et tu fais un **checkup** : les images générées correspondent à la liste et à leurs prompts |
| 7. Storyboard : générer les plans | Toi + moi | Les 64 plans numérotés de 1 à 64 (numérotation continue), rangés par **séquence** dans un dossier `Storyboard`, chacun avec son prompt (`PlanN.txt`) et son image, générés **plan par plan**. C'est un storyboard : il sert seulement à **se faire une idée** de ce qui se passe, sans validation ni vérification |
| 8. Projet ImGen : générer les plans par bots | Moi + toi | Un fichier **`projet_imgen.json`** : 64 images (une par plan), avec nom, chemin de sauvegarde réel, prompt et images de référence (assets pris dans le zip du dépôt GitHub, plan précédent en local), ordonnées par vagues de dépendance. Je le colle dans ImGen (bouton « + ») |
| 9. Analyser les plans et préparer la génération des assets d'animation | Moi + toi | Je te donne l'arborescence réelle du projet ; tu m'écris un script qui sélectionne le storyboard, le zippe en `Storyboard.zip` et le pousse dans le dépôt dédié **`Storyboard`** ; tu le télécharges, tu **parcours d'abord les 64 plans pour décider l'ajustement technique de chaque asset** (tel quel, séparé pour le calque, décomposé, animation en code, feuille de sprites, nouvelle configuration ; livrable : `Registre_elements_animation.md`, que je valide), puis tu analyses chaque plan (dynamique ou statique) et tu livres, par lots, **`animation_lot_NN.zip`** (un dossier par plan, un JSON **par nouvelle génération seulement** : fond vide, asset ou groupe d'assets, avec son prompt et l'image du plan en référence ; ce qui revient d'un autre plan n'est jamais régénéré) et **`Liste_assets_animation.md`** (fiche de chaque plan : ce qui se passe, fond, assets, chronologie, montage) |
| 10. Dossier `AssetAnimation` et projet ImGen des assets d'animation | Moi + toi | Je te donne les `animation_lot_NN.zip` ; tu les assembles en **`AssetAnimation.zip`** (un dossier `PlanN` par plan, avec les JSON de génération, les fiches de code et les fichiers `_reutilise.txt` / `_rien_a_generer.txt`) ; je le décompresse et te donne le **chemin réel** ; tu m'écris **`projet_imgen_assets.json`**, le projet ImGen qui génère toutes les images d'assets d'animation, chacune enregistrée dans le dossier de son plan |
| 11. Re-vérification des assets d'animation générés | Moi + toi | Je te donne l'arborescence réelle du dossier qui contient toutes les images d'assets d'animation générées ; tu m'écris un script qui les archive et les pousse dans le dépôt **`Assets_Animation`** ; tu télécharges le zip et tu fais un **checkup** : quelles images ont une **génération grave** (à regénérer) |
| 12. Vectoriser les assets d'animation | Moi + toi | Une fois les assets d'animation validés (étape 11), on les **vectorise avec `GenSVG.pyw`**. Je te donne l'**arborescence réelle** du dossier `AssetAnimation` (tu me la demandes si tu ne l'as pas) ; tu m'écris **`projet_gensvg.json`**, le projet GenSVG : une ligne par image d'asset, avec son image source (**dans le dépôt `Assets_Animation`**, jamais en local) et le chemin du `.svg` à produire (sur mon PC, à côté de l'image) |
| 13. Archive de données pour l'animation | Moi + toi | Je te donne l'**arborescence réelle** du projet et mes décisions sur les points à trancher ; tu m'écris **`envoyer_animation.py`**, qui rassemble en **un seul zip, `AnimationData.zip`**, les SVG de chaque plan, les fiches de code, les directives (fiches par plan, registre, séquences, scénario), les images du storyboard, un `README.md` et un **`manifest.json`** qui liste chaque fichier, puis le pousse dans le dépôt dédié **`ShaderiaxAnim`** ; tu le télécharges et tu contrôles qu'il est complet. **L'archive contient aussi l'audio généré de chaque plan (`audio/`, 63 fichiers) : je relance donc `envoyer_animation.py` une fois l'étape 13 bis terminée.** Le montage est hors périmètre. Aucun code d'animation n'est écrit à cette étape |
| 13 bis. Générer l'audio de la voix off (AudioGen) | Moi + toi | Je te donne l'**arborescence réelle** du projet et mes décisions (langue, voix) ; tu **clones le dépôt `Storyboard`**, tu **récupères les `speech.txt`**, tu **traduis chaque plan en anglais** et tu y **intègres les balises d'émotion**, en suivant les **règles de balisage écrites dans ce document** (étape 13 bis) ; **pas de page HTML** : tu me livres **`Speech_audio.zip`** (les 51 `speech.txt` modifiés), **`ecraser_speeches.py`** (il écrase les `speech.txt` de mon ordinateur, après sauvegarde des originaux) et **`projet_audiogen.json`** (une ligne par plan parlé, soit 63) ; je colle le JSON dans AudioGen, qui génère les audios. **Cette étape se fait AVANT l'animation** ; une fois les 63 audios générés, **je relance `envoyer_animation.py` : l'audio de chaque plan part dans `AnimationData.zip`** |
| 14. Réaliser l'animation de chaque plan | Moi + toi | **Directement en web, sans aucun logiciel externe.** Tu lis le scénario, puis, **plan par plan**, tu écris une **page web animée** (`planN.html`) : objets, **détourage**, caméra, chronologie, éléments en code. Tu la **regardes toi-même** (images clés comparées au storyboard), tu la publies et tu me donnes le lien ; je regarde et je te dis « ça marche » ou l'erreur ; tu corriges la même page. **Les plans sont rangés comme des tâches dans ClaudeAnimatorAgent** (`projet_caa.json` : dépendances entre plans, blocage des plans dont le précédent n'est pas validé, désactivation par plan), qui les distribue à des agents ; chaque agent livre `planN.html` en fichier joint. **Aucun travail manuel pour moi** |

---

## Étape 1 : lister et classer les assets

À partir du scénario (`Plan_animation.md`), tu relèves tout ce qu'il faut produire : décors, personnages, objets, icônes.

- Une ligne par asset. Un asset qui revient dans plusieurs plans n'est listé qu'une seule fois.
- Pour chaque asset : un **nom court** (sans caractères interdits dans un nom de dossier Windows : `\ / : * ? " < > |`), une **description** (forme, taille, style, position, tirée de la colonne « Visuel et caméra »), et les **plans** où il apparaît.

### Classer : élément clé ou petit élément

- **Élément clé** : il occupe beaucoup d'espace à l'écran, ou il est important dans l'histoire, ou il revient souvent (décors, personnages, objets fil rouge comme la télécommande). Il garde sa **propre génération**.
- **Petit élément** : il occupe peu d'espace et n'a pas besoin d'un fichier à lui seul (petit objet, petite icône). Il est **regroupé** avec d'autres.

### Répartir les petits éléments en planches

Une **planche** est un groupe de petits éléments générés ensemble dans une seule image.

- On regroupe des éléments de même famille, de taille voisine et de style compatible.
- Une planche reste petite (en général 4 à 6 éléments), pour que chaque élément reste net et soigné.
- Chaque planche reçoit un nom (`planche_01_petits_objets`, par exemple).

Cette liste est la base de tout le reste : les noms d'assets et de planches deviendront les noms de dossiers de l'archive finale.

### Livraison de l'étape 1 : le fichier `Liste_assets.md`

Quand tu as fini de lister les assets à utiliser, **tu me l'envoies sous forme de fichier `Liste_assets.md`** (pas seulement dans ta réponse). Je le relis, je le corrige si besoin, puis je m'en sers à l'étape 2. Format du fichier :

- un titre, puis une phrase rappelant que les textes et éléments d'interface (cartons, badges, tampons, étiquettes, règle de vitesse, barres de signal, jauges, pastilles) ne sont pas dans la liste, car ils sont faits au montage ;
- une section **« Éléments clés (une génération chacun) »** : un tableau `# | Asset | Plans` ;
- une section **« Petits éléments (planches) »** : une sous-section par planche (`Planche 1 : télécom`, etc.), chacune avec un tableau `Élément | Plans`.

Exemple :

```
# Liste des assets de l'animation

## Éléments clés (une génération chacun)

| # | Asset | Plans |
| --- | --- | --- |
| 1 | Opérateur de drone, de dos, en camouflage | 1.1, 1.2, 9.1 |

## Petits éléments (planches)

### Planche 1 : télécom

| Élément | Plans |
| --- | --- |
| Parabole blanche sur maison | 2.5 |
```

Les descriptions détaillées (forme, taille, style, position) restent tirées du scénario : tu les utilises pour choisir les mots et écrire les prompts, mais le fichier `Liste_assets.md` n'a besoin que des noms et des plans.

## Étape 2 : chercher les images de référence dans Lexiax (une seule passe)

Cette étape se fait **une seule fois pour l'ensemble des assets** : éléments clés **et** chaque petit élément des planches (chacun a besoin de sa propre référence). Lexiax fournit déjà le prompt et les règles de choix des mots (ils sont dans l'application : tu les suis, tu ne les réinventes pas).

1. **Moi, dans Lexiax** : onglet **« Images de référence »**. Je colle dans **« SPEECH À ILLUSTRER »** le contenu de **`Liste_assets.md`** (la liste complète des assets, éléments clés et petits éléments, que tu m'as envoyée à l'étape 1), puis je clique sur **« Copier prompt + mots pour l'IA »**. Cela copie le prompt et `mots.txt`, la liste de tous les mots de ma bibliothèque. Je te les envoie **une seule fois**.
2. **Toi** : pour **chaque asset de la liste**, tu choisis dans `mots.txt` les mots qui mènent à de bonnes références, puis tu écris **un seul script Python** qui récupère les images de **tous** les assets d'un coup.
   - Tu recopies chaque mot **exactement** comme dans `mots.txt`. Avant de livrer, tu **vérifies par programme** que chaque mot existe dans `mots.txt` (aucun mot inventé).
   - **Ne sature pas : peu de mots, bien choisis.** Les mots de `mots.txt` sont déjà fidèles (chacun désigne une chose réellement repérée dans la bibliothèque, avec sa meilleure image). Inutile d'empiler des mots larges, des mots voisins et des synonymes « au cas où » : ils ramènent surtout du bruit et alourdissent le zip.
   - **Cible : 3 à 5 mots par élément clé, 2 à 4 mots par petit élément.** Le maximum absolu reste 30 mots par asset, mais il n'est pas un objectif.
   - Du particulier au général : le mot le plus précis d'abord. Tu n'ajoutes un mot plus large ou un synonyme que s'il apporte une vraie famille de formes utile, et tu supprimes tout mot qui ne mènerait pas à une référence exploitable.
   - Les mots peuvent se répéter d'un asset à l'autre : le script les traite séparément, pour que chaque asset ait son propre dossier.
   - Pour les planches, chaque petit élément est traité **comme un asset à part entière** (son propre dossier et ses propres mots).
   - Tu ne fais **pas** le tri des images à ce stade.
   - Tu limites le nombre d'images par mot (par exemple 4 à 6) pour que le zip reste léger (quelques dizaines de Mo). Cette valeur est une constante du script (`MAX_PAR_MOT`) que je peux augmenter.
   - Tu **testes le script** (syntaxe et jeu de données factice) avant de me le donner.
   - Tu respectes le format de réponse demandé par le prompt : **une ligne** de consigne courte, puis **le script dans un seul bloc de code**. Rien d'autre.
3. **Moi** : je colle le script dans la zone **« SCRIPT PYTHON »** de Lexiax et je clique sur **« Exécuter »**. Le script crée **un seul zip** dans le dossier `Bibliotheque\InfographicsShowData\references_speech`. **Le même script envoie ensuite ce zip lui-même** (voir la règle sur les envois Git) : je n'ai pas à le sélectionner dans « ZIP PRÊTS ».
4. **Le script, sans aucun geste de ma part** : le zip est envoyé à la racine du dépôt **https://github.com/officecenter632-maker/ImageReferenceData** (branche `main`). Je te donne ce lien (c'est toujours le même). Plus de bouton, plus de glisser-déposer.
   - Le dépôt est public et ne garde **qu'un seul zip à la fois** : chaque nouveau push remplace le précédent.
5. **Toi** : tu télécharges le zip depuis ce dépôt, par exemple avec `git clone --depth 1 https://github.com/officecenter632-maker/ImageReferenceData.git`, puis tu prends le fichier `references_AAAAMMJJ_HHMMSS.zip` à la racine. **Tu gardes cette copie dans ton espace de travail** : si un zip complémentaire est poussé plus tard, il remplace l'ancien sur GitHub, mais pas ta copie.
6. **Toi** : avant tout tri, tu **vérifies la structure** (voir « Vérification du zip reçu » ci-dessous). Tant que la vérification n'est pas bonne, tu ne passes pas à l'étape 3.

### Vérification du zip reçu (étape 2 bis)

Pour pouvoir comparer, tu gardes dans ton script la **carte de recherche** : pour chaque asset, son nom de dossier et la liste de ses mots. Une fois le zip téléchargé, tu fais ces contrôles **par programme** :

| Contrôle | Ce qui est attendu |
| --- | --- |
| Le zip | Un seul fichier `references_AAAAMMJJ_HHMMSS.zip` à la racine du dépôt, qui s'ouvre sans erreur (`testzip`). Son horodatage est **postérieur** à l'envoi de ton script ; sinon c'est probablement un ancien zip : tu me demandes de relancer le script, qui repousse tout seul. |
| `index.json` | Présent à la racine du zip, JSON valide, avec pour chaque image : asset, mot, fichier, vidéo d'origine. |
| Assets | Chaque asset de ta carte de recherche a son dossier, au nom exact. Aucun dossier d'asset inattendu (les assets déjà validés, exclus du script, n'y sont pas). |
| Mots | Dans chaque asset, chaque mot de ta carte a son dossier `NN_mot` (au nom exact) et contient au moins une image. Les mots vides sont ceux annoncés dans le bilan du script. |
| Images | Chaque image de `index.json` existe dans le zip, et chaque image du zip figure dans `index.json`. Pas plus de `MAX_PAR_MOT` images par mot. |
| Bilan | Les chiffres que tu recalcules (images par asset, mots introuvables, images manquantes) sont ceux du bilan affiché par le script. |

**Résultat** : tu me donnes un court compte rendu (« conforme », ou la liste des écarts).

- **Conforme** : tu passes à l'étape 3.
- **Écarts légers** (quelques mots vides, un asset sans image) : tu continues avec le reste et tu traites ces assets comme dans « Cas particuliers ».
- **Écarts importants** (zip périmé, assets entiers absents, `index.json` illisible) : tu t'arrêtes, tu me le dis, et on repart d'un nouveau push. Tu ne trie rien sur un zip qui ne correspond pas à la recherche.

### Structure du zip de collecte

Le zip est à la racine du dépôt GitHub. Son contenu :

```
references_AAAAMMJJ_HHMMSS.zip
├── 02_proprietaire_reseau/          ← un dossier par asset
│   ├── 01_homme en costume/         ← un dossier par mot
│   │   └── <images>
│   ├── 02_costume noir/
│   └── ...
├── 12_drone/
├── P1_01_parabole_blanche_maison/   ← un petit élément de planche = un dossier d'asset
├── ...
└── index.json                       ← pour chaque image : asset, mot, fichier, vidéo d'origine
```

Le script affiche à la fin un **bilan** : nombre d'images par asset, mots introuvables, images manquantes.

### Cas particuliers

- **Asset déjà validé** (par exemple l'opérateur de drone) : il n'est pas relancé, il est exclu du script.
- **Aucune bonne référence dans le zip** pour un asset : c'est l'exception. Tu me le signales à l'étape 3, et seulement pour ces assets-là tu écris un **petit script complémentaire** avec d'autres mots. On ne refait jamais la collecte complète. Le zip complémentaire passe par le même chemin (push sur le même dépôt, téléchargement, vérification de structure) et remplace l'ancien zip sur GitHub : c'est pourquoi tu as gardé ta copie du premier.

## Étape 3 : choisir la meilleure référence

Une fois le zip vérifié, tu fais le tri final, asset par asset, **dans ce zip unique**, **par lots** (par exemple 5 à 8 assets à la fois, éléments clés les plus importants d'abord). Chaque lot validé passe tout de suite à l'étape 4 et m'est livré avant que tu ne trions le lot suivant.

- Tu gardes **l'image la plus proche** de l'asset voulu : même sujet, même forme, même composition.
- Les couleurs, l'ambiance et le style **n'ont pas d'importance** pour le choix : l'IA générative les change facilement.
- Tu gardes **une image par asset**. Pour une planche, cela donne une image par petit élément : on ne mélange jamais deux éléments dans une même référence.
- Tu ne retiens que les images que tu as validées. Les autres sont ignorées.
- Si un asset n'a aucune image convenable, tu le listes dans ton retour (voir « Cas particuliers »).

## Étape 4 : construire l'archive des assets

Tu crées **un dossier par génération**. Chaque dossier a un sous-dossier `generation`, qui contient les images de référence et le prompt.

### Pour un élément clé

Le dossier porte le nom de l'asset. Le sous-dossier contient :

- **`reference`** : l'image choisie à l'étape 3, renommée `reference` (elle garde son extension, par exemple `reference.webp`) ;
- **`prompt.txt`** : le prompt pour l'IA générative.

### Pour une planche de petits éléments

Le dossier porte le nom de la planche. Le sous-dossier contient :

- **une image de référence par petit élément**, nommée `reference_01_<élément>`, `reference_02_<élément>`… (par exemple `reference_01_panier.webp`) ;
- **un seul `prompt.txt`** pour toute la planche.

### Exemple

```
assets.zip
├── operateur_drone/                  ← élément clé
│   └── generation/
│       ├── reference.webp
│       └── prompt.txt
├── telecommande_geante/              ← élément clé
│   └── generation/
│       ├── reference.webp
│       └── prompt.txt
├── planche_01_petits_objets/         ← planche de petits éléments
│   └── generation/
│       ├── reference_01_panier.webp
│       ├── reference_02_sablier.webp
│       ├── reference_03_loupe.webp
│       ├── reference_04_pouce.webp
│       └── prompt.txt
└── ...
```

### Ce que contient `prompt.txt`

**Pour un élément clé**, le prompt demande à l'IA générative de **modifier l'image `reference` pour obtenir l'asset voulu**. Il reprend ce que le scénario dit de cet asset :

- la description de l'asset (forme, taille, position, détails) ;
- les couleurs à utiliser, avec leurs codes, tirées de la charte visuelle du scénario (ici les couleurs comptent : ce sont elles que l'IA générative doit changer) ;
- le style : aplats vectoriels, sans ombre portée ; pour les personnages, une petite ellipse sombre sous les pieds ;
- les interdits du scénario : aucun logo réel, aucune ressemblance avec une personne réelle.

**Pour une planche**, le prompt demande **une seule image** qui réunit tous les petits éléments. Il contient en plus :

- la liste des éléments, avec pour chacun **la référence qui lui correspond** (« `reference_01_panier` sert pour le panier », etc.) et sa description propre ;
- la consigne de **transformer chaque élément à partir de sa propre référence**, sans mélanger les références entre elles ;
- la consigne de **bien séparer les éléments les uns des autres**, sur un fond uni, pour pouvoir les découper ensuite ;
- les mêmes couleurs, le même style et les mêmes interdits que pour un élément clé.

### Livraison progressive (pour ne pas perdre le travail validé)

Les crédits ou les messages peuvent s'arrêter à tout moment. **Tout ce qui n'a pas été livré est perdu.** Tu ne gardes donc jamais un travail validé en attente : tu le livres par lots, au fur et à mesure.

- **Un lot = quelques générations terminées** (par exemple 5 à 8 dossiers : références validées et prompts écrits). Éléments clés d'abord, par ordre d'importance, puis les planches.
- Dès qu'un lot est prêt, tu construis **`assets_lot_NN.zip`** (`assets_lot_01.zip`, `assets_lot_02.zip`…) et tu me le livres **immédiatement**, avant de commencer le lot suivant.
- Chaque lot a **la même structure** que l'exemple ci-dessus (un dossier par génération, avec son sous-dossier `generation`). Seul le **lot 1** contient en plus, à sa racine, l'outil **`copier_assets.pyw`** (voir plus bas). Les noms de dossier ne se répètent jamais d'un lot à l'autre : je fusionne les lots en les décompressant dans un même dossier.
- À chaque lot, tu me livres aussi **`Images_deja_validees_NE_PAS_RETRIER.md`** à jour. C'est la **mémoire du travail déjà fait** : il retient toutes les images de référence déjà validées, pour que personne ne les retrie ni ne les refasse.
  - Format : un tableau `Asset | Type | Image validée (chemin dans le zip de collecte) | État | Lot`.
  - Les états possibles : « validée et livrée », « à faire », « sans référence ».
  - **Règle** : un asset « validée et livrée » est **définitif**. Tu ne le retries pas, tu ne le re-livres pas, même dans une nouvelle conversation. Tu ne traites que les assets « à faire » (et « sans référence », via le script complémentaire).
  - **Reprise** : si une conversation s'arrête (crédits épuisés), je te redonne ce fichier et le lien du dépôt, et tu continues exactement là où tu t'étais arrêté. Je garde les `assets_lot_NN.zip` déjà reçus.
- Si tu sens que la limite approche, tu livres **tout de suite** ce qui est prêt, même si le lot est incomplet, et tu signales ce qui reste.
- Un `assets.zip` final qui regroupe tous les lots n'est produit que s'il reste des crédits. Il n'est pas nécessaire : la somme des lots suffit.

### `copier_assets.pyw` : copier les prompts et ranger les images générées

Générer les images à la main est pénible : il faut ouvrir chaque dossier, copier le prompt, retrouver les références, puis renommer et ranger chaque image téléchargée. Tu fournis donc **un outil** : une grille de boutons pour copier, et un bouton « Move » pour ranger.

**Livraison.** Un **seul** fichier **`copier_assets.pyw`**, livré **une seule fois**, **à la racine de `assets_lot_01.zip`** (pas dans les lots suivants). Comme je fusionne les lots dans un même dossier, il se retrouve **à la racine du dossier `assets`**, à côté des dossiers d'asset. Extension `.pyw` : un double-clic l'ouvre sans console. **tkinter uniquement** (Pillow, s'il est installé, ne sert qu'aux miniatures). Tu ne le modifies jamais d'un lot à l'autre ; s'il est corrigé, tu le re-livres, une seule fois. Tu le **testes** avant de me le donner, sur de faux dossiers d'asset et un faux dossier Téléchargements. Il doit rester dans `assets` (il cherche les dossiers d'asset à côté de lui) : pour le lancer d'ailleurs, je crée un raccourci.

**Ce qu'il reconnaît.** Une **génération** est tout dossier de `assets` qui contient `generation/prompt.txt` (élément clé ou planche). Elles sont rangées par nom de dossier : les éléments clés `01_…` à `24_…`, puis les planches `planche_01_…`. **L'image générée** d'une génération est n'importe quelle image posée **directement dans son dossier**, à côté de `generation`.

**Fenêtre principale : une grille, rien d'autre.** Pour chaque génération : un **label** (le nom du dossier) et un **bouton « Copier »**. Le label devient **vert** quand l'image générée existe. La fenêtre est **étirée sur toute la largeur de l'écran, collée en haut**, avec autant de colonnes que la largeur le permet, pour rester basse et laisser voir le navigateur en dessous. Mise à jour automatique toutes les 2 s.

- **« Copier »** met dans le presse-papiers, comme des **fichiers** à coller d'un coup dans l'IA de génération : un fichier **`<asset>_prompt.txt`** qui ne contient que le prompt (créé à la volée dans le dossier temporaire), puis les **images de référence** du sous-dossier `generation`, dans l'ordre (`reference`, ou `reference_01_…`, `reference_02_…` pour une planche). Le texte du prompt est aussi copié en texte. Sous Windows seulement ; ailleurs, seul le texte est copié.
- Une génération dont le `prompt.txt` est vide ou introuvable a son bouton grisé. Une référence introuvable est signalée dans la barre d'état et n'empêche pas la copie des autres.
- **Aucune dépendance entre générations** : contrairement aux plans, chaque asset est indépendant, on peut les générer dans n'importe quel ordre.

**Bouton « Move » : ranger les images téléchargées.** Il ouvre une fenêtre qui liste les images du dossier **Téléchargements** (miniatures, nom, date). Le but : faire correspondre chaque image à une génération précise.

- **Ordre par défaut : du plus ancien au plus récent.** L'image la plus ancienne vise la **première génération sans image**, la suivante la génération d'après, et ainsi de suite. Le bouton « Ordre » inverse (choix mémorisé dans un petit fichier `.json` créé à côté du script).
- **Cases à cocher** : seules les images cochées sont rangées. Par défaut sont cochées celles des **dernières 24 h**.
- **Permuter** : on clique sur deux lignes, puis « Permuter » : leurs cibles sont échangées.
- **Valider** : c'est seulement à ce moment que les images sont **déplacées** (pas copiées) dans le dossier de leur génération et **renommées d'après ce dossier** : `02_proprietaire_reseau.png`, `planche_01_telecom.webp` (l'extension d'origine est gardée). Les noms arbitraires de l'IA (« Cinq poses d'un homme d'affaires cartoon.png ») disparaissent donc dès le rangement.
- **Aucune image n'est jamais écrasée** : une génération qui a déjà son image n'est pas visée. Pour refaire un asset, je supprime son image à la main : son label redevient gris.
- **Annuler** ferme la fenêtre sans rien déplacer. **Dossier…** change le dossier surveillé.

**Conséquence pour l'étape 5.** Les images sont déjà dans leur dossier d'asset, **sous un nom prévisible** (`<dossier>.<extension>`). L'arborescence que je te fournis le montre, et le script `collecter_images.py` fonctionne comme décrit : il copie ces images dans `assetsBrute1`. Le cas « nom de fichier introuvable » devient rare.

---

## Étape 5 : rassembler les images générées dans un seul dossier

Cette étape commence **après** que j'ai généré toutes les images avec l'IA générative (à partir des dossiers de l'étape 4) et que je les ai posées dans leur dossier d'asset. Les noms de fichier donnés par l'IA générative sont descriptifs mais arbitraires (« Cinq poses d'un homme d'affaires cartoon.png »). Le script de cette étape copie les images dans un seul dossier et les renomme sans ambiguïté, d'après le nom de leur dossier.

### Ce que je te fournis : l'arborescence réelle

Je t'envoie l'**arborescence réelle du dossier `Assets`** (le dossier parent de `assets`), copiée telle quelle depuis mon ordinateur. Ce n'est pas un exemple : la première ligne donne le **chemin complet** du dossier et chaque ligne donne le **nom exact** d'un dossier ou d'un fichier. Tu t'en sers directement pour écrire le script. Exemple abrégé :

```
📁 D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets

├── assets/
│   ├── 01_operateur_drone/
│   │   ├── generation/
│   │   │   ├── prompt.txt
│   │   │   └── reference.webp
│   │   └── Comparaison de deux soldats assis.png      ← image générée
│   ├── planche_01_telecom/
│   │   ├── generation/
│   │   │   ├── prompt.txt
│   │   │   └── reference_01_parabole_blanche_maison.webp
│   │   └── Planche d'icônes de communication et défense.png   ← image générée
│   └── ...
└── assets.zip
```

Structure attendue : chaque dossier d'asset contient son sous-dossier `generation` (références et prompt) **et** l'image générée, posée directement dans le dossier d'asset, à côté de `generation`.

### Ce que tu fais

1. **Tu lis l'arborescence** et tu la compares à `Liste_assets.md` : tous les éléments clés et toutes les planches sont là, chaque dossier a son image générée, aucun dossier n'est en trop. Tu me signales les écarts (dossier sans image, plusieurs images dans un dossier, nom de fichier avec des caractères étranges) avant de livrer le script.
2. **Tu écris un seul script Python, `collecter_images.py`, avec les chemins réels.**
   - Le **chemin du dossier `Assets`** est copié de la première ligne de l'arborescence, écrit en dur dans le script. Tu n'utilises ni chemin relatif, ni `__file__`, ni dossier courant.
   - Le script contient un **dictionnaire `IMAGES`** : pour chaque dossier d'asset, le **nom exact du fichier image** tel qu'il figure dans l'arborescence. C'est lui qui désigne l'image de chaque asset.
   - Si le chemin contient des **emojis** (comme `👉 📚📦 🧠`), tu les écris en codes `\U0001F449`, etc., au lieu de les coller tels quels : certains éditeurs (IDLE par exemple) refusent ces caractères dans un fichier. Le reste du script peut contenir des accents.
3. **Le script se lance depuis un éditeur, pas en ligne de commande.** Je l'ouvre dans mon éditeur (IDLE, Thonny, VS Code, PyCharm) et je clique sur « Run » / « Exécuter ». Il ne lit donc aucun argument, ne pose aucune question, n'utilise pas `sys.exit`, et il écrit son bilan avec un `print` qui ne plante pas sur les caractères que l'éditeur ne sait pas afficher.
4. **Tu livres le script dans un seul bloc de code**, avec une consigne courte : le fichier se place dans le dossier `Assets` (le dossier parent de `assets`) et se lance par « Run » dans l'éditeur.
5. **Tu testes le script** avant de me le donner, sur une arborescence factice qui reprend tes noms (dossier sans image, dossier absent, plusieurs images, nom de fichier différent, caractères accentués ou non latins).

### Ce que fait le script

- Pour chaque asset du dictionnaire `IMAGES`, il cherche le fichier au **chemin exact** `Assets\assets\<dossier>\<nom du fichier>`. Le sous-dossier `generation` est ignoré : les références et les prompts ne sont pas copiés.
- Il **copie** l'image dans un nouveau dossier **`assetsBrute1`**, créé à côté de `assets` et **du même nom que le zip**, sous le **nom du dossier d'asset**. Les originaux restent à leur place dans `assets`, intacts. **Ce sont les copies de `assetsBrute1` qui font foi.**
  - `02_proprietaire_reseau\Cinq poses d'un homme d'affaires cartoon.png` devient `assetsBrute1\02_proprietaire_reseau.png`.
  - `planche_01_telecom\Planche d'icônes de communication et défense.png` devient `assetsBrute1\planche_01_telecom.png`.
- Si le nom exact est introuvable (je l'ai renommé, ou un caractère diffère), il prend l'image qu'il trouve dans le dossier et le signale. S'il y en a plusieurs, elles sont copiées sous `<asset>_v1`, `<asset>_v2`… et rien n'est écrasé.
- Si le fichier exact existe mais que le dossier contient d'autres images, seul le fichier exact est copié ; les autres sont listées dans le bilan.
- Il écrit un fichier **`index.csv`** dans `assetsBrute1`, avec une ligne par image copiée et quatre colonnes : `fichier` (nouveau nom), `asset`, `type` (`element_cle` ou `planche`) et **`chemin_copie`** (chemin complet de la copie dans `assetsBrute1`). Le CSV ne mentionne pas les originaux.
- Il range les images copiées et `index.csv` dans un **zip nommé `assetsBrute1.zip`**, créé dans le dossier `Assets`, à côté de `assets`. Les fichiers y sont dans un dossier `assetsBrute1/`, pour qu'une fois décompressé le dossier porte le même nom que le zip. Le nom vient de la constante `NOM_ZIP` en haut du script.
- Il affiche un **bilan** : nombre d'images copiées, dossiers absents, assets sans image, noms de fichier différents, autres images non copiées, dossiers non prévus. S'il n'y a aucun écart, il écrit « Aucun ecart. ».
- Le dossier `assetsBrute1`, `index.csv` et le zip sont **recréés à chaque exécution** : je peux relancer le script après avoir regénéré une image. Comme les originaux ne bougent pas, c'est sans risque.
- **Nom du dossier et du zip.** Le dossier des images et le zip portent le même nom, `assetsBrute1` : « brute » parce que ce sont les images telles que générées, avant découpage des planches et retouches. Pour une nouvelle version, je change `NOM_ZIP` en `assetsBrute2`, puis `assetsBrute3`, etc. : le dossier et le zip précédents sont conservés. Ce zip est distinct de `assets.zip` (références et prompts de l'étape 4).

### Exemple de script (projet `6-musk_starlink`)

```python
# -*- coding: utf-8 -*-
"""
collecter_images.py - projet 6-musk_starlink

Rassemble les images GENEREES de tous les assets dans un seul dossier,
avec des noms sans ambiguite. Les images sont COPIEES : les originaux restent
a leur place dans assets/, rien n'est deplace ni modifie.

A lancer depuis un editeur (IDLE, Thonny, VS Code, PyCharm...) : ouvrir ce
fichier et cliquer sur "Run" / "Executer". Aucune ligne de commande.

Resultat (le dossier et le zip portent le meme nom, NOM_ZIP) :
  <Assets>/assetsBrute1/      01_operateur_drone.png, ..., planche_01_telecom.png, index.csv
  <Assets>/assetsBrute1.zip   le meme contenu, dans un dossier assetsBrute1/ a l'interieur du zip

index.csv donne, pour chaque image, le chemin de la COPIE (dossier assetsBrute1).

Le dossier assetsBrute1, index.csv et le zip sont recrees a chaque lancement.
Change NOM_ZIP pour assetsBrute2, assetsBrute3... a chaque nouvelle version
(le dossier et le zip precedents sont alors conserves).
"""
import csv
import shutil
import zipfile
from pathlib import Path

# ---------------------------------------------------------------------------
# CHEMINS REELS (copies de l'arborescence fournie)
# Les emojis du chemin sont ecrits en codes \U pour que tous les editeurs
# acceptent ce fichier : 1F449 = main qui pointe, 1F4DA = livres,
# 1F4E6 = colis, 1F9E0 = cerveau.
# ---------------------------------------------------------------------------
DOSSIER_ASSETS_PARENT = Path(
    "D:/ScaleTube/CHANNELS/IngeniaX/"
    "\U0001F449 \U0001F4DA\U0001F4E6 Contents \U0001F9E0/"
    "Video/6-musk_starlink/Assets"
)
DOSSIER_ASSETS = DOSSIER_ASSETS_PARENT / "assets"
EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}

# Nom du livrable : assetsBrute1, puis assetsBrute2... pour une nouvelle version.
# Le dossier des images et le zip portent ce meme nom.
NOM_ZIP = "assetsBrute1"
DOSSIER_SORTIE = DOSSIER_ASSETS_PARENT / NOM_ZIP
FICHIER_ZIP = DOSSIER_ASSETS_PARENT / (NOM_ZIP + ".zip")

# ---------------------------------------------------------------------------
# IMAGE GENEREE DE CHAQUE ASSET : dossier -> nom exact du fichier (arborescence)
# ---------------------------------------------------------------------------
IMAGES = {
    "01_operateur_drone": "Comparaison de deux soldats assis.png",
    "02_proprietaire_reseau": "Cinq poses d\u2019un homme d\u2019affaires cartoon.png",
    "03_soldat_generique": "Soldat en uniforme olive minimaliste.png",
    "04_personnage_pupitre": "Trois personnages en style vectoriel flat.png",
    "05_responsable_ukrainien": "Officier militaire en uniforme d\u00e9cor\u00e9.png",
    "06_silhouettes_foule": "Planche d\u2019infographie de silhouettes bleues.png",
    "07_silhouette_couronnee_levier": "Personnage couronn\u00e9 actionnant un levier g\u00e9ant.png",
    "08_telecommande_geante": "Bouton d\u2019urgence rouge entre les mains.png",
    "09_batiment_cinq_cotes": "Complexe pentagonal en vue a\u00e9rienne.png",
    "10_satellite_constellation": "Grand satellite et constellation en orbite.png",
    "11_carte_ukraine": "Carte vectorielle de l\u2019Ukraine en bleu.png",
    "12_drone": "Deux vues d\u2019un drone quadricopt\u00e8re.png",
    "13_document": "Certificat officiel stylis\u00e9.png",
    "14_balance_geante": "Balance dor\u00e9e parfaitement \u00e9quilibr\u00e9e.png",
    "15_poste_pilotage_ecrans": "Poste de contr\u00f4le cartographique\u0d47\u0d27.png",
    "16_poste_commandement_nuit": "Centre de contr\u00f4le futuriste violet et vert.png",
    "17_bureau_angle_vitre": "Bureau moderne face \u00e0 la ville.png",
    "18_salle_presse": "Tribune de presse minimaliste en vert-de-gris.png",
    "19_table_negociation_ronde": "R\u00e9union minimaliste vue du dessus.png",
    "20_tranchee": "Coupe transversale d\u2019une tranch\u00e9e militaire.png",
    "21_mur_panneaux_arches_rideaux": "D\u00e9cor de sc\u00e8ne bleu sym\u00e9trique.png",
    "22_bureau_turquoise_dossiers": "Bureau organis\u00e9 aux dossiers color\u00e9s.png",
    "23_console_nuit_fenetre_lune": "Console lunaire sous ciel \u00e9toil\u00e9.png",
    "24_brouillard_gris": "Cadre de fum\u00e9e nuageuse monochrome.png",
    "planche_01_telecom": "Planche d\u2019ic\u00f4nes de communication et d\u00e9fense.png",
    "planche_02_militaire": "Ic\u00f4nes militaires et spatiales en flat design.png",
    "planche_03_bureau": "Ic\u00f4nes administratives en grille \u043c\u0438\u043d\u0438\u043caliste.png",
    "planche_04_interface": "Ic\u00f4nes infographiques modernes et color\u00e9es.png",
    "planche_05_symboles": "Ensemble d\u2019ic\u00f4nes color\u00e9es en grille.png",
    "planche_06_objets_de_scene": "Restrictions, temps et \u00e9quipement.png",
}


def afficher(texte=""):
    """print sans plantage, meme si l'editeur ne sait pas afficher certains caracteres."""
    try:
        print(texte)
    except UnicodeEncodeError:
        print(texte.encode("ascii", "replace").decode("ascii"))


def type_asset(nom):
    return "planche" if nom.startswith("planche_") else "element_cle"


def images_du_dossier(dossier):
    """Images posees directement dans le dossier (le sous-dossier generation est ignore)."""
    trouvees = [p for p in dossier.iterdir()
                if p.is_file() and p.suffix.lower() in EXTENSIONS]
    return sorted(trouvees, key=lambda p: (p.stat().st_mtime, p.name))


def main():
    if not DOSSIER_ASSETS.is_dir():
        afficher("ERREUR : dossier introuvable : " + str(DOSSIER_ASSETS))
        afficher("Verifie DOSSIER_ASSETS_PARENT en haut du script.")
        return

    if DOSSIER_SORTIE.exists():
        assert DOSSIER_SORTIE.name == NOM_ZIP and NOM_ZIP != "assets"  # garde-fou
        shutil.rmtree(DOSSIER_SORTIE)                  # simple dossier de copies
    DOSSIER_SORTIE.mkdir()

    lignes = []
    absents, sans_image, repli, restes = [], [], [], []

    dossiers_presents = {p.name for p in DOSSIER_ASSETS.iterdir() if p.is_dir()}
    non_prevus = sorted(dossiers_presents - set(IMAGES))

    for nom, fichier in IMAGES.items():
        dossier = DOSSIER_ASSETS / nom
        if not dossier.is_dir():
            absents.append(nom)
            continue

        exact = dossier / fichier
        if exact.is_file():
            # Chemin exact de l'arborescence : c'est l'image de l'asset.
            sources = [exact]
            autres = [p.name for p in images_du_dossier(dossier) if p != exact]
            if autres:
                restes.append((nom, autres))
        else:
            # Nom different de l'arborescence : on prend ce qui est dans le dossier.
            sources = images_du_dossier(dossier)
            if not sources:
                sans_image.append(nom)
                continue
            repli.append((nom, [p.name for p in sources]))

        for n, src in enumerate(sources, start=1):
            suffixe = "" if len(sources) == 1 else "_v" + str(n)
            nouveau = nom + suffixe + src.suffix.lower()
            copie = DOSSIER_SORTIE / nouveau
            shutil.copy2(src, copie)                              # COPIE
            lignes.append([nouveau, nom, type_asset(nom), str(copie)])

    # index.csv : le chemin de chaque copie.
    with open(DOSSIER_SORTIE / "index.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["fichier", "asset", "type", "chemin_copie"])
        w.writerows(lignes)

    # Zip : un dossier NOM_ZIP/ avec les images copiees et index.csv.
    if FICHIER_ZIP.exists():
        FICHIER_ZIP.unlink()
    with zipfile.ZipFile(FICHIER_ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(DOSSIER_SORTIE.iterdir()):
            z.write(f, NOM_ZIP + "/" + f.name)

    afficher(str(len(lignes)) + " image(s) copiee(s) sur " + str(len(IMAGES))
             + " assets attendus.")
    afficher("Dossier des images : " + str(DOSSIER_SORTIE))
    afficher("Index des chemins : " + str(DOSSIER_SORTIE / "index.csv"))
    afficher("Zip cree : " + str(FICHIER_ZIP))
    if absents:
        afficher("\nDOSSIERS D'ASSET ABSENTS :")
        for a in absents:
            afficher("  - " + a)
    if sans_image:
        afficher("\nASSETS SANS IMAGE GENEREE :")
        for a in sans_image:
            afficher("  - " + a)
    if repli:
        afficher("\nNOM DE FICHIER DIFFERENT DE L'ARBORESCENCE (image prise dans le dossier) :")
        for a, noms in repli:
            afficher("  - " + a + " -> " + ", ".join(noms))
    if restes:
        afficher("\nAUTRES IMAGES PRESENTES, NON COPIEES :")
        for a, noms in restes:
            afficher("  - " + a + " -> " + ", ".join(noms))
    if non_prevus:
        afficher("\nDOSSIERS NON PREVUS DANS LA LISTE :")
        for a in non_prevus:
            afficher("  - " + a)
    if not (absents or sans_image or repli or restes or non_prevus):
        afficher("Aucun ecart.")


if __name__ == "__main__":
    main()
```


---

## Étape 6 : envoyer les images générées sur GitHub et les vérifier

Une fois `assetsBrute1.zip` produit par le script de l'étape 5, je l'envoie sur GitHub pour que tu puisses le télécharger et faire un checkup.

### Ce que je fais

1. **Je n'ai rien à glisser ni à cliquer** : `assetsBrute1.zip` a été poussé sur GitHub par le script de l'étape 5, au même lancement.
2. Si le script signale un échec d'envoi, je **relance le même script** ; il repousse tout seul. Tu ne me demandes jamais de pousser à la main.
3. Je te dis que c'est fait.

### Lien de téléchargement

- **Téléchargement direct du zip** : https://github.com/officecenter632-maker/ImageReferenceData/raw/main/assetsBrute1.zip
- Page du dépôt (branche `main`) : https://github.com/officecenter632-maker/ImageReferenceData

Exemple : `curl -L -o assetsBrute1.zip https://github.com/officecenter632-maker/ImageReferenceData/raw/main/assetsBrute1.zip`

**Attention :** le dépôt ne garde **qu'un seul zip à la fois**. Ce push a **remplacé** le zip de références (`references_AAAAMMJJ_HHMMSS.zip`), qui n'est plus sur GitHub. Le lien ci-dessus pointe toujours vers `assetsBrute1.zip`. Pour une nouvelle version (`assetsBrute2`), le lien devient `.../raw/main/assetsBrute2.zip` et remplace le précédent : tu gardes ta copie dans ton espace de travail.

### Ce que tu fais : le checkup

1. Tu **télécharges** `assetsBrute1.zip` au lien ci-dessus et tu **gardes la copie** dans ton espace de travail.
2. **Structure (par programme)** : le zip s'ouvre sans erreur (`testzip`), contient un dossier `assetsBrute1/` avec `index.csv`, et chaque ligne du CSV a son fichier image (et inversement). Les fichiers sont bien 24 éléments clés (`01_` à `24_`) et 6 planches (`planche_01_` à `planche_06_`), soit **30 images**, sans doublon ni manque par rapport à `Liste_assets.md`.
3. **Images (à l'œil)** : tu regardes chaque image et tu la compares à son prompt et à `Liste_assets.md` : bon sujet, bon style, pas de texte déformé, fond propre (surtout pour les planches : chaque petit élément présent, bien séparé, rien de coupé). Les assets de `Images_deja_validees_NE_PAS_RETRIER.md` ne sont pas retriés : on contrôle les images **générées**, pas les références.
4. Tu m'envoies un **bilan par asset** : OK, ou à regénérer avec la raison (et, si utile, une correction du prompt). Tu ne modifies rien toi-même : pour une image à refaire, je regénère, je relance le script (même `NOM_ZIP` ou `assetsBrute2`), qui repousse tout seul, et tu recontrôles seulement ces images.
5. Quand toutes les images sont bonnes, on passe à la **génération des storyboards**.


---

## Étape 7 : organiser le storyboard et générer les plans

Cette étape commence quand le checkup de l'étape 6 est terminé et que les assets bruts (`assetsBrute1`) sont bons. Le but : **générer l'image de chacun des 64 plans de `Plan_animation.md`, à partir des assets bruts**. Tu examines de quoi chaque plan est fait, tu rédiges son prompt de génération, je génère l'image. **C'est un storyboard, juste pour se faire une idée** de ce qui se passe : il n'y a ni validation ni vérification des plans, et pas de dossier `temp`.

### Numérotation continue des plans

- Chaque plan a **un numéro unique de 1 à 64** : `Plan1`, `Plan2`… `Plan64`. **Le numéro ne se réinitialise jamais**, ni au changement de partie, ni au changement de séquence.
- Les numéros du scénario (`1.1`, `4.7`, `9.7`…) ne servent plus à nommer les fichiers. Chaque prompt rappelle le numéro d'origine, pour retrouver la ligne dans `Plan_animation.md`. Correspondance :

| Partie du scénario | Plans du scénario | Numéros continus |
| --- | --- | --- |
| 1. Accroche | 1.1 à 1.6 | Plan1 à Plan6 |
| 2. Le contexte | 2.1 à 2.6 | Plan7 à Plan12 |
| 3. La nuit où tout ralentit | 3.1 à 3.8 | Plan13 à Plan20 |
| 4. Qui a donné l'ordre ? | 4.1 à 4.8 | Plan21 à Plan28 |
| 5. Rétabli, vraiment ? | 5.1 à 5.7 | Plan29 à Plan35 |
| 6. Le verdict d'Internet | 6.1 à 6.9 | Plan36 à Plan44 |
| 7. Les gouvernements s'en mêlent | 7.1 à 7.7 | Plan45 à Plan51 |
| 8. La réponse | 8.1 à 8.6 | Plan52 à Plan57 |
| 9. Conclusion et écran de fin | 9.1 à 9.7 | Plan58 à Plan64 |

### Identifier les séquences

Une **séquence** est une suite de plans consécutifs qui partagent le même décor et les mêmes personnages. Dans le scénario, chaque nouveau décor change de teinte dominante : un changement de décor (donc de teinte) ouvre une nouvelle séquence. Une séquence peut ne contenir qu'un seul plan (fréquent dans l'accroche) ou en contenir plusieurs (par exemple les prises de parole officielles dans le même décor gris-vert).

1. Tu lis `Plan_animation.md` en entier.
2. Tu me proposes le **découpage en séquences** dans un tableau : numéro de séquence, plans (numéros continus et numéros d'origine), décor, teinte dominante, assets utilisés.
3. **Je le corrige et je le valide.** Tu ne crées aucun dossier avant ma validation.
4. Les séquences sont numérotées de façon continue : `sequence1`, `sequence2`, `sequence3`…

### Le dossier `Storyboard`

Une fois le découpage validé, tu crées **tout le dossier d'un coup** et tu me le livres en `Storyboard.zip`. Cette première archive contient : à la racine le fichier **`Sequences.md`** (le tableau du découpage), puis tous les dossiers `sequenceN` avec leur `speech.txt`, et **tous les fichiers `PlanN.txt`**, un par plan, dans le dossier de sa séquence. **Tous sont remplis** : les 64 prompts sont écrits d'un coup, plans initiaux et plans suivants, pour que je puisse générer dans l'ordre que je veux. Ainsi, le nombre de fichiers `PlanN.txt` d'un dossier me dit combien de plans contient la séquence :

```
Storyboard/
├── Sequences.md
├── sequence1/
│   ├── speech.txt
│   ├── Plan1.txt
│   ├── Plan1.png
│   ├── Plan2.txt
│   └── Plan2.png
├── sequence2/
│   ├── speech.txt
│   ├── Plan3.txt
│   └── Plan3.png
└── ...
```

- **`speech.txt`** : le speech dit pendant cette séquence, **mot pour mot** (colonne « Voix off » de `Plan_animation.md`), plans dans l'ordre, une ligne par plan sous la forme `Plan6 : la phrase`. Rien n'est ajouté, rien n'est retiré. Un plan sans voix off (l'écran de fin) est marqué `Plan64 : (aucune voix off)`.
- **`PlanN.txt`** : le prompt de génération du plan N, dans le dossier de sa séquence. **Un fichier par plan, tous créés dès le départ et tous remplis** : il n'y a ni validation ni attente, donc rien ne justifie de laisser un plan vide.
- **`PlanN.png`** : l'image du plan, que je pose **directement dans le dossier de la séquence**, à côté de `PlanN.txt`. Il n'y a **pas de dossier `temp`** et **aucune validation** : une image posée est une image prise, le storyboard sert seulement à se faire une idée.
- Au départ, aucune image : le dossier d'une séquence ne contient que `speech.txt` et les `PlanN.txt` remplis.
- **Aucun fichier à compléter plus tard** : il n'y a pas de zip `Storyboard_NN.zip`. Si un prompt doit être corrigé, tu me livres le fichier corrigé, avec son chemin.

### Règle des fichiers `PlanN.txt` : un par plan, tous remplis dès le départ

- **Tous les plans ont leur fichier, et tous sont remplis.** Dans chaque dossier `sequenceN`, tu crées un `PlanN.txt` pour **chaque plan** de la séquence, dès la première archive, **avec son prompt complet**. Le nombre de fichiers `PlanN.txt` d'un dossier donne le nombre de plans de la séquence : `sequence1` contient `Plan1.txt` et `Plan2.txt`, donc 2 plans ; `sequence26` contient `Plan30.txt`, `Plan31.txt` et `Plan32.txt`, donc 3 plans.
- **Le plan initial** (le premier de la séquence) part des assets seuls. **Les plans suivants** de la séquence joignent aussi **l'image du plan précédent**, avec son chemin complet (`...\\Storyboard\\sequenceN\\PlanN.png`), même si cette image n'existe pas encore au moment où tu écris le prompt : elle existera quand je générerai la séquence dans l'ordre. En-tête du fichier : « Plan suivant de la séquence : joindre l'image du plan précédent (PlanN) pour garder le décor et les personnages. »
- **Aucun fichier vide**, aucun fichier à remplir plus tard.
- **Les fichiers ne sont jamais supprimés ni renommés.** Une séquence d'un seul plan n'a qu'un fichier.

Exemple : `sequence1/` contient `Plan1.txt` (plan initial) et `Plan2.txt` (plan suivant, qui joint `Plan1.png`), tous deux remplis ; `sequence2/` contient seulement `Plan3.txt`.

### Ce que contient `PlanN.txt`

Avant d'écrire le prompt, tu **examines de quoi le plan est fait** : sa ligne dans `Plan_animation.md` (voix off, visuel et caméra, texte à l'écran, couleur), et ce que la voix off veut faire comprendre. Le fichier contient :

1. **L'identité du plan** : `PlanN`, numéro d'origine (par exemple 4.7), séquence, durée.
2. **La voix off** du plan, pour le contexte.
3. **Ce que le plan représente** : en une phrase, ce que l'image doit faire comprendre.
4. **Les images à joindre**, avec leur **chemin complet** (lecteur, dossiers et nom de fichier, jamais un chemin relatif ni un simple nom), pour que je puisse les glisser directement dans l'IA de génération :
   - les **assets** nécessaires, par exemple `D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets\assetsBrute1\17_bureau_angle_vitre.png`. Quand l'élément vient d'une planche, le prompt donne le chemin complet de la planche, puis dit seulement lequel (par exemple « `...\assetsBrute1\planche_04_interface.png` : le cadran VITESSE »). **Tu ne décris pas le visuel des assets joints** : ils sont fournis en image, on cite leur nom et rien de plus ;
   - **l'image du plan précédent**, si le plan est dans la même séquence, elle aussi avec son chemin complet : `D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Storyboard\sequenceN\PlanN.png`. C'est elle qui garde la cohérence du décor et des personnages.
5. **Le prompt de génération** : composition (ce qui est où), pose des personnages, ce qui s'affiche sur les écrans, et la couleur du fond quand le plan introduit un fond nouveau (en code couleur). Pour le style, **une seule phrase : « même style que les images de référence jointes »** ; tu ne redécris ni le style ni l'apparence des assets.
6. **Ce que l'image ne contient pas** : ni texte, ni étiquette, ni badge, ni logo (tout cela est fait au montage, voir `Liste_assets.md`). Les mouvements de caméra (zoom, recul) sont aussi faits au montage : l'image montre la **composition la plus large** du plan (celle d'où partent ou où arrivent le zoom et le recul), pour que le montage puisse s'y déplacer.
7. **Ce qui est fait au montage** : une rubrique « FAIT AU MONTAGE (à ne pas dessiner) » qui liste, pour ce plan, le texte, les tampons, les badges, le logo et le mouvement de caméra.

Le fichier suit toujours cet ordre : identité, voix off, ce que le plan représente, images à joindre, prompt de génération, phrase de style et interdits, fait au montage. Exemple, `sequence3/Plan4.txt` :

```
PLAN4  (plan 1.4 du scénario) · sequence3 · 4 s
Plan initial de la séquence : aucune image de plan précédent à joindre.

VOIX OFF
À cause de l'homme qui possède le réseau.

CE QUE LE PLAN REPRÉSENTE
Le responsable est enfin désigné : le propriétaire du réseau, assis dans son bureau, tient une télécommande géante à un seul bouton. Un petit satellite flotte au-dessus de lui, pour dire qu'il contrôle le réseau.

IMAGES À JOINDRE
- D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets\assetsBrute1\17_bureau_angle_vitre.png
- D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets\assetsBrute1\02_proprietaire_reseau.png (pose assise, première à gauche)
- D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets\assetsBrute1\08_telecommande_geante.png
- D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Assets\assetsBrute1\10_satellite_constellation.png (un seul satellite)

PROMPT DE GÉNÉRATION
Dans le décor 17, le propriétaire du réseau (02, pose assise) est assis derrière le bureau, face au spectateur, au centre de l'image. Il tient à deux mains, devant sa poitrine, la télécommande géante (08), presque aussi grande que son torse. Un petit satellite (10) flotte au-dessus de sa tête. Dominante vert menthe #86DDAB.

Même style que les images de référence jointes. Format 16:9.
L'image ne contient aucun texte, étiquette, badge, tampon ni logo (faits au montage). Les mouvements de caméra aussi : l'image montre la composition la plus large du plan.

FAIT AU MONTAGE (à ne pas dessiner)
Le gros plan sur la télécommande puis le recul qui révèle le personnage ; le logo de la chaîne en bas à gauche.
```

### Ordre de progression

1. **Tous les prompts sont déjà écrits** (pour laisser des bots générer les plans à ma place avec ImGen, voir l'étape 8). Je génère les images dans l'ordre de chaque séquence (le plan initial d'abord, puis les suivants avec l'image du plan précédent) et je pose chaque image dans le dossier de sa séquence.
2. **Aucune validation, aucune vérification.** Tu ne contrôles pas les images et tu ne demandes pas de validation : c'est un storyboard, juste pour se faire une idée. Si je veux refaire un plan, je te le dis.
3. **Tu n'as plus de prompt à écrire**, sauf correction demandée ou plan à refaire : tu me livres alors le fichier `PlanN.txt` corrigé.

### Cas particuliers

- **Plan qui reprend un plan d'une autre séquence.** Le scénario le prévoit parfois (par exemple 4.7 reprend le décor de 4.2, 9.1 celui de 1.1, 9.4 celui de 5.6). Le prompt cite alors l'image de ce plan (son **chemin complet**, par exemple `D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink\Storyboard\sequence3\Plan4.png`) en plus des assets. Si l'image de ce plan n'existe pas encore, tu me le dis et on le traite d'abord.
- **Plan sans asset généré** (carton de texte, fond uni, écran de fin) : le prompt décrit seulement le fond et la couleur ; le texte reste au montage.

---

## Étape 8 : le fichier projet pour ImGen (génération automatique des plans)

Cette étape commence quand le `Storyboard` est livré (étape 7) et que je veux générer les plans avec **ImGen** (`ImGen.pyw`) au lieu de les générer à la main. Les `PlanN.txt` sont la source, le JSON en est la copie exacte, et les images arrivent au même endroit (`Storyboard\sequenceN\`).

### Ce qu'ImGen attend

Un JSON que je colle dans ImGen (bouton **« + »**, « Nouveau projet »). ImGen le valide, crée le projet et affiche un tableau : une ligne par image. Les bots prennent les images **dans l'ordre du JSON**, une à la fois.

```
{
  "projet": "nom du projet",
  "images": [
    {
      "nom": "Plan1",
      "chemin_sauvegarde": "chemin complet de l'image à créer (.webp)",
      "prompt": "le prompt complet",
      "references": {
        "local": ["chemins complets d'images sur mon PC"],
        "depot": {"url": "lien du dépôt", "branche": "main", "chemins": ["chemins vus dans le zip du dépôt"]}
      }
    }
  ]
}
```

`references` est facultatif : `null`, ou `local`, ou `depot`, ou les deux (avec des images **différentes** dans chacun).

### Comment le bot (`GPTimageGenarator.py`) lit les références

- **`local`** : le bot lit le fichier sur mon PC (directement, ou par le pont pilote si le bot tourne sur un notebook). Le chemin doit exister **exactement** comme écrit, extension comprise.
- **`depot`** : le bot **clone** le dépôt (`git clone --depth 1`, branche demandée), puis **extrait toujours d'abord tous les zip du dépôt** dans un dossier `<dépôt>_extrait` (comme « Extraire ici »). Les `chemins` sont donc ceux **qu'on voit dans le zip**, par exemple `assetsBrute1/17_bureau_angle_vitre.png` (le dossier du zip porte le nom du zip). Chaque chemin est cherché d'abord dans les zip extraits, puis dans le clone. Un chemin qui ne trouve aucun fichier fait échouer l'image.
- Les références sont jointes au chat **avant** le prompt, **locales d'abord**, puis celles du dépôt. Le bot ajoute lui-même à chaque prompt « Génère l'image demandée. Réponds uniquement avec l'image, sans texte. » : le JSON ne la répète pas.
- **Limites par plan** : 10 références au maximum (locales et dépôt ensemble), 10 Mo par fichier.
- **Format des images** : la compression WebP du bot est **conservée** (qualité 60). Le bot enregistre donc chaque plan en **`.webp`** et ImGen garde cette extension. Le plan suivant reçoit l'image telle quelle, en WebP.

### Ce que je te fournis

1. L'**arborescence réelle** du dossier `Storyboard`, copiée telle quelle depuis mon ordinateur (chemin complet en première ligne), comme à l'étape 5. Et celle du dossier `Assets` si elle a changé.
2. Le **lien du dépôt GitHub** (toujours `https://github.com/officecenter632-maker/ImageReferenceData`, branche `main`). **Tant qu'ImGen génère, le dépôt doit contenir le zip des assets** (`assetsBrute1.zip`, ou `assetsBrute2.zip` si j'en ai fait une nouvelle version, qui contient alors les 30 images à jour). Je ne pousse rien d'autre dans le dépôt pendant ce temps : un push remplace le zip précédent et casserait tous les chemins du dépôt.

### Ce que tu fais

0. **Avant de créer le projet, tu me demandes toujours** l'**arborescence réelle du dossier de références GitHub tel qu'il est sur mon PC** (chemin complet en première ligne), au cas où je devrais générer des images à la main. Tu ne commences pas sans l'avoir.
1. **Tu lis les 64 `PlanN.txt`** (dans `Storyboard.zip` ou dans le dossier). Tu compares l'arborescence à `Sequences.md` : 51 dossiers `sequenceN`, 64 fichiers `PlanN.txt`, aucun en trop. Tu me signales les écarts avant de livrer le JSON.
2. **Tu télécharges le dépôt** (`git clone --depth 1`), tu notes le nom du zip qu'il contient et tu en lis le contenu : c'est la **seule source** des chemins `depot`. Tu n'écris jamais un chemin de dépôt de mémoire.
3. **Tu écris le JSON, une image par plan** (64 entrées), avec ces règles :

| Champ | Règle |
| --- | --- |
| `projet` | Un nom court (par exemple `6-musk_starlink_storyboard`). ImGen refuse un nom de projet déjà existant. |
| `nom` | `Plan1` … `Plan64`, uniques, numérotation continue. |
| `chemin_sauvegarde` | Le **chemin complet** `.../Storyboard/sequenceN/PlanN.webp`, écrit avec des `/`, recopié de l'arborescence (emojis du chemin recopiés tels quels : le JSON est collé dans ImGen, pas ouvert dans un éditeur Python, donc pas de codes `\U`). L'extension est `.webp` parce que le bot enregistre en WebP. |
| `prompt` | Le contenu **mot pour mot** de la rubrique « PROMPT DE GÉNÉRATION » de `PlanN.txt` (composition, phrase de style, interdits), jusqu'à « FAIT AU MONTAGE » exclu. Ni voix off, ni liste d'images, ni « FAIT AU MONTAGE », ni la consigne que le bot ajoute. Tu ne reformules rien. Guillemets et retours à la ligne échappés correctement. |
| `references.depot` | Les **assets** de « IMAGES À JOINDRE » : `url`, `branche`, et `chemins` **tels qu'ils sont dans le zip** (par exemple `assetsBrute1/17_bureau_angle_vitre.png`), dans l'ordre de « IMAGES À JOINDRE ». Une planche n'est listée **qu'une fois**, même si le plan utilise deux de ses éléments (le prompt dit lequel). Aucun caractère `* ? [ ]` dans un chemin : le bot les lit comme un motif. |
| `references.local` | Les images de **plans**, qui n'existent que sur mon PC : l'**image du plan précédent** de la séquence, et l'image reprise d'un autre plan (cas particuliers de l'étape 7), en **chemins complets**, avec l'extension **`.webp`** (le format réel enregistré par le bot). Le plan précédent d'abord. |
| Plan initial sans plan repris | Seulement `depot`. |
| Carton, fond uni, écran de fin | `"references": null` (pas d'asset, le prompt décrit le fond). |

   Une même image n'apparaît jamais à la fois dans `local` et dans `depot`. Un plan a **au plus 10 références** en tout. Si le plan joint un **asset** déjà présent en `local` dans mon arborescence, il reste malgré tout en `depot` : une seule source par image.

4. **Tu ordonnes les images par vagues.** ImGen prend la première image libre dans l'ordre du JSON et **ne tient pas compte des dépendances** : un bot pourrait commencer `Plan2` avant que `Plan1.webp` existe, et l'image échouerait (« référence locale introuvable »). Tu calcules donc, à partir des « IMAGES À JOINDRE », le graphe des dépendances entre plans :
   - **vague 1** : les plans qui ne joignent aucune image de plan (plans initiaux de séquence qui ne reprennent rien) ;
   - **vague 2** : les plans dont toutes les dépendances sont en vague 1 (deuxièmes plans de séquence, reprises d'un plan de vague 1) ;
   - **vague 3**, **vague 4**… de même.
   Dans une vague, l'ordre suit le numéro de plan. Le JSON liste la vague 1, puis la 2, etc. Tu m'indiques dans ton bilan **quel plan ouvre chaque vague** : je mets en pause à la fin d'une vague (bouton « Pause ») pour que les bots ne démarrent pas une vague dont les images précédentes ne sont pas toutes finies. Une image qui échoue faute de référence se relance via le menu « Bots » (relancer les échecs).

5. **Tu contrôles par programme avant de livrer :**

| Contrôle | Ce qui est attendu |
| --- | --- |
| Validateur d'ImGen | Tu charges `ImGen.pyw` (il s'importe sans interface ni PySide6) et tu passes ton JSON à sa fonction `parse_project_text` : **aucune erreur**. Les seuls avertissements acceptés sont « fichier local introuvable » pour des images de plans pas encore générées. |
| Plans | 64 entrées, `Plan1` à `Plan64`, sans doublon ni manque, chaque `chemin_sauvegarde` dans le bon dossier `sequenceN`, en `.webp`. |
| Prompts | Chaque `prompt` est identique à la rubrique de son `PlanN.txt` (comparaison automatique). |
| Dépôt | Tu clones le dépôt et tu **extrais le zip** comme le fait le bot : **chaque** chemin de `depot.chemins` désigne un fichier existant, et aucun ne contient `* ? [ ]`. Le nom de dossier dans les chemins est bien celui du zip présent dans le dépôt. |
| Références locales | Chaque chemin local de **plan** pointe vers un `PlanN.webp` d'un dossier de séquence existant, d'un plan **plus tôt dans l'ordre des vagues**. |
| Cohérence avec `PlanN.txt` | Les images à joindre de chaque plan sont toutes présentes dans `references`, ni plus, ni moins. |
| Limites du bot | Chaque plan a au plus 10 références ; aucun fichier de référence ne dépasse 10 Mo. |
| Ordre | Aucune image ne dépend d'un plan placé après elle dans le JSON. |

6. **Tu livres** le fichier **`projet_imgen.json`** (fichier complet, jamais tronqué) avec une consigne courte : « dans ImGen, clique sur **+**, colle le contenu du fichier ». Puis un bilan : nombre d'images, les vagues (plan qui ouvre chacune), le zip du dépôt vérifié, les avertissements attendus.

### Premier essai

Avant de lancer les 64 plans, je génère **`Plan1` puis `Plan2`**. Tu me dis quoi vérifier :
- `Plan2` a bien reçu `Plan1` en référence (le chemin local avec emojis passe bien par le pont si le bot tourne sur un notebook) ;
- `Plan1` a bien été enregistré en `.webp` (si le navigateur n'a pas pu produire du WebP, le format peut différer : tu me livres alors le JSON corrigé) ;
- l'image `.webp` de `Plan1` est bien rangée dans le dossier de sa séquence, sous le nom attendu.

### Corrections

Un prompt à corriger : tu me livres le `PlanN.txt` corrigé **et** l'entrée JSON correspondante, toujours identiques. Les noms de plans ne changent jamais. Si l'image du plan est déjà générée, tu me livres aussi, dans la même réponse, le `reinitialisation_imgen.html` (étape 9) pour que je puisse la réinitialiser dans ImGen d'un clic de copie. ImGen ne modifie pas les prompts : le `projet_imgen.json` corrigé doit être posé dans le dossier du projet **avant** de coller le JSON de réinitialisation.

---

## Étape 9 : analyser les plans et préparer la génération des assets d'animation

Cette étape commence quand **toutes les images des 64 plans sont générées** (étape 7, ou étape 8 avec ImGen) et que je les ai rangées dans `Storyboard`. Le but : à partir de chaque plan, savoir exactement ce qui est **le fond** (statique), ce qui **bouge, apparaît ou change d'état** (dynamique), et ce qui se fait **au montage** ; puis **préparer le prompt de génération de chaque élément ou groupe d'éléments**, sur fond détourable, pour qu'ils soient ensuite animés. Les images du storyboard servent de **références visuelles** : ce sont elles que l'IA générative reçoit pour regénérer chaque élément isolé du reste de la scène.

**Principe directeur : on décide d'abord, pour chaque asset, comment l'ajuster à ce que le storyboard en montre ; on ne génère jamais deux fois le même élément.** Un même fond, un même personnage, un même objet revient souvent dans plusieurs plans, et le storyboard le montre chaque fois dans une configuration précise (pose, état, taille, ce qui le cache). Les assets généraux sont déjà connus (`Liste_assets.md`, `assetsBrute1`) ; c'est leur **ajustement technique** qu'on décide. Selon son **rôle dans la scène**, un asset sert tel quel, ou est **décomposé en éléments séparés** que nous reconstituons et manipulons nous-mêmes, ou est décliné en **feuille de sprites**, ou est remplacé par une **animation en code générée par IA**, ou demande une **nouvelle configuration**. Générer chaque plan indépendamment multiplierait le travail, donnerait des découpages différents d'un plan à l'autre et produirait des versions qui ne se ressemblent pas. On **décide donc d'abord, sur les 64 plans et asset par asset, l'ajustement technique de chacun, avant d'écrire le moindre prompt** ; chaque asset, sous-asset, feuille de sprites et configuration est ensuite généré **une seule fois**, dans le plan où il se voit le mieux, et les autres plans le **réutilisent**. Cela renforce le côté **dynamique** : le découpage suit les mouvements dont chaque scène a besoin, et il est le même d'un plan à l'autre.

Cette étape ne génère aucune image. Elle produit trois livrables : d'abord **`Registre_elements_animation.md`** (la décision d'ajustement technique de chaque asset, configuration par configuration, livrée avant tout prompt), puis, par lots d'environ 10 plans, **l'archive de prompts** (`animation_lot_NN.zip`, un dossier par plan, un JSON par nouvelle génération) et **`Liste_assets_animation.md`** (la fiche de chaque plan : ce qui se passe, fond, assets, chronologie, montage), sans rien d'implicite, pour qu'il n'y ait aucun embrouillement ni à la création des assets sur fond détourable, ni à l'animation.

### Dépôt dédié : `Storyboard`

Le storyboard ne va **pas** dans `ImageReferenceData`. Il a son propre dépôt : **`Storyboard`** (`https://github.com/officecenter632-maker/Storyboard`, branche `main`). Les deux dépôts sont indépendants : pousser `Storyboard.zip` dans `Storyboard` **ne remplace pas** `assetsBrute1.zip`, qui reste dans `ImageReferenceData`, et les chemins `depot` d'ImGen continuent de fonctionner. Il n'est donc plus nécessaire d'attendre la fin d'ImGen pour pousser, mais je garde ma copie locale de `assetsBrute1`, qui resservira pour la réutilisation des assets. Le dépôt `Storyboard` ne garde lui aussi **qu'un seul zip à la fois** : un nouveau push de `Storyboard.zip` remplace le précédent. L'envoi ne passe plus par Lexiax mais par un script (voir ci-dessous).

### Ce que je fais : te donner l'arborescence du projet

1. Quand les 64 images sont générées et rangées dans `Storyboard`, je t'envoie l'**arborescence réelle du projet actuel**, copiée telle quelle depuis mon ordinateur : la première ligne donne le **chemin absolu complet du dossier racine du projet** (ici `D:\ScaleTube\CHANNELS\IngeniaX\👉 📚📦 Contents 🧠\Video\6-musk_starlink`, qui contient `Storyboard`, `Assets`, `Meta`…), chaque ligne le **nom exact** d'un dossier ou d'un fichier (comme à l'étape 5 et à l'étape 8).
2. **Si je ne l'ai pas encore envoyée, tu me la demandes** avant d'écrire quoi que ce soit. Tu n'écris jamais un chemin de mémoire.
3. Je te dis aussi comment je m'authentifie auprès de GitHub : `git` est installé et déjà connecté à mon compte, ou j'ai un jeton d'accès (token) à mettre dans le script. Si tu ne le sais pas, tu me le demandes en même temps que l'arborescence.

### Ce que tu fais : le script `envoyer_storyboard.py`

À partir de mon arborescence, tu écris **un seul script Python, `envoyer_storyboard.py`**, qui sélectionne **uniquement le storyboard** (les plans), le zippe et l'envoie dans le dépôt `Storyboard`.

**RÈGLE D'OR : tu ne réécris JAMAIS ce script de zéro.** Le script ci-dessous (« Modèle de `envoyer_storyboard.py` ») est **déjà écrit, testé et utilisé avec succès** sur mon ordinateur. **Tu le recopies tel quel, en entier, et tu ne changes que ce que ma situation impose** : le chemin `PROJET` (copié de la première ligne de mon arborescence, emojis en codes `\U0001F449`, etc.), le nom du projet dans l'en-tête, `NB_SEQUENCES` et `NB_PLANS` si le découpage a changé, `DEPOT_URL` / `LIEN_DIRECT` si le dépôt change. **Tu ne touches ni à la structure, ni aux fonctions, ni à la logique d'envoi** (dépôt neuf, un seul commit, push forcé, vérification de la branche distante, jeton jamais affiché) : réécrire du code qui marche fait perdre du temps et introduit des erreurs. Si tu penses qu'une amélioration est vraiment nécessaire, tu me la proposes **avant**, en une phrase, et tu ne l'appliques que si je dis oui. Quand je te redemande « le code de mise à jour », tu me **renvoies ce même modèle** (avec le chemin à jour), jamais une nouvelle version.

**Règles d'écriture** (les mêmes que `collecter_images.py`, étape 5) :
- **le script s'exécute n'importe où sur l'ordinateur** : rangé dans n'importe quel dossier (le Bureau, Téléchargements…), lancé avec n'importe quel dossier courant, il fonctionne de la même façon. Pour cela, il ne dépend ni de son emplacement ni du dossier courant : tu utilises le **chemin absolu du projet**, copié de la première ligne de l'arborescence et écrit en dur en tête du script (constante `PROJET`), et tu en déduis `Storyboard` et `Storyboard.zip`. Ni chemin relatif, ni `__file__`, ni dossier courant ; les emojis du chemin sont écrits en codes `\U0001F449`, etc. ;
- le script se lance **depuis un éditeur** (« Run » / « Exécuter ») : aucun argument, aucune question, pas de `sys.exit`, un `print` qui ne plante pas sur les caractères non affichables ;
- tu le **testes** avant de me le donner, sur un faux dossier `Storyboard` et un faux dépôt `git` local (fichier en trop, image manquante, dépôt vide, ancien zip déjà présent) ;
- tu le livres **dans un seul bloc de code**, avec une consigne courte : il peut être rangé où je veux, et se lance par « Run » dans l'éditeur.

**Ce que le script sélectionne** (et rien d'autre) :

| Inclus | Exclu |
| --- | --- |
| `Sequences.md` à la racine ; dans chaque `sequenceN` : `speech.txt`, les `PlanN.txt` et les images des plans (`.webp`, `.png`, `.jpg`, `.jpeg`, casse du nom comme sur le disque) | `copier_prompts.pyw`, `copier_prompts.json`, `projet_imgen.json`, dossiers `temp`, anciens zip, tout autre fichier. Les fichiers exclus sont listés dans le bilan |

**Ce qu'il fait, dans cet ordre :**
1. **Contrôle de structure avant tout envoi** : 51 dossiers `sequenceN`, 64 fichiers `PlanN.txt`, **64 images** (une par plan, dans le bon dossier), 51 `speech.txt`. En cas d'écart (image manquante, plan en trop, mauvais dossier), il l'affiche et **n'envoie rien** : un zip incomplet ne part pas. Une constante `FORCER = False` permet de passer outre, si je le décide.

   **Contrôle des images suspectes : pas dans le script.** Le modèle ne contient pas ce contrôle et tu ne l'y ajoutes pas (sauf si je te le demande). Tu le fais **toi-même, par programme, sur la copie téléchargée** (voir « cloner et contrôler le storyboard », point 3) : image illisible, entièrement noire ou blanche, minuscule, aplat uni, dimensions différentes. Aucun plan suspect n'est écarté en silence.
2. **Zip** : il crée `Storyboard.zip` à la racine du projet, à côté du dossier `Storyboard`, avec un dossier racine `Storyboard/` ; il est recréé à chaque lancement. S'il dépasse **100 Mo** (limite de GitHub par fichier), il s'arrête et le dit.
3. **Envoi** : avec `git`, il crée dans un dossier temporaire un dépôt neuf qui ne contient que `Storyboard.zip`, fait **un seul commit**, puis le pousse sur `https://github.com/officecenter632-maker/Storyboard` (branche `main`, push forcé). Le dépôt ne garde ainsi **qu'un seul zip et un seul commit** : l'ancien zip disparaît, et le dépôt ne grossit pas à chaque envoi. Il fonctionne aussi sur un dépôt vide (premier envoi). Après le push, il relit la branche distante pour **vérifier** que le commit y est. Il ne touche **jamais** à `ImageReferenceData`.
4. **Authentification** : il utilise les identifiants `git` déjà enregistrés sur mon ordinateur ; si je lui ai donné un jeton (constante `GITHUB_TOKEN`, vide par défaut), il l'utilise, **sans jamais l'afficher** dans le bilan. Si `git` est absent ou si l'envoi est refusé, il le dit en clair et laisse `Storyboard.zip` en place pour que je puisse l'envoyer autrement.
5. **Bilan** : nombre de fichiers zippés (plans, images, speech), taille du zip, éventuels fichiers exclus, écarts de structure, résultat du push et lien de téléchargement direct. S'il n'y a aucun écart, il écrit « Aucun ecart. ».

### Modèle de `envoyer_storyboard.py` (projet `6-musk_starlink`) : à recopier, pas à réécrire

```python
# -*- coding: utf-8 -*-
"""
envoyer_storyboard.py - projet 6-musk_starlink

Selectionne UNIQUEMENT le storyboard (Sequences.md, speech.txt, PlanN.txt et
images des plans), controle sa structure, le zippe en Storyboard.zip et le
pousse dans le depot GitHub "Storyboard".

Ce script s'execute N'IMPORTE OU sur l'ordinateur : range-le dans n'importe
quel dossier (Bureau, Telechargements...) et lance-le depuis un editeur
(IDLE, Thonny, VS Code, PyCharm...) avec "Run" / "Executer". Il n'utilise ni
chemin relatif, ni __file__, ni dossier courant : tout part du chemin ABSOLU du
projet (constante PROJET).

Resultat :
  <PROJET>/Storyboard.zip      (dossier racine Storyboard/ a l'interieur du zip)
  depot GitHub Storyboard      un seul commit, un seul fichier : Storyboard.zip

Le depot ne garde qu'un seul zip : chaque envoi REMPLACE le precedent
(historique reduit a un commit, push force). ImageReferenceData n'est jamais
touche.

Authentification GitHub : par defaut, git utilise les identifiants deja
enregistres sur l'ordinateur. Sinon, renseigne GITHUB_TOKEN (jeton d'acces).
Le jeton n'est jamais affiche.
"""
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

# ---------------------------------------------------------------------------
# CHEMIN ABSOLU DU PROJET (copie de la premiere ligne de l'arborescence)
# Les emojis sont ecrits en codes \U pour que tous les editeurs acceptent ce
# fichier : 1F449 = main qui pointe, 1F4DA = livres, 1F4E6 = colis,
# 1F9E0 = cerveau.
# ---------------------------------------------------------------------------
PROJET = Path(
    "D:/ScaleTube/CHANNELS/IngeniaX/"
    "\U0001F449 \U0001F4DA\U0001F4E6 Contents \U0001F9E0/"
    "Video/6-musk_starlink"
)
DOSSIER_STORYBOARD = PROJET / "Storyboard"
FICHIER_ZIP = PROJET / "Storyboard.zip"

# ---------------------------------------------------------------------------
# DEPOT GITHUB
# ---------------------------------------------------------------------------
DEPOT_URL = "https://github.com/officecenter632-maker/Storyboard.git"
BRANCHE = "main"
LIEN_DIRECT = ("https://github.com/officecenter632-maker/Storyboard/"
               "raw/main/Storyboard.zip")
GITHUB_TOKEN = ""          # vide = identifiants git deja enregistres

# ---------------------------------------------------------------------------
# ATTENDU
# ---------------------------------------------------------------------------
NB_SEQUENCES = 51
NB_PLANS = 64
FORCER = False             # True : envoie meme s'il y a des ecarts de structure
TAILLE_MAX = 100 * 1024 * 1024   # limite GitHub par fichier

RE_SEQ = re.compile(r"^sequence(\d+)$", re.IGNORECASE)
RE_TXT = re.compile(r"^plan(\d+)\.txt$", re.IGNORECASE)
RE_IMG = re.compile(r"^plan(\d+)\.(webp|png|jpg|jpeg)$", re.IGNORECASE)


def afficher(texte=""):
    """print sans plantage, meme si l'editeur ne sait pas afficher certains caracteres."""
    try:
        print(texte)
    except UnicodeEncodeError:
        print(texte.encode("ascii", "replace").decode("ascii"))


def masquer(texte):
    """Retire le jeton de tout texte affiche."""
    if GITHUB_TOKEN:
        texte = texte.replace(GITHUB_TOKEN, "***")
    return texte


def selectionner():
    """Retourne (fichiers a zipper, exclus, ecarts)."""
    inclus, exclus, ecarts = [], [], []
    txt, img, speech = {}, {}, {}

    seq_dossiers = sorted(
        (p for p in DOSSIER_STORYBOARD.iterdir()
         if p.is_dir() and RE_SEQ.match(p.name)),
        key=lambda p: int(RE_SEQ.match(p.name).group(1)))

    # Racine du storyboard : Sequences.md seulement.
    seq_md = DOSSIER_STORYBOARD / "Sequences.md"
    for p in sorted(DOSSIER_STORYBOARD.iterdir()):
        if p.is_file() and p.name.lower() == "sequences.md":
            inclus.append(p)
            seq_md = p
        elif p.is_file() or not RE_SEQ.match(p.name):
            exclus.append(p.relative_to(DOSSIER_STORYBOARD).as_posix())
    if not seq_md.is_file():
        ecarts.append("Sequences.md absent de la racine de Storyboard")

    for d in seq_dossiers:
        a_speech = False
        for p in sorted(d.iterdir()):
            rel = p.relative_to(DOSSIER_STORYBOARD).as_posix()
            if not p.is_file():
                exclus.append(rel + "/")
                continue
            m_txt, m_img = RE_TXT.match(p.name), RE_IMG.match(p.name)
            if p.name.lower() == "speech.txt":
                inclus.append(p)
                a_speech = True
                speech[d.name] = p
            elif m_txt:
                n = int(m_txt.group(1))
                if n in txt:
                    ecarts.append("Plan%d.txt en double (%s et %s)"
                                  % (n, txt[n][0].name, d.name))
                txt[n] = (d, p)
                inclus.append(p)
            elif m_img:
                n = int(m_img.group(1))
                if n in img:
                    ecarts.append("image du plan %d en double (%s et %s)"
                                  % (n, img[n][1].name, p.name))
                img[n] = (d, p)
                inclus.append(p)
            else:
                exclus.append(rel)
        if not a_speech:
            ecarts.append("speech.txt absent de " + d.name)

    # Controles de structure.
    if len(seq_dossiers) != NB_SEQUENCES:
        ecarts.append("%d dossiers sequenceN trouves, %d attendus"
                      % (len(seq_dossiers), NB_SEQUENCES))
    attendus = set(range(1, NB_PLANS + 1))
    manque_txt = sorted(attendus - set(txt))
    manque_img = sorted(attendus - set(img))
    if manque_txt:
        ecarts.append("PlanN.txt manquants : " + ", ".join(map(str, manque_txt)))
    if manque_img:
        ecarts.append("images manquantes : "
                      + ", ".join("plan%d" % n for n in manque_img))
    en_trop = sorted((set(txt) | set(img)) - attendus)
    if en_trop:
        ecarts.append("plans hors 1.." + str(NB_PLANS) + " : "
                      + ", ".join(map(str, en_trop)))
    for n in sorted(set(txt) & set(img)):
        if txt[n][0] != img[n][0]:
            ecarts.append("plan %d : texte dans %s, image dans %s"
                          % (n, txt[n][0].name, img[n][0].name))
    for n in sorted(set(img) - set(txt)):
        ecarts.append("image du plan %d sans PlanN.txt" % n)

    stats = {"sequences": len(seq_dossiers), "txt": len(txt),
             "images": len(img), "speech": len(speech)}
    return inclus, exclus, ecarts, stats


def creer_zip(fichiers):
    if FICHIER_ZIP.exists():
        FICHIER_ZIP.unlink()
    with zipfile.ZipFile(FICHIER_ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(fichiers):
            arc = "Storyboard/" + p.relative_to(DOSSIER_STORYBOARD).as_posix()
            z.write(p, arc)
    with zipfile.ZipFile(FICHIER_ZIP) as z:
        if z.testzip() is not None:
            raise RuntimeError("zip corrompu")
    return FICHIER_ZIP.stat().st_size


def git(args, cwd):
    r = subprocess.run(["git"] + args, cwd=str(cwd), capture_output=True,
                       text=True, encoding="utf-8", errors="replace",
                       timeout=900,
                       env=dict(__import__("os").environ,
                                GIT_TERMINAL_PROMPT="0"))
    return r.returncode, masquer((r.stdout or "") + (r.stderr or "")).strip()


def pousser():
    """Depot neuf, un seul commit, push force. Retourne (ok, message)."""
    if shutil.which("git") is None:
        return False, "git est introuvable sur cet ordinateur."
    url = DEPOT_URL
    if GITHUB_TOKEN:
        url = DEPOT_URL.replace("https://",
                                "https://x-access-token:" + GITHUB_TOKEN + "@", 1)
    tmp = Path(tempfile.mkdtemp(prefix="storyboard_push_"))
    try:
        shutil.copy2(FICHIER_ZIP, tmp / "Storyboard.zip")
        for etape in (["init", "-q"],
                      ["symbolic-ref", "HEAD", "refs/heads/" + BRANCHE],
                      ["add", "Storyboard.zip"],
                      ["-c", "user.name=Storyboard Script",
                       "-c", "user.email=storyboard@local",
                       "commit", "-q", "-m", "Storyboard.zip"]):
            code, sortie = git(etape, tmp)
            if code != 0:
                return False, "git " + etape[-1 if etape[0] == "-c" else 0] \
                    + " a echoue : " + sortie
        code, sortie = git(["-c", "http.postBuffer=524288000", "push",
                            "--force", url, "HEAD:refs/heads/" + BRANCHE], tmp)
        if code != 0:
            return False, "push refuse : " + sortie
        code, local = git(["rev-parse", "HEAD"], tmp)
        code2, distant = git(["ls-remote", url, "refs/heads/" + BRANCHE], tmp)
        if code != 0 or code2 != 0 or not distant.startswith(local.strip()):
            return False, ("push passe, mais la branche distante ne montre pas "
                           "le commit attendu : " + distant)
        return True, "commit " + local.strip()[:8] + " present sur " + BRANCHE
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    if not DOSSIER_STORYBOARD.is_dir():
        afficher("ERREUR : dossier introuvable : " + str(DOSSIER_STORYBOARD))
        afficher("Verifie PROJET en haut du script.")
        return

    fichiers, exclus, ecarts, stats = selectionner()
    afficher("Selection : %d dossiers sequence, %d PlanN.txt, %d images, "
             "%d speech.txt (%d fichiers au total)."
             % (stats["sequences"], stats["txt"], stats["images"],
                stats["speech"], len(fichiers)))
    if exclus:
        afficher("\nFICHIERS EXCLUS (non envoyes) :")
        for e in exclus:
            afficher("  - " + e)
    if ecarts:
        afficher("\nECARTS DE STRUCTURE :")
        for e in ecarts:
            afficher("  - " + e)
        if not FORCER:
            afficher("\nRien n'est envoye. Corrige les ecarts, ou mets FORCER = True.")
            return
        afficher("\nFORCER = True : on continue malgre les ecarts.")

    taille = creer_zip(fichiers)
    afficher("\nZip cree : %s (%.1f Mo)" % (FICHIER_ZIP, taille / 1048576.0))
    if taille >= TAILLE_MAX:
        afficher("ERREUR : le zip depasse 100 Mo, limite de GitHub. Rien n'est envoye.")
        return

    ok, message = pousser()
    if ok:
        afficher("Envoi reussi : " + message)
        afficher("Depot : " + DEPOT_URL)
        afficher("Lien direct : " + LIEN_DIRECT)
        if not (exclus or ecarts):
            afficher("Aucun ecart.")
    else:
        afficher("ENVOI ECHOUE : " + message)
        afficher("Storyboard.zip reste en place : " + str(FICHIER_ZIP))
        afficher("Si c'est un probleme d'identifiants, renseigne GITHUB_TOKEN.")


if __name__ == "__main__":
    main()
```

Après l'envoi, je te dis que c'est fait. Le lien de téléchargement direct est :
`https://github.com/officecenter632-maker/Storyboard/raw/main/Storyboard.zip`
Page du dépôt (branche `main`) : `https://github.com/officecenter632-maker/Storyboard`
Exemple : `curl -L -o Storyboard.zip https://github.com/officecenter632-maker/Storyboard/raw/main/Storyboard.zip`

### Ce que tu fais : cloner et contrôler le storyboard

1. Tu **télécharges** `Storyboard.zip` depuis le dépôt `Storyboard` (`git clone --depth 1 https://github.com/officecenter632-maker/Storyboard.git`, ou `curl -L` au lien direct), tu **gardes la copie** dans ton espace de travail et tu notes le nom exact du zip et de son dossier racine.
2. **Structure (par programme)** : le zip s'ouvre sans erreur ; 51 dossiers `sequenceN` ; 64 fichiers `PlanN.txt` ; **64 images** (une par plan, dans le bon dossier de séquence, extension réelle notée : `.webp` ou `.png`, majuscules ou minuscules du nom comprises) ; un `speech.txt` par séquence. Tu compares à `Sequences.md`.
3. **Images suspectes (par programme).** Tu repasses **toi-même** les mêmes contrôles que le script d'envoi sur les 64 images clonées : illisible, **entièrement noire ou blanche**, fichier minuscule, aplat uni, dimensions différentes de la majorité, format réel différent de l'extension. Tu ne te fies pas à ce que le script a déjà dit : tu le refais sur la copie téléchargée. Une image **noire ou blanche** n'est jamais acceptée comme « fond uni » sans que le `PlanN.txt` l'annonce (couleur noire ou blanche demandée).
4. **Images qui ne correspondent pas à leur plan (à l'œil).** Tu fabriques des **planches-contact numérotées** (12 plans par planche, le numéro écrit sur chaque image) et tu compares chaque image à la ligne « CE QUE LE PLAN REPRÉSENTE » et à « IMAGES À JOINDRE » de son `PlanN.txt` : bon décor, bons personnages, bons objets, texte parasite, élément manquant, élément d'un autre plan (par exemple une constellation avec un point d'interrogation sur un plan qui devait montrer la règle de vitesse seule), fond de la mauvaise couleur, plan qui reprend un autre plan mais qui n'en a pas le décor.
5. **Écarts** : image manquante, image en trop, plan dans le mauvais dossier, image illisible, **image noire, blanche ou vide**, **image qui ne correspond pas à son plan**. Tu me les signales **avant** de commencer l'analyse, dans un tableau `Plan | Problème | Gravité | Action` (les actions possibles : « à regénérer », « à confirmer par moi », « acceptable, noté dans les points à trancher »). Tu n'analyses jamais un plan dont l'image manque, est noire, blanche ou vide : on le traite d'abord, c'est-à-dire que **je regénère l'image, je la repose dans `Storyboard`, je relance `envoyer_storyboard.py`** et tu re-télécharges. Les plans concernés sont marqués « image à regénérer » dans `asset_profond_status.md` et dans le registre, **sans bloquer les autres plans**. **Dans la même réponse que ce tableau, tu me livres directement le fichier `reinitialisation_imgen.html`** (zones de copie des JSON de réinitialisation d'ImGen, voir la sous-section suivante) : je ne te le demande pas.

   **Deux sortes d'écarts, deux traitements.**
   - **Bloquant : à regénérer.** L'image manque, est illisible, **noire, blanche ou vide**, ou **n'a aucun rapport avec son plan** (mauvais décor, scène d'un autre plan). Seuls ces plans vont dans `reinitialisation_imgen.html` et sont marqués « image à regénérer ».
   - **Détail gênant : tu le corriges toi-même, dans les prompts.** Un texte ou un chiffre dessiné par erreur (par exemple le « 13 » du numéro d'asset de Plan56), un élément coupé par le cadre (le masque comique de Plan41), un élément en trop, en moins ou déformé, une mauvaise pose, une flèche mal orientée, un décor un peu différent (la maison avec parabole de Plan22, les deux propriétaires de Plan24, le combiné radio de Plan55). **Je ne regénère pas ces images** et tu ne me demandes pas de le faire : tu les listes dans le tableau avec l'action **« corrigé dans les prompts »** et tu appliques la règle de la sous-section « Défauts de détail » plus bas.

### Réinitialiser les images à regénérer : le fichier `reinitialisation_imgen.html`

Dès que le tableau des écarts contient au moins un plan « à regénérer » (ou « à confirmer par moi »), tu me livres **dans la même réponse, sans que je le demande**, un fichier **`reinitialisation_imgen.html`**. C'est une page web autonome que j'ouvre dans mon navigateur : elle contient, pour chaque vague, **une zone de texte avec le JSON de réinitialisation et un bouton « Copier »**. Je colle ensuite ce JSON dans ImGen (bouton **« ↺ Réinitialiser par JSON… »**, à côté de « Réinitialiser »). Je n'ai jamais à écrire ni à retoucher un JSON à la main.

**Le JSON, tel qu'ImGen l'accepte (`parse_reset_json`)**

```
{
  "projet": "nom du projet",
  "reinitialiser": [
    { "nom": "Plan17", "raison": "ne correspond pas au prompt (devait être un fond seul)" },
    { "nom": "Plan20", "raison": "image noire" }
  ]
}
```

- `reinitialiser` : liste non vide. Chaque entrée est soit un nom (`"Plan17"`), soit un objet `{"nom", "raison"}`. **Tu mets toujours une raison**, courte et précise : elle est écrite dans le journal de l'image.
- `projet` : le nom exact du projet ImGen (celui de `projet_imgen.json`, par exemple `6-musk_starlink_storyboard`). ImGen refuse le JSON si le nom ne correspond pas au projet ouvert. Si tu n'as pas le `projet_imgen.json` sous la main, tu omets le champ et tu me le dis en une ligne.
- Les noms viennent **exactement** du `projet_imgen.json` (`Plan17`, jamais `plan 17`). Aucun doublon.

**Les vagues (obligatoires quand il y a une dépendance)**

ImGen ne tient pas compte des dépendances : si un plan joint en `local` l'image d'un plan réinitialisé en même temps, un bot peut le générer avec **l'ancienne image fautive**. Tu lis donc les `references.local` de `projet_imgen.json` et tu ranges les plans ainsi :

| Vague | Contenu | Quand je la colle |
| --- | --- | --- |
| **Vague 1** | Les plans « à regénérer » : seulement les écarts **bloquants** (images noires, blanches, vides, illisibles, sans rapport avec leur plan). **Jamais un simple détail gênant** : il se corrige dans les prompts | Tout de suite |
| **Vague 2** (et suivantes) | Les plans qui reprennent en `local` l'image d'un plan de la vague précédente (la dépendance est suivie de proche en proche) | Seulement quand la vague précédente est regénérée **et que je l'ai regardée** |
| **À confirmer** (zone facultative) | Les plans « à confirmer par moi » : seulement si un écart de détail me paraît quand même assez grave pour regénérer l'image (par défaut, il est corrigé dans les prompts) | Seulement si je décide de les regénérer ; **un plan de cette zone n'est jamais mis dans une vague sans ma confirmation** |

S'il n'y a aucune dépendance, il n'y a qu'une vague : tu ne crées pas de vague vide. Si un plan facultatif de la vague 2 a une image qui paraît correcte (il a seulement été généré avec une mauvaise référence), tu le marques « facultatif » dans sa raison et dans la carte.

**Le contenu de la page**

- Un en-tête : nom du projet, date, nombre de plans par vague.
- **Une carte par vague** : titre (« Vague 1 : à coller maintenant »), la condition de collage en une phrase, un petit tableau `Plan | Raison` (pour que je voie ce que je réinitialise), puis la **zone de texte en lecture seule** contenant le JSON, et le bouton **« Copier »**. Le bouton affiche « Copié ✓ » après le clic. Si la copie automatique est refusée par le navigateur, la zone se sélectionne entièrement pour un Ctrl+C.
- Une carte « À confirmer » si elle existe, visuellement distincte (bordure en pointillés).
- **Un avertissement par plan dont le prompt est lui-même la cause de l'erreur** (par exemple un texte écrit dans le prompt que le modèle a dessiné tel quel) : réinitialiser relancerait le même prompt et le même défaut. Dans ce cas, tu me livres **d'abord** le `PlanN.txt` corrigé et l'entrée JSON de `projet_imgen.json` correspondante (voir « Corrections », étape 8) et tu l'écris en haut de la carte.
- Une seule page HTML, **CSS et JavaScript dans le même fichier**, encodage UTF-8, **aucune ressource externe** (ni police, ni script, ni image distante) ; lisible en mode clair et en mode sombre ; zone de texte en police à chasse fixe.

**Structure imposée de la page (c'est le modèle livré et validé, tu le reprends tel quel).** Chaque carte de vague contient, dans cet ordre : le titre, la condition de collage en une phrase, l'avertissement éventuel (encadré orangé), le tableau `Image | Raison`, **une zone de texte `<textarea id="jN" readonly spellcheck="false">`** avec le JSON (échappé pour le HTML), puis **un seul bouton `<button id="bN" type="button">Copier</button>`**. Une seule zone et un seul bouton par vague, jamais de `<form>`.

**LE PIÈGE À ÉVITER : le bouton « Copier » qui ne fait rien.** Je double-clique sur ce fichier : il s'ouvre **depuis le disque (`file://`)**, et dans ce cas **les navigateurs bloquent souvent l'API moderne `navigator.clipboard.writeText`** (elle exige une page « sécurisée »). Une page qui n'utilise que cette API **ne copie rien, sans aucun message d'erreur** : c'est exactement ce qui s'est produit une fois. Règles obligatoires :
1. **Tu essaies d'abord la copie classique** : `t.focus(); t.select(); t.setSelectionRange(0, t.value.length); document.execCommand("copy")`. Elle fonctionne en fichier local, sur une zone `readonly` sélectionnée, et doit être appelée **directement dans le gestionnaire du clic** (jamais après un `await`, un `setTimeout` ou une promesse).
2. **Tu n'utilises `navigator.clipboard.writeText` qu'en plan B**, si `execCommand` renvoie `false`.
3. **Si les deux échouent**, la zone reste **sélectionnée** et le bouton affiche « Sélectionné : Ctrl+C » : je ne dois jamais rester devant un bouton muet.
4. Le bouton affiche « Copié ✓ » seulement quand la copie a **réellement** réussi, puis revient à « Copier » après 2 secondes.

Gestionnaire à recopier tel quel (adapter seulement les `id`) :

```javascript
document.getElementById("b1").addEventListener("click", function () {
  var t = document.getElementById("j1"), b = this;
  function fait() { b.textContent = "Copié ✓"; setTimeout(function () { b.textContent = "Copier"; }, 2000); }
  function selectionner() { t.focus(); t.select(); t.setSelectionRange(0, t.value.length); }
  function plan_b() {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t.value).then(fait, function () { selectionner(); b.textContent = "Sélectionné : Ctrl+C"; });
    } else { selectionner(); b.textContent = "Sélectionné : Ctrl+C"; }
  }
  selectionner();
  var ok = false;
  try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
  if (ok) { fait(); } else { plan_b(); }
});
```

**Ce que tu contrôles par programme avant de livrer**

1. Les JSON sont **générés par un script** (`json.dumps(..., ensure_ascii=False, indent=2)`), jamais tapés à la main, puis insérés dans la page **échappés pour le HTML** (`html.escape`). Tu relis le fichier produit et tu extrais chaque zone : le texte extrait est **identique** au JSON généré.
2. Chaque JSON passe dans la fonction **`parse_reset_json`** d'`ImGen.pyw` (il s'importe sans interface) avec la liste réelle des noms du projet : **aucune erreur**, **aucun avertissement** « absent du projet », et la liste de noms retournée est exactement celle de la vague.
3. Aucun plan n'apparaît dans deux vagues ; aucun plan de la vague N+1 ne dépend d'un plan qui n'est pas dans une vague précédente ; chaque raison est non vide.
4. Le nombre de plans de la page égale le nombre de plans « à regénérer » du tableau des écarts (plus, séparément, ceux « à confirmer »).
5. **Le bouton « Copier » est contrôlé** : le script JavaScript de la page passe `node --check` (aucune erreur de syntaxe), il appelle `document.execCommand("copy")` **avant** `navigator.clipboard`, et chaque bouton a sa zone (`id` correspondants). Tu me dis honnêtement si tu n'as pas pu l'essayer dans un vrai navigateur.

**Livraison.** Le fichier `reinitialisation_imgen.html` est livré **seul**, avec en deux lignes : la consigne (« ouvre le fichier, clique sur Copier sur la vague 1, colle dans ImGen ») et le bilan (nombre de plans par vague, plans dont le prompt doit d'abord être corrigé). Quand j'ai regénéré et regardé une vague, tu **mets à jour** la page (la vague faite disparaît ou est marquée « faite »), toujours dans le même fichier et sans que je le demande. Une même relance de contrôle (nouveau `Storyboard.zip` téléchargé) qui trouve de nouveaux plans à regénérer produit une **nouvelle version** du fichier, qui reprend les vagues non faites.

### Porte avant l'analyse : la mise à jour du dépôt `Storyboard` est-elle faite ?

**Avant de passer à la passe d'inventaire et à la rédaction des prompts d'animation (la suite de l'étape 9), tu t'assures que le dépôt `Storyboard` contient bien les images à jour.** Tant que des plans sont « image à regénérer » (ou « à confirmer » que j'ai décidé de regénérer), tu ne démarres pas l'analyse de ces plans : tu ne dois jamais écrire de prompt à partir d'une image périmée.

Chaque fois que je reviens vers toi (même pour une autre question) alors que des plans étaient « à regénérer », tu fais ce contrôle, dans cet ordre :

1. **Tu me demandes si j'ai regénéré ces images entre-temps** (une seule question, la liste des plans concernés).
2. **Si oui, tu me renvoies le code de mise à jour : `envoyer_storyboard.py`, en entier, dans un seul bloc de code** (même script que celui déjà livré, avec les chemins réels). Je n'ai pas à te le redemander et tu ne me dis pas « relance le script que tu as déjà » : tu le redonnes. Consigne en une ligne : « repose les nouvelles images dans `Storyboard`, lance ce script par Run, puis dis-moi quand c'est fait ». Si l'arborescence a changé depuis, tu me demandes la nouvelle arborescence **avant** de rééditer le script.
3. **Quand je te signale que c'est poussé**, tu **re-télécharges** `Storyboard.zip` (nouveau clone, pas l'ancienne copie) et tu **refais les contrôles** : structure (51 séquences, 64 `PlanN.txt`, 64 images, 51 `speech.txt`), images suspectes par programme, puis, à l'œil, **les plans regénérés** (planche-contact numérotée), plus ceux qui les reprennent en `local`.
4. **Tu me rends le verdict** : chaque plan regénéré est soit « validé » (plus aucun écart), soit de nouveau « à regénérer » (une nouvelle version de `reinitialisation_imgen.html` reprend alors les vagues non faites, avec une raison à jour). Tu mets à jour `asset_profond_status.md` dans la même réponse.
5. **Tu ne passes à la passe d'inventaire que lorsqu'il ne reste aucun plan « à regénérer » bloquant** : ou que je t'ai dit explicitement de continuer sans eux. Dans ce dernier cas, les plans non traités restent marqués « image à regénérer » dans le registre et dans `asset_profond_status.md`, et tu n'écris aucun prompt pour eux.

**Si je n'ai rien regénéré**, tu le notes en une ligne et tu continues sur les autres plans, **sans bloquer** (règle déjà posée plus haut). **Si je dis avoir regénéré mais que je n'ai pas poussé**, tu ne te fies pas à ma parole : le nouveau téléchargement montre que les images n'ont pas changé, et tu me renvoies le code de mise à jour.

### Défauts de détail : tu les corriges dans les prompts, je ne regénère rien

Une image de storyboard n'est qu'une **référence visuelle** : elle sert à générer les assets et les fonds d'animation, pas à être livrée telle quelle. Un défaut de détail qui ne la rend pas inutilisable **ne justifie donc jamais une regénération** : c'est **toi** qui le corriges quand tu écris le prompt de l'asset ou du fond concerné. Je n'ai pas à y penser.

**Ce que tu fais, sans rien me demander :**
1. **Tu repères** le défaut pendant l'inventaire et la visualisation du plan (texte ou chiffre dessiné, élément coupé, en trop, en moins, déformé, mauvaise pose, mauvaise orientation, décor différent du prompt d'origine).
2. **Tu écris la correction dans le prompt** de chaque génération concernée, en toutes lettres : ce qu'il faut **retirer** (« aucun chiffre, aucune lettre, aucun texte »), **compléter** (« l'élément est entier, non coupé, avec de la marge »), **remplacer** (« un seul propriétaire, de dos, derrière le téléphone ») ou **réorienter** (« la flèche part du propriétaire »). Le prompt décrit **ce que le plan devait montrer** (ligne « CE QUE LE PLAN REPRÉSENTE » de `PlanN.txt`), pas le défaut de l'image. Tu ne recopies jamais le défaut.
3. **Tu choisis le plan source** en tenant compte du défaut : si l'asset apparaît net et correct dans un autre plan, tu le prends comme source (voir « Choisir le plan source »).
4. **Tu les notes** dans une section du registre, **G. Détails corrigés dans les prompts** : un tableau `Plan | Défaut vu | Correction écrite dans le prompt | Générations concernées`. C'est une trace, **pas une question** : tu ne les mets pas dans « Points à trancher ».
5. **Dans `asset_profond_status.md`**, le plan reste « à faire » (puis « fait et livré »), avec dans « Remarque » : « détail corrigé dans le prompt : … ».

Cette règle remplace « image à regénérer » pour tout ce qui n'est pas bloquant. Si, **malgré** la correction écrite dans le prompt, le défaut revient sur une image que je génère, c'est **moi** qui te le signale ; tu renforces alors le prompt (et tu mets à jour le JSON), sans que je regénère le storyboard.

### Passe d'inventaire : décider l'ajustement technique de chaque asset, AVANT tout prompt

**Les assets généraux, on les connaît déjà** : ce sont ceux de `Liste_assets.md`, générés à l'étape 5 (`assetsBrute1`). Cette passe **ne refait pas l'inventaire de base**. Elle sert à **ajuster techniquement** chaque asset à la configuration exacte dans laquelle le storyboard l'utilise : sa pose, son état, sa taille, ce qui le cache, et surtout **ce qu'il fait dans la scène**. Selon ce rôle, un asset est conservé tel quel, ou **décomposé en éléments séparés** que nous reconstituons nous-mêmes et manipulons comme nous voulons, ou **décliné en feuille de sprites** (une suite d'images), ou **remplacé par une animation écrite en code** (générée par IA), ou décliné en une nouvelle configuration. Cette décision se prend **une fois par asset, sur tous les plans où il apparaît**, pas plan par plan : c'est ce qui rend le découpage cohérent d'un plan à l'autre et ce qui permet de ne générer qu'une fois ce qui est identique.

**Tant que le registre n'est pas écrit et livré, tu n'écris aucun prompt, aucun JSON, aucune fiche de plan. Tu n'attends en revanche pas ma validation : une fois le registre livré, tu enchaînes immédiatement sur l'analyse plan par plan puis sur les lots.**

**1. Parcourir les 64 plans, dans l'ordre, asset par asset.** Les assets de départ sont ceux de `Liste_assets.md` (éléments clés et petits éléments des planches), **plus** ce que l'image montre et que la liste ne contient pas : les **fonds** (cartons, aplats, décors), les **variantes** (le propriétaire en chemise au lieu du costume, la foule en groupes ou les bras levés, le pouce qui appuie ou levé, la télécommande tenue par une vraie main) et les objets non listés (mains qui signent, chemin pointillé…). **L'image fait foi** : une apparition annoncée par la liste mais absente de l'image n'est pas comptée, et une apparition visible mais non annoncée l'est. Des **planches-contact numérotées** sont permises pour comparer les plans entre eux ; l'analyse détaillée de l'étape suivante reste un plan à la fois. Pour chaque apparition, tu notes :

- la **configuration vue** : pose ou état, orientation, taille et cadrage, ce qui le cache ou ce qu'il cache ;
- son **rôle dans la scène** : il bouge (comment : mouvement rigide, déformation, cycle, tracé, pulsation), il apparaît ou disparaît, il change d'état, il est animé avec un autre élément, il reste immobile, il sert de décor ;
- ce qui le **relie aux autres** (il tient un objet, il est devant ou derrière un autre élément, il est relié par un câble).

**2. Décider la technique, pour chaque asset.** Chaque apparition reçoit **une technique** parmi les six ci-dessous (un même plan peut en combiner plusieurs, une par élément). Les techniques sont classées **du plus simple au plus coûteux** ; tu prends **la plus simple qui donne le mouvement voulu**.

| Technique | Quand | Ce qu'on fabrique | Qui l'anime |
| --- | --- | --- | --- |
| **1. Tel quel** | L'asset sert en un seul morceau : il apparaît, se déplace, change de taille, se retourne ou s'efface comme un tout | Une génération, et des **réglages de montage** (position, taille, miroir, rotation, voile). Le même asset vu **dans la même configuration** dans plusieurs plans n'est généré qu'**une fois** | Le logiciel de montage |
| **2. Séparé pour le calque** | Un autre élément passe **devant** lui et le cache en partie (bureau devant un personnage, chaise derrière) | L'élément de devant devient un **calque séparé**, même s'il est immobile | Le logiciel de montage |
| **3. Décomposé en éléments séparés** | Une partie bouge **indépendamment**, par un **mouvement rigide** autour d'un point d'attache : rotation (bras, tête, porte, aiguille), translation, bascule ; ou deux parties arrivent à des moments différents | Une génération **par sous-asset** (ou par groupe de sous-assets compatibles). Chaque sous-asset a : son nom, son **point d'attache** (épaule, cou, charnière…), sa **zone cachée à reconstruire**, son **mouvement attendu** (axe, amplitude, durée) et son **calque** | **Nous** : nous reconstituons l'asset dans le logiciel de montage (hiérarchie, point de pivot) et le manipulons comme nous le souhaitons |
| **4. Animation par code** | L'élément est **géométrique, répétitif ou calculable**, et une image générée serait un mauvais outil : trait qui se trace, pointillés qui avancent, jauge ou barres qui se remplissent, signal qui pulse, particules (cœurs qui montent), compteur, effet de pixellisation progressive, traînées qui dérivent, très grande foule dont chaque silhouette bouge | **Pas d'image** : une **fiche de code** (cahier des charges) que l'IA transformera en code d'animation (SVG, CSS, JavaScript, Lottie ou script du logiciel de montage), sur fond transparent | Le code, écrit par l'IA, puis intégré au montage |
| **5. Feuille de sprites** | L'élément change de **forme** de façon que des parties rigides ne peuvent pas rendre : cycle (marche, hélices qui tournent, clignement), états successifs d'un même dessin (cases barrées une à une, expression qui change), déformation | **Une seule image** qui contient une suite de **4 à 12 images successives** en grille, cellules de même taille, même cadrage et même ancrage, séparées par un vide net. On la découpe ensuite en images que l'on **joue à la cadence voulue** | Le logiciel de montage (lecture d'images) |
| **6. Nouvelle configuration** | La pose, l'état ou l'angle vus **n'existent pas** dans l'asset de départ et ne s'obtiennent ni en bougeant des sous-assets ni par une feuille de sprites (de dos au lieu de face, autre tenue, ouvert au lieu de fermé) | Une **nouvelle génération**, rattachée au même asset, avec le **même cadrage, la même taille et le même point d'ancrage** que sa configuration de base | Le logiciel de montage |

**Comment choisir entre elles.**
- Un **mouvement rigide** autour d'une articulation → **décomposer** (3), jamais une feuille de sprites.
- Un **dessin riche qui change de forme** (visage, tissu, objet qui se déforme) → **feuille de sprites** (5).
- Un élément **géométrique ou répétitif** (lignes, barres, jauges, pointillés, particules, foule de silhouettes identiques) → **code** (4), plus net, plus léger et plus modifiable qu'une image. Le code reprend les **couleurs et le style en aplats** du plan ; il n'invente aucun élément.
- Quand deux techniques donnent le même résultat, tu prends la plus simple. **La décomposition suit le mouvement, jamais l'inverse** : un asset n'est découpé que si quelque chose le justifie (une partie qui bouge, qui arrive à un autre moment, ou un calque à intercaler). Chaque découpe, chaque feuille de sprites ajoute des générations à produire et un risque que les morceaux ou les images ne se raccordent pas.
- Pour décider, tu t'appuies sur la voix off, sur la ligne « CE QUE LE PLAN REPRÉSENTE », sur le scénario (`Plan_animation.md`, colonne « Visuel et caméra ») puis sur les plans voisins.

**Continuité entre deux plans.** Quand deux plans consécutifs montrent le même asset dans deux configurations (l'opérateur assis droit, puis penché la main sur la tête), tu regardes si on passe de l'une à l'autre **en animant des sous-assets** (le bras et la main qui montent) plutôt qu'en remplaçant une image par l'autre. Si oui, l'asset est **décomposé une fois**, et les deux plans utilisent les mêmes sous-assets. Sinon, c'est une **substitution** (coupe) et la seconde configuration est une nouvelle génération.

**Un seul ajustement par asset.** La décomposition (ou la feuille de sprites, ou la fiche de code) est définie **une fois** pour l'asset, sur le plan le plus exigeant (celui qui demande le plus de parties séparées, d'images ou de comportements) ; les autres plans l'utilisent, avec les parties inutiles laissées immobiles. Les points d'attache, les calques, les tailles et les ancrages sont **les mêmes d'un plan à l'autre**.

**Fonds.** Un même décor qui revient (même cadrage, teinte un peu changée ou assombrie) est **un seul fond**, généré une fois, **assez large pour le plan le plus exigeant** (zoom, recul, déplacement de caméra). Ce qui change dessus est un asset, un état, un effet de code ou de montage. Un décor vu sous un autre angle est un autre fond.

**Un doute** entre deux techniques, ou entre « nouvelle configuration » et « réutilisation avec retouche de montage », se tranche en faveur de la **solution la plus simple**, sauf si le mouvement annoncé est irréaliste ainsi ; tu le notes alors dans « Points à trancher » du registre.

**3. Choisir le plan source.** Chaque asset, sous-asset, feuille de sprites et configuration est **généré une seule fois**, dans le dossier du **plan source** : celui où il se voit **le plus net, le plus complet et le moins caché**. Par défaut, c'est sa **première apparition** ; tu prends un plan plus tardif seulement si la première est nettement moins bonne (partiellement caché, très petit, pixellisé, en transition). La génération part de **l'image de ce plan, seule référence** (règle des JSON), et **tous les sous-assets d'un même asset sont générés à partir de la même image de plan**, pour garder la même main de dessin. Les autres plans utilisent ce qui est généré, sans rien régénérer. Un élément **en code** n'a pas de plan source d'image : sa fiche de code est écrite une fois, dans le dossier du premier plan où il apparaît.

**4. Livrer `Registre_elements_animation.md`**, **avant le lot 1**, avec ces sections :

- **A. Résumé** : nombre d'assets, de fonds, d'assets décomposés, de sous-assets, de feuilles de sprites, d'éléments en code, de nouvelles configurations, et de générations économisées par rapport à « tout régénérer plan par plan ».
- **B. Fonds** : un tableau `ID | Fond | Teinte | Plan source (génération) | Plans qui l'utilisent | Retouche de montage par plan | Largeur demandée`.
- **C. Assets**, **une sous-section par asset** (celui de `Liste_assets.md`, avec son numéro, ou son nom si ajouté) :
  - un tableau **une ligne par plan** : `Plan | Configuration vue | Rôle dans la scène | Technique (1 à 6) | Génération (JSON prévu, fiche de code prévue, ou « réutilise PlanN/NN_nom ») | Retouche de montage` ;
  - si l'asset est **décomposé** : un **schéma de décomposition** (la liste des sous-assets, leur hiérarchie, le **point d'attache** de chacun, la **zone cachée à reconstruire**, le **mouvement attendu**, l'ordre des calques) ;
  - si l'asset est une **feuille de sprites** : la **grille** (colonnes × lignes), le **nombre d'images**, la **taille de cellule**, l'**ancrage**, la **cadence** (images par seconde), **boucle ou non**, et la **description image par image** ;
  - si l'asset est **en code** : la **fiche de code** (voir plus bas), ou sa référence.
- **D. Assets à usage unique** : ce qui n'apparaît que dans un plan (liste courte : plan, élément, technique).
- **E. Plans à regénérer** : les plans dont l'image du storyboard est suspecte (voir « cloner et contrôler le storyboard »), exclus de l'analyse.
- **F. Points à trancher** : tous les doutes de décision, y compris les choix de technique.
- **G. Détails corrigés dans les prompts** : les défauts de détail vus sur les images du storyboard (voir « Défauts de détail »), plan par plan, avec la correction écrite dans le prompt. Ce sont des décisions déjà prises, pas des questions.

**Fiche de code** (un fichier `NN_nom_code.md` dans le dossier du plan, jamais un JSON d'image). Elle contient : **ce que l'élément fait** (comportement, mouvement, rythme), les **paramètres modifiables** (durée, cadence, nombre d'éléments, amplitude, couleurs en codes), la **position et la taille** dans l'image (en % comme pour un asset), le **moment d'entrée et de sortie** dans le plan, la **sortie attendue** (animation sur fond transparent, format et dimensions) et le **style** (aplats, mêmes couleurs que le plan, aucun texte, aucun logo). Elle est assez précise pour qu'on la donne telle quelle à une IA qui écrira le code.

**5. Aucune validation bloquante : tu enchaînes.** Tu me livres le registre (je le lis quand je veux, il ne bloque rien) et tu passes **tout de suite** à l'analyse plan par plan, sans me demander « ok ». Le registre est **la référence** : l'analyse plan par plan s'y plie. Une décision de technique se répercute sur tous les plans où l'asset apparaît : si je te corrige le registre plus tard, tu mets à jour **tous** les plans, fiches et JSON concernés. Si l'analyse d'un plan montre qu'il faut corriger le registre (un mouvement qui exige un sous-asset de plus, une feuille de sprites au lieu d'un découpage), tu le notes dans « Points à trancher », tu mets le registre à jour avec les plans concernés et tu continues.

### Ce que tu fais : visualiser chaque plan, un par un

Une fois le registre livré (sans attendre ma validation), tu regardes **l'image de chaque plan, de Plan1 à Plan64, une par une** (jamais plusieurs plans d'un coup, jamais de mémoire), en gardant le registre ouvert : pour chaque chose visible, tu dis si elle est **générée ici** ou **réutilisée d'un autre plan**. Pour chacun, tu croises : **l'image**, son `PlanN.txt` (voix off, « ce que le plan représente », « fait au montage ») et le `speech.txt` de sa séquence.

**Le plan et le speech ne se calquent pas exactement.** Une phrase de la voix off tombe dans un intervalle de temps qui peut chevaucher deux plans. Tu t'en sers pour **comprendre ce que la scène veut dire**, jamais pour caler un plan sur une phrase.

**Tu visualises la scène comme un film, pas comme une image isolée.** Tu pars de la fin du plan précédent et tu vas vers le début du suivant, et tu imagines ce qui se passe entre les deux : ce qui reste, ce qui part, ce qui arrive, et comment. L'image du plan n'est qu'une **référence visuelle** qui t'aide à voir la scène.

Avec cela, tu **anticipes ce qui sera dynamique** (ça bouge, apparaît, disparaît, change d'état) **et ce qui sera statique** (le fond). Règles :
- l'image fait foi pour ce qu'elle montre : tu **n'inventes aucun élément absent** et tu **n'oublies aucun élément visible**, **sauf un défaut de détail** (voir « Défauts de détail »), que tu **corriges dans le prompt** au lieu de le reproduire ;
- quand tu doutes d'un mouvement, tu choisis la **proposition la plus probable**, tu la notes dans « Points à trancher » et tu continues : tu ne me bloques pas ;
- si l'image montre autre chose que le prompt du `PlanN.txt` (élément en plus, en moins, déformé), tu le notes aussi dans « Points à trancher ».

**Chaque chose visible est classée dans une et une seule de ces catégories.** Le registre dit, pour chaque asset, laquelle de ses techniques s'applique ; ce tableau sert à classer ce qui n'est pas un asset (fond, forme, texte).

| Catégorie | Définition | Ce qu'on fabrique |
| --- | --- | --- |
| **FOND** | Le décor qui ne bouge pas : sol, murs, ciel, motif, couleur de fond, éléments fixes du décor | Une image de fond **vide**, pleine page, sans aucun élément mobile (pas de détourage) |
| **ASSET** | Tout élément qui **bouge, apparaît, disparaît, change d'état ou est animé séparément** : personnage, objet, icône, flèche dessinée, effet | Une image **sur fond détourable** (un élément, ou un groupe d'éléments générés ensemble) |
| **CODE** | Tout ce qui est **géométrique, répétitif ou calculable** et que le registre confie à une **animation écrite en code** par une IA (tracé, jauge, particules, pulsation, pixellisation…) | Une **fiche de code**, pas d'image |
| **MONTAGE** | Tout ce qui se fait dans le logiciel de montage : texte, étiquette, badge, tampon, logo, jauge, barre, pastille, cercle, ligne, flèche simple, règle graduée, voile, masque, ombre sous les pieds, mouvement de caméra | Rien à générer |

**Une forme géométrique simple** (rectangle, cercle, disque, ligne, flèche, trait pointillé, barre, croix, coche, coin de panneau, ellipse d'ombre) est **MONTAGE**, sauf si elle porte un dessin propre (ex. flèche en câble épais), ou si son animation est trop complexe pour le logiciel de montage (tracé, pulsation, répétition) : le registre la confie alors au **CODE**.

### Règles de découpage en générations

Un plan contient souvent plusieurs éléments. Tu les **scindes** en groupes d'éléments ou en éléments seuls. Une **génération** est une image à créer : un fond vide, un asset seul, ou un groupe d'assets.

1. **Un asset par chose qui bouge indépendamment.** Si deux éléments arrivent à des moments différents, ou vont dans des directions différentes, ce sont deux assets. Quatre groupes de foule qui s'allument un par un = quatre assets.
2. **Des éléments qui bougent toujours ensemble = un seul asset.** Une pile de caisses qui ne bouge pas en bloc ; un journal et son titre.
3. **Groupe de génération.** Plusieurs assets peuvent être générés **sur une même image** seulement s'ils sont de même famille, de taille voisine, séparés par un vide net, et si chacun reste net (4 à 6 au plus). Sinon, chacun a sa propre génération.
4. **Un personnage n'est découpé que si une partie est animée, et le découpage est celui du registre.** Il est défini une fois pour l'asset, sur tous ses plans, pas plan par plan. Un personnage figé = un asset. Un personnage dont un bras se lève ou dont la main va sur la tête = **parties séparées** (corps, tête, bras animé, main), chacune avec son nom, son point d'attache (épaule, cou) et la zone cachée à reconstruire.
5. **Un état qui change l'aspect = une génération par état**, ou une **feuille de sprites** quand les états sont nombreux (4 à 12) et se suivent comme une animation (écran vert puis gris, pose normale puis main sur la tête, cadenas fermé puis ouvert), avec le même cadrage, la même taille et le même point d'ancrage.
6. **Zones cachées.** Quand un élément en cache un autre dans l'image (personnage derrière un bureau, journal sous une main), tu notes **ce qui doit être reconstruit**.
7. **Le fond d'un plan est l'image du plan sans ses éléments dynamiques.** Tu listes ce qui doit disparaître, ce qui doit être reconstruit à la place, et si le fond doit **dépasser le cadre 16:9** (zoom, recul, déplacement de caméra) et de combien.
8. **Un élément qui revient dans plusieurs plans est généré une seule fois.** Son JSON se trouve dans le dossier de son **plan source** (voir le registre). Les autres plans n'ont **aucun JSON** pour cet élément : leur fiche écrit « réutilise `PlanN/NN_nom` » et indique la **retouche de montage** (position, taille, retournement, voile, contenu d'écran…). Un plan reçoit un **nouveau JSON** pour un élément déjà connu **seulement** si c'est une **variante** (règle 5 : autre pose, autre état). Le fond d'un décor qui revient est généré **une fois**, assez large pour le plan le plus exigeant.
9. **Un plan peut n'avoir aucun JSON.** Si tout ce qu'il contient est réutilisé ou fait au montage, son dossier contient seulement un fichier `_reutilise.txt` qui liste, une ligne par élément, ce qui est réutilisé et d'où (ou `_rien_a_generer.txt` si le plan est un aplat seul).

### Règles du fond détourable

Les assets (jamais les fonds) se génèrent sur un **fond uni détourable**. Chaque génération d'asset dit dans son prompt :

- **La couleur de détourage**, choisie **par génération** : vert pur `#00FF00` par défaut ; magenta `#FF00FF` si l'asset contient du vert ou du turquoise ; bleu pur `#0000FF` s'il contient du vert **et** du magenta. Elle ne doit apparaître **nulle part dans l'asset**, ni proche d'une de ses couleurs.
- **Aplat parfait** : aucune ombre portée, aucun dégradé, aucun halo, aucun sol. L'ombre sous les pieds des personnages est MONTAGE.
- **Marge** : l'asset est entier, jamais coupé, avec de la marge sur tous les côtés.
- **Transparence** : un halo, une zone translucide, une lueur ou un voile **ne se détourent pas**. Ils sont générés **opaques** ou, mieux, classés **MONTAGE**.

### Ce que tu me livres : l'archive de prompts

**Une archive par lot**, `animation_lot_NN.zip` (`animation_lot_01.zip`, `animation_lot_02.zip`…), d'environ 10 plans consécutifs. **Un dossier par plan** (`Plan1`, `Plan2`…, numérotation continue, même nombre de dossiers que de plans du lot) et, dans chaque dossier, **un fichier JSON par nouvelle génération** (jamais pour un élément déjà généré dans un autre plan) : le fond vide du plan d'abord (s'il n'est pas déjà généré ailleurs), puis les assets ou groupes d'assets, du fond vers le devant. Un dossier sans nouvelle génération contient `_reutilise.txt` ou `_rien_a_generer.txt` (règle 9) ; un élément en code y a sa fiche `NN_nom_code.md`.

```
animation_lot_01.zip
├── Plan1/
│   ├── 01_fond_poste_pilotage_vide.json
│   ├── 02_operateur_assis.json
│   └── 03_ecrans_drone.json
├── Plan2/
│   ├── 01_fond_poste_pilotage_vide.json
│   ├── 02_operateur_main_sur_tete.json
│   └── ...
└── ...
```

Le nom du fichier est `NN_nom_court` : `NN` donne l'ordre (fond = `01`), le nom n'a aucun caractère interdit dans un nom Windows (`\ / : * ? " < > |`).

**Contenu d'un JSON** : le nom, le prompt, et **une seule référence : l'image du plan**, prise sur GitHub dans le dépôt `Storyboard`. Les références sont toujours au format `depot` (celui d'ImGen) ; il n'y a **ni `chemin_sauvegarde`, ni référence locale, ni asset de `assetsBrute1`** : l'image du plan contient déjà tout ce qu'il faut.

```
{
  "nom": "Plan4_02_proprietaire_assis",
  "prompt": "…",
  "references": {
    "depot": {
      "url": "https://github.com/officecenter632-maker/Storyboard",
      "branche": "main",
      "chemins": ["Storyboard/sequence3/plan4.webp"]
    }
  }
}
```

- `chemins` est le chemin **tel qu'on le voit dans le zip** du dépôt : `Storyboard/sequenceN/planN.webp`, avec la **casse exacte du fichier** (les images sont en minuscules : `plan4.webp`, alors que les prompts sont `Plan4.txt`), et sans caractère `* ? [ ]`.
- `nom` est `PlanN_NN_nom_court`, unique dans tout le projet.

**Contenu du prompt.** L'IA reçoit l'image du plan en entier : le prompt lui **désigne** l'élément à produire (sa description, sa position dans l'image : « le personnage à gauche »), jamais plus.

- **Fond** : « même image, sans [liste des éléments dynamiques] ; reconstruis ce qui était caché derrière eux ; [le fond doit être plus large / plus haut que 16:9 de tant, si la caméra bouge] ». Pas de fond détourable.
- **Asset ou groupe** : « reproduis uniquement [élément(s) désigné(s)], isolé(s), entier(s), centré(s), sur un fond uni `#00FF00` (ou la couleur choisie) ; aplat parfait, ni ombre, ni dégradé, ni halo, ni sol ; même style et mêmes couleurs que l'image de référence ; reconstruis ce qui était caché ». Pour un groupe, chaque élément est désigné et séparé des autres par un vide net. Pour un état, le prompt dit lequel (« bras levé »). Pour un personnage articulé, il dit quelle partie.
- **Feuille de sprites** : « reproduis [l'élément] en N images successives, rangées en grille de C colonnes × L lignes, **cellules de même taille**, même cadrage et même ancrage dans chaque cellule, séparées par un vide net, sur un fond uni `#00FF00` (ou la couleur choisie) ; image 1 : [état], image 2 : [état]… ». Le `nom` du JSON se termine par `_sprites`.
- **Élément en code** : **pas de JSON**. Un fichier `NN_nom_code.md` (fiche de code, voir le registre) est livré dans le dossier du plan où l'élément apparaît en premier.
- **Dans tous les cas** : « même style que l'image de référence jointe », et « aucun texte, étiquette, badge, tampon ni logo ».

### Livraison progressive (pour ne pas perdre le travail)

Les jetons ou les messages peuvent s'arrêter à tout moment. **Tout ce qui n'a pas été livré est perdu.** Tu ne gardes donc jamais du travail terminé en attente, même au milieu d'un lot de 10 plans.

- **Le registre d'abord** : `Registre_elements_animation.md` est livré **dès qu'il est prêt**, avant tout prompt. C'est le premier livrable de l'étape.
- **Dès que 3 plans environ sont terminés**, tu livres **tout de suite** l'archive du lot **dans son état actuel** (`animation_lot_NN.zip` avec les dossiers des plans déjà faits), `Liste_assets_animation.md` cumulatif et `asset_profond_status.md` à jour, **avant** de continuer. Tu recommences ainsi tous les 3 plans. Chaque livraison remplace la précédente du même lot : l'archive est **cumulative**.
- Si tu sens que la limite approche, tu livres **tout de suite** ce qui est prêt, même un seul plan, et tu signales ce qui reste.
- **`asset_profond_status.md`** (ce nom exact, jamais un autre : ni `Avancement_animation.md`, ni `asset_profond.md`, ni `asset_profond_1.md`) est la mémoire du travail de l'étape 9. Il commence par le titre `# Avancement de l'animation (étape 9)` et une phrase de contrôle (zip et commit du dépôt `Storyboard` contrôlés, nombre d'images lues, état du registre), puis contient un tableau `Plan | État | Lot | Remarque`, avec les états « fait et livré », « à faire » ou « image à regénérer » (plan dont l'image du storyboard est noire, blanche, vide ou ne correspond pas à son plan : il est mis de côté jusqu'à ce que je la regénère). Un plan « fait et livré » est **définitif** : tu ne le refais pas, même dans une nouvelle session.
- **Reprise** : si la session s'arrête, je te redonne `Registre_elements_animation.md`, `asset_profond_status.md`, `Liste_assets_animation.md` et les archives déjà reçues ; tu reprends au premier plan « à faire », avec le même format, les mêmes noms et les mêmes conventions.

### Ce que tu me livres : `Liste_assets_animation.md`

En plus de l'archive, **un seul fichier `Liste_assets_animation.md`**, **cumulatif**, qui dit pour chaque plan **tout ce qu'il faut savoir pour animer**. Aucun champ n'est laissé vide : un champ non applicable est écrit « sans objet ».

**Fiche d'un plan**, toujours dans le même ordre :

1. **Identité** : `PlanN`, numéro d'origine, séquence, durée, voix off, image analysée (`Storyboard/sequenceN/planN.webp`).
2. **Ce qui se passe** : en quelques phrases, ce qui reste du plan précédent, ce qui arrive, ce qui part, ce qui change, et comment.
3. **FOND (statique)** : description, couleur dominante (code), éléments à retirer, zones à reconstruire, besoin d'un fond plus large pour la caméra. **Origine** : « généré ici » (fichier JSON associé) ou « réutilise `PlanN/NN_nom` » avec la retouche de montage.
4. **ASSETS (dynamiques)**, du fond vers le devant : un tableau, une ligne par élément, avec les champs ci-dessous.
5. **Chronologie d'animation** : l'ordre exact dans lequel tout apparaît et bouge pendant les secondes du plan (ex. « 0 s : fond ; 0,5 s : opérateur ; 2 s : écran droit glisse depuis la droite »).
6. **MONTAGE** : tout ce qui se fait au montage dans ce plan (texte exact, étiquette, badge, tampon, logo, forme simple, ombre, voile, mouvement de caméra), avec son emplacement et son moment d'apparition.
7. **Contrôle de couverture** : « chaque chose visible de l'image est classée FOND, ASSET ou MONTAGE : oui ». Si une chose n'est pas classée, elle est signalée ici.
8. **Points à trancher** pour ce plan.

**Champs d'un asset** : nom ; **technique** (tel quel, calque séparé, décomposé, code, feuille de sprites, nouvelle configuration) ; type (personnage, objet, icône, effet, forme dessinée, partie de personnage) ; description visuelle (forme, couleurs en codes, pose ou état, orientation, détails) ; position et taille dans l'image (centre en % de la largeur et de la hauteur, taille en % de la hauteur, rotation en degrés) ; ordre des calques ; animation (entrée, mouvement pendant le plan avec départ et arrivée, sortie, ordre d'arrivée, délai et durée en secondes) ; états ; parties séparées (point d'attache, zone cachée) ; **pour une feuille de sprites** : grille, nombre d'images, cellule, ancrage, cadence, boucle ; **pour un élément en code** : renvoi à sa fiche de code ; zones cachées ; couleur de détourage et pourquoi si ce n'est pas le vert ; groupe de génération (quels autres éléments sont générés avec lui) ; **origine** : « généré ici » (fichier JSON associé) ou « réutilise `PlanN/NN_nom` » avec la retouche de montage ; remarque. Pour un asset réutilisé, tous les champs de **position, taille, calque et animation** restent propres à ce plan : seule la génération est partagée.

Les fiches sont livrées **par lots d'environ 10 plans**, avec l'archive du même lot.

### Ce que tu contrôles par programme avant chaque livraison

| Contrôle | Ce qui est attendu |
| --- | --- |
| Couverture des plans | Un dossier de plan et une fiche pour chaque plan du lot, sans doublon ni manque, dans l'ordre |
| Contenu des dossiers | Chaque dossier de plan a au moins un JSON, ou un fichier `_reutilise.txt` / `_rien_a_generer.txt` ; chaque JSON annoncé « généré ici » dans une fiche existe dans l'archive, et inversement |
| Registre | Chaque famille du registre a **un seul** plan source et un seul JSON ; chaque « réutilise `PlanN/NN_nom` » d'une fiche pointe vers un JSON qui existe (dans l'archive ou dans un lot déjà livré) et que le registre prévoit ; aucun élément du registre n'est généré deux fois ; aucun élément visible d'un plan ne manque dans le registre |
| JSON | Chaque fichier est un JSON valide avec `nom`, `prompt` non vide et `references.depot` ; `nom` unique dans tout le projet |
| Références | Chaque `chemins` désigne un fichier **qui existe** dans le `Storyboard.zip` cloné, casse exacte, sans `* ? [ ]` ; la référence est bien l'image **du plan du dossier** (le plan source de l'élément) |
| Noms | Aucun nom de dossier ou de fichier ne contient `\ / : * ? " < > \|` |
| Détourage | Chaque prompt d'asset donne une couleur de détourage, qui n'apparaît pas dans les couleurs décrites de l'asset |
| Prompts | Chaque prompt d'asset contient : l'élément désigné, la couleur de détourage, « aplat », « sans ombre », « aucun texte » ; chaque prompt de fond contient la liste des éléments à retirer |
| Techniques | Chaque asset de chaque fiche porte une technique du registre, la même que dans le registre ; un asset décomposé a le même schéma (sous-assets, points d'attache, calques) dans tous ses plans |
| Feuilles de sprites | Chaque JSON `_sprites` contient la grille, le nombre d'images, « cellules de même taille » et la description de chaque image ; le nombre d'images décrites est égal à C × L (ou aux cellules utilisées) |
| Fiches de code | Chaque fiche `NN_nom_code.md` contient comportement, paramètres, position et taille, entrée et sortie, sortie attendue sur fond transparent, style ; **aucun JSON d'image n'existe** pour cet élément |
| Couverture visuelle | Chaque fiche de plan a la mention de couverture |

### Validation

Le registre est livré **avant** le premier lot (voir la passe d'inventaire), mais **sans validation préalable** : tu enchaînes le registre, puis tous les lots, sans jamais attendre mon « ok ». Je relis chaque lot et je te signale ce qui doit changer, y compris les « Points à trancher » : tu mets alors à jour la fiche **et** le JSON concerné (et le registre si une réutilisation change), toujours identiques, sans changer les noms de fichiers. **Aucune image n'est générée par toi** : c'est moi qui lance la génération, à partir de l'archive.

---

## Étape 10 : le dossier `AssetAnimation` et le projet ImGen des assets d'animation

Cette étape commence quand **tous les lots de l'étape 9 sont livrés** (les 64 plans sont « fait et livré » dans `asset_profond_status.md`). Le but : rassembler **tous les JSON de génération des lots dans un seul dossier**, rangé par plan comme le `Storyboard` l'est par séquence, puis générer **toutes les images d'assets d'animation avec ImGen**, chacune enregistrée **à côté de son JSON**, dans le dossier de son plan.

Cette étape ne change **rien** au contenu des JSON : leurs prompts et leurs références (l'image du plan, dans le dépôt `Storyboard`) sont ceux de l'étape 9, recopiés tels quels.

### Ce que je te fournis

1. Les **`animation_lot_NN.zip`** (tous les lots, dans leur dernière version livrée). Si un lot a été corrigé après sa livraison, je te donne la version corrigée ; tu n'en utilises jamais une ancienne.
2. Plus tard, quand tu m'as livré `AssetAnimation.zip` : le **chemin réel** du dossier `AssetAnimation` sur mon ordinateur, après que je l'ai décompressé, et l'**arborescence réelle** de ce dossier, copiée telle quelle (première ligne : chemin absolu complet, emojis inclus ; une ligne par dossier ou fichier).

Comme à l'étape 8, **avant de créer le projet, tu me demandes toujours** l'arborescence réelle du dossier de références GitHub sur mon PC, au cas où je devrais générer des images à la main.

### Ce que tu fais, première partie : le dossier `AssetAnimation`

1. **Tu décompresses les lots** (`animation_lot_01.zip` à `animation_lot_NN.zip`) dans ton espace de travail et tu notes leur nombre. Tu ne mélanges pas deux versions d'un même lot.
2. **Tu construis le dossier `AssetAnimation`** : à la racine, **un dossier `PlanN` par plan** (`Plan1` à `Plan64`, numérotation continue, aucun en trop, aucun manquant), et dans chacun **tout ce que le lot contenait pour ce plan, sans rien modifier ni renommer** : les JSON `NN_nom.json` (un par nouvelle génération), les fiches de code `NN_nom_code.md`, et `_reutilise.txt` ou `_rien_a_generer.txt` pour un plan sans nouvelle génération. Il n'y a **aucune image** dans l'archive : elles seront créées par ImGen, à côté des JSON. À la racine, **aucun autre fichier** : ni `Liste_assets_animation.md`, ni registre, ni statut.
3. **Tu contrôles par programme** avant de livrer :

| Contrôle | Ce que tu vérifies |
| --- | --- |
| Dossiers | Exactement 64 dossiers `Plan1` à `Plan64` ; aucun dossier de plan en double d'un lot à l'autre ; aucun dossier vide |
| JSON | Chaque fichier `.json` est valide, avec `nom`, `prompt` non vide et `references.depot` ; chaque `nom` est unique dans tout le projet et commence par `PlanN_` (N = le plan de son dossier) |
| Références | Chaque `chemins` désigne un fichier qui existe dans `Storyboard.zip` (dernière version du dépôt `Storyboard`), casse exacte, sans `* ? [ ]` |
| Fichiers | Tout fichier est un JSON, une fiche `NN_nom_code.md`, `_reutilise.txt` ou `_rien_a_generer.txt` ; rien d'autre ; le nombre total de fichiers est égal à la somme de ceux des lots |
| Zip | `AssetAnimation.zip` s'ouvre sans erreur (`testzip`) et contient un dossier racine `AssetAnimation/` |

4. **Tu livres `AssetAnimation.zip`** (dossier racine `AssetAnimation/` à l'intérieur du zip) avec un bilan court : nombre de plans, de JSON (donc d'images à générer), de fiches de code, de plans sans nouvelle génération. **Pas de script d'envoi, pas de push GitHub** : l'archive n'a pas besoin d'être sur GitHub, seul `Storyboard` doit y rester.

### Ce que je fais

Je décompresse `AssetAnimation.zip` dans mon projet (à côté de `Storyboard` et `Assets`) et je te donne le chemin réel et l'arborescence de `AssetAnimation`.

### Ce que tu fais, deuxième partie : `projet_imgen_assets.json`

À partir du chemin réel, tu écris **un seul fichier JSON**, `projet_imgen_assets.json`, au même format que le `projet_imgen.json` de l'étape 8 (`projet`, puis `images`). **Une image par fichier JSON de génération**, donc pas une par plan :

| Champ | Contenu |
| --- | --- |
| `projet` | Un nom court (par exemple `6-musk_starlink_assets_animation`). ImGen refuse un nom de projet déjà existant, et il doit différer de celui de l'étape 8. |
| `nom` | Le `nom` du JSON de génération, **recopié tel quel** (il est unique dans tout le projet). |
| `chemin_sauvegarde` | `<chemin réel de AssetAnimation>/PlanN/<nom du fichier JSON sans .json>.webp`, écrit avec des `/`, emojis du chemin recopiés tels quels (le JSON est collé dans ImGen : pas de codes `\U`). L'image est donc **à côté de son JSON**, sous le même nom. |
| `prompt` | Le `prompt` du JSON de génération, **identique**, sans le modifier. |
| `references` | Le `references` du JSON de génération, **identique** (l'image du plan, en `depot`, dans le dépôt `Storyboard`). Aucune référence locale. |

Règles :

- **Ordre** : par numéro de plan, puis par numéro de fichier (`01_`, `02_`…). Il n'y a **pas de vagues** : chaque génération part de l'image de son plan dans `Storyboard` et ne dépend d'aucune autre image à générer. Tu ne crées donc ni vague ni dépendance.
- **Aucune image pour** les fiches `NN_nom_code.md`, `_reutilise.txt` et `_rien_a_generer.txt` : un élément en code et un élément réutilisé ne se génèrent pas.
- **Dépôt** : tant qu'ImGen génère, le dépôt `Storyboard` doit contenir le `Storyboard.zip` à jour ; je ne pousse rien d'autre dans ce dépôt pendant ce temps.
- **Limites** : au plus 10 références par image (ici une seule), 10 Mo par fichier.
- **Extension** : `.webp`, comme à l'étape 8 (le bot enregistre en WebP).

### Ce que tu contrôles avant de livrer le JSON

| Contrôle | Ce que tu vérifies |
| --- | --- |
| Nombre | Autant d'images dans le projet que de fichiers `.json` dans `AssetAnimation` ; aucun nom en double |
| ImGen | Le JSON passe `parse_project_text` d'ImGen sans erreur ; tu donnes les avertissements attendus |
| Chemins de sauvegarde | Chaque `chemin_sauvegarde` est sous le chemin réel de `AssetAnimation`, dans le dossier du bon plan, avec le nom du fichier JSON et l'extension `.webp` ; aucun doublon |
| Identité | Chaque `prompt` et chaque `references` sont identiques à ceux du JSON de génération d'origine (comparaison par programme) |
| Dépôt | Chaque `chemins` existe dans le `Storyboard.zip` cloné, casse exacte |

Tu livres **`projet_imgen_assets.json`** (fichier complet, jamais tronqué) avec une consigne courte : « dans ImGen, clique sur **+**, colle le contenu du fichier ». Puis un bilan : nombre d'images, répartition par lot, avertissements attendus.

### Premier essai

Avant de lancer toutes les images, je génère **la première image du `Plan1`, puis celle du `Plan2`** : je vérifie que la référence est bien reçue, que l'image est enregistrée à côté de son JSON, avec le bon nom, et que le fond est bien détourable (aplat vert, sans ombre). Si un prompt est à corriger, tu me livres le JSON de génération corrigé, le `projet_imgen_assets.json` mis à jour (identiques), et, si l'image est déjà générée, le `reinitialisation_imgen.html` de l'étape 9.


**Étape suivante : l'étape 11 (re-vérification).** Quand toutes les images d'assets d'animation sont générées par ImGen, on passe à la re-vérification : on envoie les images sur GitHub et tu les contrôles.

---

## Étape 11 : re-vérifier les assets d'animation générés

Cette étape commence quand **toutes les images de `projet_imgen_assets.json` sont générées** par ImGen (étape 10). Le but : envoyer toutes les images dans un dépôt dédié, **`Assets_Animation`** (`https://github.com/officecenter632-maker/Assets_Animation`, branche `main`), puis les contrôler pour trouver celles dont la **génération est grave**, à regénérer. Ce dépôt est indépendant de `ImageReferenceData` et de `Storyboard` : il ne touche à aucun des deux. Comme eux, il ne garde **qu'un seul zip et un seul commit** : un nouvel envoi remplace le précédent.

### Ce que je fais : te donner l'arborescence

1. Je t'envoie l'**arborescence réelle** du dossier qui contient tous les assets d'animation générés (le dossier `AssetAnimation` de l'étape 10, avec ses images à côté des JSON), copiée telle quelle depuis mon ordinateur : la première ligne donne le **chemin absolu complet** du dossier, chaque ligne le **nom exact** d'un dossier ou d'un fichier.
2. **Si je ne l'ai pas encore envoyée, tu me la demandes** avant d'écrire quoi que ce soit. Tu n'écris jamais un chemin de mémoire.
3. Je te dis aussi comment je m'authentifie auprès de GitHub (`git` déjà connecté, ou jeton), comme pour `envoyer_storyboard.py`.

### Ce que tu fais, première partie : le script d'envoi

Tu m'écris **un seul script Python** (`envoyer_assets_animation.py`) qui **archive** le dossier et le **pousse** dans le dépôt `Assets_Animation`. Même règle d'or qu'à l'étape 9 : **tu ne le réécris pas de zéro**. Tu pars du modèle `envoyer_storyboard.py` (déjà testé : contrôle de structure, un seul zip, dépôt neuf, un seul commit, push forcé, vérification de la branche distante, jeton jamais affiché) et tu ne changes que ce que ma situation impose : le chemin du dossier (copié de la première ligne de mon arborescence), le nom du zip, le dépôt, les contrôles de structure. Mêmes règles d'écriture : il s'exécute n'importe où, se lance depuis un éditeur sans argument ni question, tu le **testes** avant de me le donner, et tu le livres dans un seul bloc de code.

**Ce qu'il archive** : les images générées (`.webp`) et les JSON de génération de chaque dossier `PlanN` (pour comparer chaque image à son prompt). Il liste dans le bilan tout fichier exclu. Avant tout envoi, il vérifie que **chaque JSON a son image** ; en cas d'écart (image manquante), il l'affiche et n'envoie rien, sauf si je force.

Je le lance depuis mon éditeur et je te dis que c'est fait.

### Ce que tu fais, deuxième partie : le checkup

1. Tu **télécharges le zip** depuis le dépôt `Assets_Animation` et tu **gardes la copie** dans ton espace de travail.
2. **Structure (par programme)** : le zip s'ouvre sans erreur (`testzip`), chaque JSON a son image et inversement, aucun doublon, aucun manque par rapport à `projet_imgen_assets.json`.
3. **Images suspectes (par programme)** : image illisible, entièrement noire ou blanche, minuscule, aplat uni sans contenu. Aucune n'est écartée en silence.
4. **Images (à l'œil)** : tu regardes **chaque image** et tu la compares à son prompt. Une **génération grave** (à regénérer) est : image manquante ou illisible, noire, blanche ou vide, **sans rapport avec son prompt**, **fond non détourable** (pas un aplat vert uni), élément principal **absent ou coupé**, **texte ou logo dessiné**. **Une image n'a pas besoin d'être parfaite** : un fil ou une manche qui touche le bord, un petit détail imparfait ne sont **pas** des défauts graves. Tu **ne les signales pas** et tu **n'en parles pas** : tu ne noies pas l'utilisateur sous des défauts mineurs.
5. Tu me rends un **bilan court, limité aux générations graves** : un tableau `Plan | Image | Problème | Action` (à regénérer) **uniquement** pour les images graves. S'il n'y en a aucune, tu écris simplement « aucune génération grave : les assets sont prêts pour la vectorisation » ; **pas de liste d'images acceptables, pas de remarques de détail**. **Dans la même réponse**, si des images sont à regénérer, tu me livres directement **`reinitialisation_imgen.html`** (étape 9, **avec sa structure imposée et la règle du bouton « Copier »**) pour le projet ImGen des assets, sans que je le demande. Les noms à réinitialiser sont ceux du champ `nom` de chaque JSON de génération (par exemple `Plan23_01_silhouettes_costume_face`), pas le nom du fichier du plan. Tu ne modifies rien toi-même : je regénère, je relance le script (il repousse tout seul), et tu recontrôles seulement ces images ; une image regénérée est **validée** dès qu'elle n'a plus de défaut grave (pas de seconde passe sur les détails).

**Étape suivante : l'étape 12 (vectorisation).** Quand plus aucune génération grave ne reste, on passe à la vectorisation des assets.


## Étape 12 : vectoriser les assets d'animation

Cette étape commence quand **l'étape 11 est terminée** : plus aucune image d'asset d'animation n'a de génération grave (les images regénérées ont été validées et le dépôt `Assets_Animation` est à jour). Le but : **vectoriser** les assets d'animation validés avec **`GenSVG.pyw`**, l'application qui gère une file de SVG à générer à partir d'images sources (même principe qu'ImGen : je colle un JSON avec le bouton **« + »**, des bots prennent les lignes une à une).

### Ce que je te fournis

1. L'**arborescence réelle** du dossier `AssetAnimation` sur mon ordinateur, **avec les images générées à côté des JSON** (étapes 10 et 11), copiée telle quelle : première ligne = **chemin absolu complet** (emojis inclus), une ligne par dossier ou fichier.
2. **Si je ne te l'ai pas encore donnée, tu me la demandes avant d'écrire quoi que ce soit.** Tu n'écris jamais un chemin de mémoire, et tu ne réutilises pas une arborescence d'une autre étape sans me demander si elle est toujours à jour.

### Ce que GenSVG attend

Un JSON que je colle dans GenSVG (bouton **« + »**, « Nouveau projet »). GenSVG le valide, crée le projet (dossier `ProjetsSVG`) et affiche un tableau : **une ligne = un SVG à générer**. Le projet est distinct de ceux d'ImGen.

```
{
  "projet": "nom du projet",
  "images": [
    {
      "nom": "nom court et unique",
      "chemin_sauvegarde": "chemin complet du .svg à produire",
      "source": {"depot": {"url": "https://github.com/officecenter632-maker/Assets_Animation", "branche": "main", "chemin": "chemin de l'image vu dans le zip du dépôt"}}
    }
  ]
}
```

Règles du validateur (`parse_project_text` de GenSVG) :

- `source` est **obligatoire** et c'est **un seul chemin** : soit `{"local": "..."}`, soit `{"depot": {...}}`, **jamais les deux**. Ici on utilise **toujours `depot`** : le bot clone le dépôt `Assets_Animation` (`https://github.com/officecenter632-maker/Assets_Animation`, branche `main`) et prend l'image dans le zip. **Jamais `local`** pour la source.
- La source est une image : `.png`, `.jpg`, `.jpeg`, `.webp`, `.gif` ou `.bmp`. Nos assets sont en **`.webp`**.
- `chemin_sauvegarde` **finit par `.svg`**. S'il est omis, GenSVG range le SVG dans `outputs/<nom>.svg` du dossier du projet : on ne l'omet **pas**.
- Chaque `nom` est **unique** (sans tenir compte de la casse) ; le chemin local est écrit avec des `/`.
- Un champ manquant ou invalide (dépôt, chemin, extension) donne une erreur.

### Ce que tu fais : `projet_gensvg.json`

À partir du chemin réel, tu écris **un seul fichier JSON**, `projet_gensvg.json`. **Une ligne par image d'asset générée** (donc une par fichier `.webp` de `AssetAnimation`) :

| Champ | Contenu |
| --- | --- |
| `projet` | Un nom court (par exemple `6-musk_starlink_assets_svg`). GenSVG refuse un nom de projet déjà existant. |
| `nom` | Le `nom` du JSON de génération (par exemple `Plan23_01_silhouettes_costume_face`), **recopié tel quel**. Il est unique dans tout le projet. |
| `source.depot` | `url` du dépôt `Assets_Animation`, `branche` `main`, et `chemin` = le chemin de l'image **tel qu'il est dans le zip du dépôt**, par exemple `AssetAnimation/Plan23/01_silhouettes_costume_face.webp`. **Tu télécharges le dépôt et tu lis le contenu du zip** : tu n'écris jamais ce chemin de mémoire. |
| `chemin_sauvegarde` | Le chemin **sur mon PC**, `<chemin réel de AssetAnimation>/PlanN/<nom>.svg`, écrit avec des `/`, emojis recopiés tels quels (le JSON est collé dans GenSVG : pas de codes `\U`) : le SVG est **à côté de l'image et du JSON**, sous le même nom. C'est le seul chemin local du projet. |

Règles :

- **Ordre** : par numéro de plan, puis par numéro de fichier (`01_`, `02_`…). Il n'y a **pas de dépendance** entre les lignes : chaque SVG part de son image.
- **Aucune ligne** pour les fiches `NN_nom_code.md`, `_reutilise.txt` et `_rien_a_generer.txt` : un élément en code ou réutilisé ne se vectorise pas.
- **Les images à vectoriser sont celles du zip du dépôt `Assets_Animation`** (une ligne par `.webp` du zip, avec le `nom` lu dans son JSON). Tant que ce dépôt contient le zip à jour, je ne pousse rien d'autre dedans.
- Tu ne changes **ni les noms ni les dossiers** : `nom` est celui de l'étape 10.

### Ce que tu contrôles avant de livrer le JSON

| Contrôle | Ce que tu vérifies |
| --- | --- |
| Nombre | Autant de lignes que d'images `.webp` dans l'arborescence ; aucun nom en double |
| GenSVG | Le JSON passe `parse_project_text` de GenSVG (`GenSVG.pyw` s'importe sans interface) **sans erreur** ; aucun avertissement n'est attendu |
| Chemins | Chaque `depot.chemin` désigne un fichier **existant dans le zip cloné** (casse exacte, aucun `* ? [ ]`) ; chaque `chemin_sauvegarde` est sous le chemin réel de `AssetAnimation`, dans le bon dossier de plan, en `.svg` ; aucun doublon ; **aucune source `local`** |
| Identité | Chaque `nom` est identique à celui du JSON de génération d'origine (comparaison par programme) |

Tu livres **`projet_gensvg.json`** (fichier complet, jamais tronqué) avec une consigne courte : « dans GenSVG, clique sur **+**, colle le contenu du fichier ». Puis un bilan court : nombre de lignes, répartition par plan, avertissements attendus.

### Premier essai

Avant de lancer toutes les lignes, je vectorise **la première image du `Plan1`, puis celle du `Plan2`** : je vérifie que le SVG est enregistré à côté de l'image, sous le bon nom, et qu'il ressemble à l'image. Si un chemin est à corriger, tu me livres le JSON corrigé (les noms ne changent jamais).

**Règle qui vaut pour toute l'étape : tu ne me signales pas les défauts mineurs.** Seules les erreurs graves (SVG manquant, vide, sans rapport avec l'image, élément principal absent ou faux) méritent d'être remontées. Les SVG n'ont pas besoin d'être parfaits.

**Étape suivante : l'étape 13 (archive de données pour l'animation).**

---

## Étape 13 : l'archive de données pour l'animation

Cette étape commence quand **l'étape 12 est terminée** : tous les assets d'animation sont vectorisés, un `.svg` à côté de chaque `.webp`. Le but : rassembler dans **un seul zip, `AnimationData.zip`, toutes les données dont tu as besoin pour écrire l'animation plan par plan**, et le pousser dans un dépôt dédié, **`ShaderiaxAnim`** (`https://github.com/officecenter632-maker/ShaderiaxAnim`, branche `main`, à créer s'il n'existe pas). Comme les autres dépôts, il ne garde **qu'un seul zip et un seul commit** : un nouvel envoi remplace le précédent. Il est indépendant de `ImageReferenceData`, `Storyboard` et `Assets_Animation`. **Le zip s'appelle `AnimationData.zip` et le dépôt `ShaderiaxAnim` : ce ne sont pas le même nom.** Le lien direct est `https://github.com/officecenter632-maker/ShaderiaxAnim/raw/main/AnimationData.zip`.

**L'animation ne passe par aucun logiciel externe.** Elle est faite **directement en web** (HTML, CSS, JavaScript), **par toi**, et **tu me montres le rendu toi-même dans la conversation** (étape 14). L'archive ne contient donc que les **données** du projet.

**Cette étape ne produit aucun code d'animation.** Elle prépare seulement l'archive. L'animation elle-même est l'étape suivante (étape 14, écrite plus bas) : tu clones le dépôt, tu lis le scénario, puis tu animes **plan par plan, progressivement**, et tu me montres chaque plan en page web pour que je te dise si tout est bon.

**Hors périmètre pour l'instant : le montage** (logo de la chaîne, police des cartons, étiquettes de date, de lieu et de source, badges, cartons de texte). L'archive ne contient donc pas de dossier `montage`. **En revanche, elle contient l'audio généré de chaque plan** (dossier `audio/`, voir plus bas) : l'audio est généré à l'étape 13 bis, donc **l'archive est d'abord poussée sans audio, puis repoussée avec l'audio** quand l'étape 13 bis est terminée (le nouvel envoi remplace le précédent). Les consignes de montage qui figurent dans les fiches restent dans les fiches, mais ne sont pas animées. On se concentre sur **l'animation des assets dans chaque plan**.

### Principe : l'archive contient TOUT ce qu'il faut pour animer

**Rien ne doit manquer.** L'IA qui anime ne doit **jamais** avoir à me demander un fichier, un texte ou une explication : tout ce qui décrit le projet est dans l'archive. Elle contient donc : le **scénario** et le texte de **chaque plan** (voix off, ce que le plan représente, ce qui est fait au montage), la liste des assets et les consignes de montage, les **prompts** de chaque asset, les images (`.svg` et `.webp` des assets, images du storyboard, images brutes), les fiches de code et la **procédure de travail** (`Director.md`).

- **Si l'IA a besoin d'un fichier qui n'est pas dans l'archive, c'est un défaut du script d'envoi** : elle ne me le demande pas, elle le signale en une phrase, corrige `envoyer_animation.py` pour qu'il l'inclue, et je relance le script.
- **Le script n'omet rien en silence** : il affiche dans son bilan **chaque fichier ou dossier du projet qui n'est pas envoyé, avec la raison**, et il **parcourt toute la racine du projet** (`AssetAnimation`, `Assets`, `Meta`, `Storyboard` et tout le reste). Un fichier d'un type inattendu dans `Meta/` ou `Storyboard/` est lui aussi listé, jamais ignoré.
- **Seules exclusions admises**, toutes listées dans le bilan : les fichiers `.part*` (téléchargements interrompus) ; les fichiers de suivi du travail (`asset_profond_status.md`, `Images_deja_validees_NE_PAS_RETRIER.md`) ; les images de référence Lexiax (`reference*.webp`), qui ne servent pas à animer ; les copies `.png` rangées dans `Assets/assets/<asset>/` et `Assets/assetsBrute1.zip` (les mêmes images sont déjà dans `assets_base/images/`) ; le dossier `Animation/` s'il existe encore (ancien projet d'un outil abandonné : il n'est **jamais** envoyé) ; les anciens zip d'envoi à la racine du projet (`AnimationData.zip`, `AssetAnimation.zip`, `Assets_Animation.zip`, `Storyboard.zip`) ; tout fichier **texte** (scénario, prompts, directives, assets de base) où le **garde-fou des secrets** trouve un identifiant : il est exclu et listé, sans bloquer l'envoi ; le montage (hors périmètre, mais **ses consignes restent dans les fiches et les `PlanN.txt`**) ; **l'audio n'est jamais exclu** : il part dans `audio/` ; et, **seulement si le total dépasse le plafond de 60 Mo d'images**, les images les moins utiles (d'abord les images brutes `assetsBrute1`, jamais les SVG), listées une à une.

### Ce que je te fournis

1. L'**arborescence réelle** du projet sur mon ordinateur, copiée telle quelle : première ligne = **chemin absolu complet** (emojis inclus), une ligne par dossier ou fichier. Elle doit montrer `AssetAnimation` avec ses `.svg`, `Storyboard`, et l'emplacement des fichiers `.md` de directives. **Si je ne te l'ai pas donnée, ou si tu doutes qu'elle soit à jour, tu me la demandes** : tu n'écris jamais un chemin de mémoire.
2. Mes **décisions sur les points à trancher** des fiches (section 8 de chaque plan de `Liste_assets_animation.md`, et section F du registre). Sans réponse de ma part, tu appliques la **lecture par défaut** indiquée dans chaque fiche, et tu le notes dans le `README.md`.
3. Comment je m'authentifie auprès de GitHub (`git` déjà connecté, ou jeton), comme pour `envoyer_storyboard.py`.

### Ce que contient `AnimationData.zip`

Un seul dossier racine, `AnimationData/`, avec :

| Dossier ou fichier | Contenu | Origine |
| --- | --- | --- |
| `assets/PlanN/` | Les **64 dossiers** `Plan1` à `Plan64`, avec les **`.svg`**, les fiches de code `NN_nom_code.md`, et les fichiers `_reutilise.txt` / `_rien_a_generer.txt`, **recopiés sans modification** | `AssetAnimation` |
| `directives/` | `Liste_assets_animation.md` (positions, calques, animations, chronologies), `Registre_elements_animation.md` (réutilisations et retouches), `Sequences.md` (durées), `Plan_animation.md` (**le scénario complet** : charte et palette, arbitrages, les 9 parties plan par plan avec voix off, visuel et caméra, texte à l'écran, couleur, annexes), **`Liste_assets.md`** (la liste des assets de base et les consignes de montage), **`Director.md`** (la procédure de travail) et **tout autre `.md` de `Meta/`**, sauf les fichiers de suivi | `Meta/` |
| `storyboard/` | Les **64 images de plan** (`.webp`), rangées par séquence : elles servent de modèle visuel pour vérifier chaque animation | `Storyboard` |
| `scenario/` | `Sequences.md` du Storyboard et, pour chaque `sequenceN/`, **`speech.txt`** (la voix off mot pour mot) et **tous les `PlanN.txt`** (64) : identité du plan, voix off, **ce que le plan représente**, composition, **« FAIT AU MONTAGE »**. Ce sont les textes qui disent **comment chaque plan a été pensé** | `Storyboard/sequenceN/` |
| `prompts_assets/PlanN/` | Les **JSON de génération** de chaque asset (`nom`, `prompt`, `references`) : ce que l'asset est censé montrer | `AssetAnimation/PlanN/*.json` |
| `assets_images/PlanN/` | Les **`.webp`** d'origine des assets : modèle pour juger la vectorisation | `AssetAnimation/PlanN/*.webp` |
| `assets_base/` | `index.csv`, `prompts/<asset>/prompt.txt` (le prompt de chaque asset de base et de chaque planche) et `images/*.png` (les images brutes `assetsBrute1`, planches de poses comprises) | `Assets/` |
| `audio/sequenceN/` | **L'audio généré de chaque plan parlé** : `PlanN.<extension>` (63 fichiers, `Plan1` à `Plan63` ; **le plan 64 n'a pas de voix off**), **recopiés sans modification**, avec leur **extension réelle** (`.wav`, `.mp3`… : AudioGen détecte le vrai format). **Un fichier par plan** | `Audio/sequenceN/` (étape 13 bis) |
| `README.md` | L'index de l'archive, les conventions et les décisions (voir plus bas) | Toi |
| `manifest.json` | La liste, plan par plan, des fichiers de l'archive avec leur taille (voir « `manifest.json` »), générée par le script | Script |

**Exclus** : uniquement ce que liste le « Principe » ci-dessus, **chaque exclusion étant affichée dans le bilan du script avec sa raison**. Les `.webp` des assets **ne sont plus exclus** (ils sont dans `assets_images/`, dans la limite du plafond de 60 Mo d'images), les JSON de génération non plus (`prompts_assets/`), ni `Liste_assets.md`.

### Où est le dossier `AssetAnimation` dans le dépôt `ShaderiaxAnim` ?

**Nulle part : on ne crée aucun dossier `AssetAnimation` dans le dépôt.** Ce nom n'existe que **sur mon ordinateur** (étapes 10 à 12) et dans le dépôt `Assets_Animation`. Dans `ShaderiaxAnim`, **le script `envoyer_animation.py` ne crée rien à la racine** : le dépôt ne contient que **`AnimationData.zip`** (un seul fichier, un seul commit). Le contenu de `AssetAnimation` est **réparti à l'intérieur du zip**, sous le dossier racine `AnimationData/`, **sans que le nom `AssetAnimation` y apparaisse**. Correspondance :

| Sur mon ordinateur (projet) | Dans le zip (`AnimationData/…`) | Dans ton clone, après `unzip` |
| --- | --- | --- |
| `AssetAnimation/PlanN/*.svg`, `*_code.md`, `_reutilise.txt`, `_rien_a_generer.txt` | `assets/PlanN/` | `AnimationData/assets/PlanN/` |
| `AssetAnimation/PlanN/*.json` | `prompts_assets/PlanN/` | `AnimationData/prompts_assets/PlanN/` |
| `AssetAnimation/PlanN/*.webp` | `assets_images/PlanN/` | `AnimationData/assets_images/PlanN/` |

Le dépôt, vu de l'extérieur, ressemble donc à :

```
ShaderiaxAnim/            (dépôt GitHub, branche main)
└── AnimationData.zip     (le seul fichier du dépôt)
        └── AnimationData/          (dossier racine du zip)
            ├── assets/Plan1 … Plan64
            ├── assets_images/Plan1 … Plan64
            ├── prompts_assets/Plan1 … Plan64
            ├── directives/  storyboard/  scenario/  assets_base/
            ├── README.md
            └── manifest.json
```

**Conséquence pour l'étape 14 :** le dossier `AssetAnimation/PlanN` écrit dans `projet_caa.json` (champ `svg`) est un chemin **du projet sur mon ordinateur** ; **dans ton clone du dépôt `ShaderiaxAnim`**, le même dossier est **`AnimationData/assets/PlanN/`**. Tu ne cherches jamais un dossier `AssetAnimation` dans le clone : tu ouvres chaque fichier avec le `chemin_relatif` du `manifest.json`. **Cette étape 13 n'est validée que si le contrôle de l'archive confirme que `AnimationData/assets/Plan1` à `Plan64` existent dans le zip téléchargé.**

**Le `README.md`** que tu rédiges donne, en une page : l'ordre de lecture des fichiers ; les conventions (image de **1672×941**, positions en % de la largeur (x) et de la hauteur (y), taille en % de la hauteur, rotation en degrés dans le sens horaire, calques du fond vers le devant, noms de fichiers `NN_nom` ; les SVG gardent leur fond de détourage vert ou magenta, retiré dans le code d'animation) ; où trouver l'**audio** de chaque plan (`audio/sequenceN/PlanN.<ext>`, à **intégrer directement dans la page HTML** à l'étape 14) ; où lire le scénario (`directives/Plan_animation.md` = le scénario complet, `scenario/` = voix off et texte de chaque plan) et où trouver les prompts, les images d'origine et les assets de base ; comment lire un `_reutilise.txt` (il renvoie à `PlanN/NN_nom`, avec la retouche à appliquer) ; les **dépendances entre plans** (un plan qui réutilise un asset d'un autre plan) ; les techniques 1 à 6 du registre ; **comment utiliser `manifest.json`** ; et la liste de mes **décisions** sur les points à trancher.

### `manifest.json` : retrouver chaque fichier

**But : tu retrouves n'importe quel fichier de l'archive sans me demander le moindre chemin.** Tu travailles sur le clone du dépôt, dans ton espace de travail ; le `manifest.json` dit, pour chaque fichier, où il est dans l'archive. **Aucun chemin de mon PC n'est nécessaire** : le rendu se fait chez toi, dans la conversation.

**Le script `envoyer_animation.py` écrit le manifest lui-même.** Il connaît le chemin absolu du projet (constante `PROJET`, copiée de mon arborescence) et construit chaque entrée à partir des fichiers **réellement présents** sur mon disque. Tu n'écris aucun chemin à la main dans le manifest.

**Structure imposée du `manifest.json`** (JSON UTF-8, `ensure_ascii=False`) :

```
{
  "projet": "6-musk_starlink",
  "genere_le": "2026-11-02T14:30:00",
  "plans": {
    "Plan1": [
      {
        "fichier": "01_fond_poste_pilotage_vide.svg",
        "type": "svg",
        "taille": 50487,
        "chemin_zip": "AnimationData/assets/Plan1/01_fond_poste_pilotage_vide.svg",
        "chemin_relatif": "Plan1/01_fond_poste_pilotage_vide.svg"
      }
    ]
  },
  "storyboard": {
    "Plan1": {"chemin_relatif": "sequence1/plan1.webp"}
  },
  "audio": {
    "Plan1": {
      "fichier": "Plan1.wav",
      "taille": 412044,
      "chemin_zip": "AnimationData/audio/sequence1/Plan1.wav",
      "chemin_relatif": "sequence1/Plan1.wav"
    }
  }
}
```

- **Tous les fichiers de `assets/PlanN/`** y figurent (SVG, fiches `NN_nom_code.md`, `_reutilise.txt`, `_rien_a_generer.txt`), avec le champ `type` (`svg`, `code`, `reutilise`, `rien`). **Chaque SVG a obligatoirement** `chemin_zip`, `chemin_relatif` et `taille`. Les 64 images du storyboard ont leur `chemin_relatif`. **Les 63 audios** (`Plan1` à `Plan63`) figurent dans la clé **`audio`**, avec `fichier`, `taille`, `chemin_zip` et `chemin_relatif` ; le plan 64 n'y est pas.
- **Tous les autres fichiers de l'archive** figurent dans la liste **`fichiers_supplementaires`** du manifest : une entrée `{groupe, fichier, chemin_zip, chemin_relatif, taille}` par fichier (`groupe` = `directives`, `scenario`, `prompts_assets`, `assets_images` ou `assets_base` ; les audios, eux, sont dans la clé `audio`).
- **Tous les chemins s'écrivent avec des `/`.**
- **Le script vérifie, avant tout envoi**, que chaque fichier cité existe sur mon disque, que sa taille est la même dans le zip, et que `chemin_relatif` et `chemin_zip` désignent le même fichier. En cas d'écart, il l'affiche et n'envoie rien (sauf si je force).

**Comment tu t'en sers (étape 14).** Tu ne me demandes jamais un chemin : tu ouvres chaque fichier dans ton clone avec `chemin_relatif`. Si un chemin manque ou ne mène à rien, c'est un défaut de l'archive : tu me le signales en une phrase, tu ne me demandes pas de te le dicter.

### Ce que tu fais, première partie : le script d'envoi

Tu m'écris **un seul script Python** (`envoyer_animation.py`) qui **assemble l'archive et la pousse** dans le dépôt `ShaderiaxAnim`. **Je n'ai jamais à copier ou à ranger un fichier à la main.** Même règle d'or qu'aux étapes 9 et 11 : **tu ne le réécris pas de zéro**. Tu pars du modèle `envoyer_storyboard.py` (déjà testé : contrôle de structure, un seul zip, dépôt neuf, un seul commit, push forcé, vérification de la branche distante, jeton jamais affiché) et tu ne changes que ce que ma situation impose : les chemins (copiés de mon arborescence), le contenu du zip, le nom du zip, le dépôt, les contrôles de structure. Mêmes règles d'écriture : il s'exécute n'importe où, se lance depuis un éditeur sans argument ni question, tu le **testes** avant de me le donner, et tu le livres dans un seul bloc de code.

**Contrôles du script avant tout envoi** (en cas d'écart, il l'affiche et n'envoie rien, sauf si je force) :

| Contrôle | Ce qu'il vérifie |
| --- | --- |
| Plans | Les 64 dossiers `Plan1` à `Plan64` existent dans `assets/` |
| Vectorisation | Chaque `.webp` de `AssetAnimation` a son `.svg`, de même nom, dans le même dossier |
| SVG lisibles | Chaque `.svg` n'est pas vide, est du XML bien formé et contient une balise `<svg>` avec `viewBox` ou dimensions |
| Fichiers parasites | Aucun fichier `.part*` ne part dans le zip |
| Storyboard | Les 64 images de plan sont présentes |
| Audio | **Si le dossier `Audio` de mon projet contient des audios** : il y a **un fichier `PlanN` pour chacun des plans 1 à 63** (extension audio quelconque), aucun fichier vide, aucun doublon pour un même plan, et chaque audio est dans `audio/sequenceN/` du zip avec la même taille que sur mon disque. **S'il manque des audios, le script l'affiche, plan par plan, et n'envoie rien (sauf si je force).** **Si le dossier `Audio` n'existe pas encore** (premier envoi, avant l'étape 13 bis), il l'indique dans le bilan (« audio pas encore généré ») et l'envoi a lieu quand même, **mais l'étape 14 ne commence pas avant le second envoi, avec l'audio**. Le script affiche aussi la **taille totale du zip** : au-delà de la limite de 100 Mo par fichier de GitHub, il le signale et n'envoie rien |
| Documents | Tous les `.md` retenus de `directives/` (au moins les quatre documents d'animation, `Liste_assets.md` et `Director.md`) et le `README.md` sont présents |
| Complétude | `Storyboard/` a **51 séquences**, `scenario/` contient **51 `speech.txt` et 64 `PlanN.txt`** (un fichier exclu par le garde-fou crée donc un écart) ; `prompts_assets/` a **un JSON par SVG** ; `directives/` contient `Liste_assets.md` et `Director.md` ; `assets_base/` a un `prompt.txt` par asset de base. Le bilan affiche **tout ce qui n'est pas envoyé, avec la raison** |
| Secrets | **Garde-fou, voir ci-dessous** : aucun identifiant, jeton, mot de passe ou clé n'est détecté dans les textes ajoutés |
| Chemins du manifest | Chaque fichier de `assets/` et chaque image du storyboard a son entrée dans `manifest.json` avec `chemin_zip` et `chemin_relatif` ; chaque SVG du zip a son entrée, et inversement ; **chaque fichier de `fichiers_supplementaires` existe sur mon disque, dans le zip, avec la même taille**, et inversement |

**Garde-fou des secrets (obligatoire, avant tout envoi).** Le dépôt `ShaderiaxAnim` est **public** : tout ce qui y est poussé est lisible par tout le monde et reste dans l'historique de GitHub même après suppression. Le script **analyse donc tous les textes ajoutés avant le zip** (`scenario/`, `prompts_assets/`, `directives/`, `assets_base/`) : jetons (`ghp_`, `github_pat_`, `sk-`, `AKIA`, `xox`…), et toute affectation d'un nom contenant `token`, `password`, `passwd`, `secret`, `api_key`, `apikey`, `authorization` ou `credential` à un texte long non vide. Le **fichier concerné est exclu** et listé dans le bilan (fichier, numéro de ligne et nom de la variable, **jamais la valeur**) ; le reste part. **`FORCER` ne contourne pas ce garde-fou** : un secret n'est jamais poussé sur un dépôt public. Si des identifiants ont déjà été poussés dans un envoi précédent, tu me le dis tout de suite en une phrase, pour que je les révoque : les supprimer du dépôt ne suffit pas.

Je le lance depuis mon éditeur et je te dis que c'est fait.

### Ce que tu fais, deuxième partie : le contrôle de l'archive

1. Tu **télécharges le zip** depuis le dépôt `ShaderiaxAnim` et tu **gardes la copie** dans ton espace de travail.
2. **Structure (par programme)** : le zip s'ouvre sans erreur (`testzip`), les 64 dossiers de plan sont là **dans `AnimationData/assets/`** (et non dans un dossier `AssetAnimation`), le nombre de SVG correspond au nombre de générations d'images (75 au registre), aucun doublon ; `scenario/` contient 51 `speech.txt` et 64 `PlanN.txt`, `prompts_assets/` un JSON par SVG, `directives/` tous les `.md` de `Meta/` retenus.
   **Audio (par programme, après le second envoi)** : `audio/` contient les **63 audios** (`Plan1` à `Plan63`), chacun lisible (taille non nulle, format reconnu), chacun cité dans la clé `audio` du manifest avec la même taille ; un audio manquant est un défaut de l'archive.
   **Manifest (par programme)** : `manifest.json` est un JSON valide ; **chaque SVG du zip** y figure avec `chemin_zip`, `chemin_relatif` et `taille`, et chaque `chemin_zip` existe dans le zip, avec la même taille ; aucun chemin ne contient `\` ni `*?"<>|`.
3. **Références (par programme)** : chaque asset cité dans `Liste_assets_animation.md` existe dans `assets/`, et chaque « réutilise `PlanN/NN_nom` » ou « Origine » désigne un fichier qui existe dans l'archive.
4. **SVG (par programme, puis à l'œil)** : tu **rends chaque SVG en image** et tu cherches les SVG vides ou illisibles. **Le fond vert `#00FF00` ou magenta `#FF00FF` des SVG n'est PAS un défaut** : les SVG ne sont pas détourés, et c'est **toi** qui retires ce fond (le premier `<path>` plein cadre) **dans l'animation**, plan par plan. Tu ne le signales donc pas dans le bilan. Tu ne regardes à l'œil que les SVG suspects, en les comparant à l'image du plan dans `storyboard/`.
5. Tu me rends un **bilan court, limité aux problèmes graves** : un tableau `Plan | Fichier | Problème | Action`. S'il n'y en a aucun, tu écris simplement « archive complète : prête pour l'animation ». **Pas de remarques de détail** : un SVG n'a pas besoin d'être parfait. Pour un SVG grave, je revectorise (ou je regénère l'image), je relance le script (il repousse tout seul).

**Règle qui vaut pour toute l'étape : tu n'écris aucun code d'animation ici.** Tu demandes ce qui manque (arborescence, décisions), tu prépares l'archive, tu la contrôles.

**Étape suivante : l'étape 13 bis (génération de l'audio de la voix off), puis l'étape 14 (réalisation de l'animation de chaque plan), écrites plus bas**, une fois l'archive validée. **Avant d'écrire la moindre ligne d'animation, tu lis toi-même, en entier, le scénario** (voir l'étape 14). Tu ne me demandes pas de te l'expliquer ; si un point reste flou après lecture, tu me poses une question précise en citant le passage.

---

## Étape 13 bis : générer l'audio de la voix off (AudioGen)

Cette étape commence quand **l'archive de l'étape 13 est validée** et se fait **avant l'étape 14** : la voix off est générée **avant** l'animation. Elle porte le numéro « 13 bis » (comme « 2 bis ») pour ne rien renuméroter dans ce document. Le but : produire **l'audio de chaque plan parlé** (63 plans ; le plan 64 n'a pas de voix off) avec **AudioGen** (`AudioGen.pyw`, TTS CAMB.AI). **Tu prépares les textes, je les génère.** Tu **n'écris aucune page HTML** : tu me livres un zip, un script et un JSON (voir plus bas).

### Principe

- **Un speech AudioGen par plan.** Chaque ligne `PlanN : phrase` d'un `speech.txt` devient **un speech**, avec son propre fichier audio. Le plan 64 (`(aucune voix off)`) est ignoré. Un speech reste sous **500 caractères** (limite d'une génération sur CAMB.AI, affichée par AudioGen).
- **Langue cible : l'anglais**, sauf si je te dis une autre langue. Les balises sont **toujours en anglais** : ce sont des commandes, pas du texte à traduire.
- **Les règles de traduction et de balisage sont écrites en entier dans ce document**, à la sous-section « Règles de traduction et de balisage » juste en dessous. **Elles ne dépendent d'aucun autre fichier** : tu ne me demandes aucun prompt TTS externe, et tu les relis en entier avant de commencer. Si un fichier de règles de balisage traîne dans la conversation, **tu l'ignores** : ces règles-ci font foi.
- **La durée max d'un speech est la durée de son plan**, lue dans la première ligne de `PlanN.txt` (par exemple `· 4 s`). Tu comptes **2,5 à 3 mots par seconde**. Si le texte traduit dépasse, tu le **raccourcis sans perdre le sens** et tu **signales le cas** dans ton bilan. Une phrase peut déborder sur le plan voisin (voir l'étape 9) : tu le signales aussi au lieu de la couper.
- **La source des textes est le dépôt `Storyboard`** (`https://github.com/officecenter632-maker/Storyboard`, `Storyboard.zip`, un `speech.txt` par séquence). **C'est toi qui le clones et qui lis les textes** : je ne te les donne pas. Si l'accès échoue, la règle de la zone « Erreurs de méthode » s'applique (les trois accès, jamais un autre dépôt à la place) : tu me demandes le lien exact en une phrase.
- **Tu ne modifies que les textes des `speech.txt`** : jamais un `PlanN.txt`, jamais une image, jamais `Sequences.md`.

### Règles de traduction et de balisage

Ces règles sont **complètes** : tu n'as besoin d'aucun autre fichier. Elles s'appliquent à **chaque ligne** `PlanN : texte` des `speech.txt`.

**Rôle.** Tu adaptes la voix off pour le TTS de CAMB.AI : tu traduis chaque segment, puis tu y intègres **une balise d'émotion** adaptée. Le ton par défaut est **posé, curieux, pince-sans-rire, jamais théâtral** (style Kurzgesagt), sauf si je te donne un autre ton.

**Traduire.**
- Reste **fidèle au sens et au rythme** de l'original. **Ne rajoute aucune idée.**
- **Garde la ponctuation finale** : elle pilote l'intonation du TTS.
- **Conserve la découpe** : un segment coupé à une micro-pause (par exemple « Et comestible ! », ou une phrase qui commence par « … ») **reste un segment séparé**.
- **Garde les chiffres lisibles à l'oral** (« 3,000 years old », « 1922 »).
- **Vérifie la durée** : 2,5 à 3 mots par seconde. Si le texte traduit dépasse la durée du plan, tu le raccourcis sans perdre le sens et tu signales le cas dans ton bilan.
- **Une autre langue que l'anglais** garde **les mêmes balises, en anglais** : ce sont des commandes, pas du texte à traduire.

**Choisir la balise.**
- **Une seule balise par segment, placée au tout début**, entre crochets : `[calm] Texte.` Jamais deux balises dans un même segment, jamais d'enchaînement contradictoire.
- Tu utilises **surtout les deux premiers niveaux** d'une émotion (les deux premiers mots de chaque ligne de la liste ci-dessous). Les **niveaux 3 et 4** seulement pour un **pic dramatique voulu**.
- **Aucun effet sonore** (`[laughing]`, `[sighing]`, `ahem ahem`…) **sauf si je le demande** explicitement.
- Les segments qui **prolongent la même idée gardent la même balise ou une balise voisine**, pour éviter les ruptures de timbre.
- **Pas de balise sur un segment de 1 à 2 mots** si elle risque de le déformer : tu le laisses **sans balise**.
- Tu écris la balise **exactement** comme dans la liste (minuscules, même orthographe, `grossed_out` avec son tiret bas). **Une balise qui n'est pas dans la liste est interdite.**

**Balises autorisées** (et **uniquement** celles-ci).

- **Styles** (à écrire en entier, virgules comprises) : `[shouting, angry, threatening]`, `[whispering]`, `[whispering, secretive]`, `[empathetic, helpful]`, `[happy, excited, promotional]`, `[patient, teaching]`.
- **Émotions**, **du plus subtil au plus extrême** (niveau 1, 2, 3, 4), chacune s'écrit seule entre crochets, par exemple `[curious]` :

| Famille | Niveau 1 | Niveau 2 | Niveau 3 | Niveau 4 |
| --- | --- | --- | --- | --- |
| Nervosité | uneasy | nervous | anxious | trembling |
| Peur | fearful | scared | terrified | panicked |
| Colère | irritated | angry | furious | enraged |
| Tristesse | down | sad | melancholic | depressed |
| Joie | cheerful | happy | joyful | delighted |
| Excitation | energetic | excited | thrilled | hyped |
| Calme | relaxed | calm | peaceful | serene |
| Confiance | assured | confident | certain | bold |
| Doute | uncertain | doubtful | hesitant | skeptical |
| Surprise | surprised | startled | shocked | astonished |
| Dégoût | grossed_out | disgusted | repulsed | revolted |
| Fierté | satisfied | accomplished | proud | fulfilled |
| Honte | embarrassed | guilty | ashamed | humiliated |
| Amour | warm | affectionate | loving | tender |
| Flirt | charming | playful | flirty | teasing |
| Sarcasme | dry | ironic | sarcastic | mocking |
| Détermination | focused | determined | driven | resolute |
| Frustration | annoyed | irritated | frustrated | exasperated |
| Soulagement | calmed | reassured | relieved | grateful |
| Curiosité | interested | curious | inquiring | intrigued |
| Ennui | dull | uninterested | bored | apathetic |
| Émerveillement | inspired | amazed | awed | wonderstruck |
| Méfiance | wary | suspicious | guarded | distrustful |
| Urgence | urgent | rushed | intense | pressured |
| Autorité | firm | authoritative | directive | commanding |
| Politesse | polite | courteous | respectful | formal |
| Gratitude | appreciative | thankful | grateful | warm |
| Confusion | uncertain | puzzled | confused | lost |
| Désespoir | resigned | defeated | hopeless | despairing |
| Espièglerie | lighthearted | playful | fun | silly |

**Si le texte source est ambigu ou incomplet** (une ligne vide, un `PlanN` manquant), tu me poses **une seule question** avant de générer.

### Ce que je te fournis

1. L'**arborescence réelle** du projet sur mon ordinateur, copiée telle quelle : première ligne = **chemin absolu complet** (emojis inclus). Elle doit montrer `Storyboard\sequenceN\speech.txt`. **Si je ne te l'ai pas donnée, ou si tu doutes qu'elle soit à jour, tu me la demandes** : tu n'écris jamais un chemin de mémoire.
2. Mes **décisions** : la langue (l'anglais par défaut) et, si je veux les fixer, la **voix**, le **modèle** et la **langue** d'AudioGen. Sans réponse, tu laisses ces champs vides (réglage de l'application) et tu le notes dans ton bilan.

### Ce que tu fais

1. **Tu clones `Storyboard`, tu ouvres `Storyboard.zip`** et tu lis les 51 `speech.txt` et les 64 `PlanN.txt` (pour les durées). Tu vérifies **51 `speech.txt`** et **64 lignes `PlanN`** (63 voix off et le plan 64) ; tout écart m'est signalé avant de continuer.
2. **Tu traduis et tu balises chaque ligne**, plan par plan, avec les règles ci-dessus. **Format conservé** : `speech.txt` garde une ligne par plan, sous la forme `PlanN : [balise] texte`, **mêmes noms de fichiers, mêmes numéros de plan, même ordre**. Le plan 64 reste tel quel.
3. **Tu me livres `Speech_audio.zip`** : un dossier racine `Storyboard/` avec les **51 `sequenceN/speech.txt` modifiés**, rien d'autre. C'est la copie à relire.
4. **Tu me livres `ecraser_speeches.py`** : **un seul script Python** qui **écrase les `speech.txt` présents sur mon ordinateur** par les versions modifiées. **Tu pars de l'esprit de `envoyer_storyboard.py`** : chemin absolu **en dur** recopié de mon arborescence (emojis écrits en codes `\U`), il s'exécute n'importe où, se lance depuis un éditeur **sans argument ni question**, tu le **testes sur de faux dossiers** avant de me le donner, et tu le livres dans **un seul bloc de code**. **Il contient lui-même les textes modifiés** : je n'ai aucun zip à placer ni à ouvrir. Il fait, dans cet ordre :
   - **contrôle de structure** : les 51 dossiers `sequenceN` et leurs 51 `speech.txt` existent sur mon disque, et chaque `speech.txt` contient les mêmes numéros de plan que la version modifiée ; en cas d'écart, il l'affiche et n'écrit rien ;
   - **sauvegarde des originaux** dans `Audio\speech_originaux_fr\sequenceN\speech.txt` ; **une sauvegarde déjà présente n'est jamais remplacée**, pour qu'un deuxième lancement ne perde pas le texte d'origine ;
   - **écrasement** des 51 `speech.txt`, en UTF-8, puis **relecture** de chacun pour vérifier qu'il est identique à la version attendue ;
   - **bilan** : fichiers écrasés, déjà à jour, absents, écarts. Il est **idempotent** (le relancer ne change rien) et **ne pousse rien sur GitHub**.
5. **Tu me livres `projet_audiogen.json`**, le fichier que je donne à AudioGen (bouton « Nouveau projet » : je saisis le **chemin du fichier**). Format :

```
{
  "projet": "nom du projet",
  "speeches": [
    {
      "nom": "Plan1",
      "texte": "[balise] le texte du plan, balise comprise",
      "chemin_sauvegarde": "chemin complet de l'audio à créer (.wav)"
    }
  ]
}
```

| Champ | Règle |
| --- | --- |
| `projet` | Un nom court (par exemple `6-musk_starlink_audio`). |
| `nom` | `Plan1` … `Plan63`, uniques, dans l'ordre. **Le plan 64 n'a pas de speech.** |
| `texte` | La ligne du `speech.txt` modifié, **sans** le préfixe `PlanN :`, **balise comprise**, identique au mot près. 500 caractères au plus. |
| `chemin_sauvegarde` | Le **chemin complet** `<racine du projet>/Audio/sequenceN/PlanN.wav`, écrit avec des `/`, emojis du chemin recopiés tels quels (le JSON est lu par AudioGen, pas ouvert dans un éditeur Python : pas de codes `\U`). L'extension est `.wav` ; AudioGen détecte lui-même le vrai format. Aucun doublon. |
| `voix`, `modele`, `langue` | **Facultatifs** : seulement si j'ai donné ma décision. Sinon, absents. |

   **Tu contrôles par programme avant de livrer** : tu charges `AudioGen.pyw` (il s'importe **sans lancer l'interface**) et tu passes mon JSON à sa fonction **`lire_liste_speech(chemin)`** : **aucune erreur ni avertissement** (en particulier aucun « dépasse 500 caractères ») ; 63 speeches, noms et chemins uniques ; chaque `chemin_sauvegarde` est dans le bon dossier `sequenceN` ; chaque `texte` est identique à la ligne du `speech.txt` modifié ; **chaque balise est dans la liste des balises autorisées** de la sous-section « Règles de traduction et de balisage » (une seule balise par segment, placée au début, ou aucune).
6. **Tu livres** les trois fichiers avec un **bilan court**, sans tableau qui répète le contenu : les choix de balises notables, les textes raccourcis ou à risque côté durée, ce qui a été changé par rapport au texte source, et la consigne en deux lignes (« lance `ecraser_speeches.py` depuis ton éditeur ; dans AudioGen, clique sur **Nouveau projet** et donne le chemin de `projet_audiogen.json` »).

### Premier essai

Avant de générer les 63 audios, je génère **`Plan1` puis `Plan2`**, je les écoute et je te dis : la balise s'entend-elle, la voix reste-t-elle la même d'un plan à l'autre, la durée tient-elle dans celle du plan. Si une balise déforme un segment, tu me livres le **`speech.txt` corrigé, `ecraser_speeches.py` en entier et l'entrée JSON correspondante**, toujours **identiques** entre eux ; les noms de plan ne changent jamais.

### Corrections

Un audio déjà généré à refaire : tu me livres, dans la **même réponse**, le JSON de réinitialisation d'AudioGen (`{"reinitialiser": ["Plan3", "Plan17"]}`) pour que je le colle dans l'application, avec la raison de chaque plan. Un texte modifié suit toujours le même chemin : `speech.txt`, script d'écrasement et JSON, **identiques**.

### Après cette étape

- **L'audio part dans `AnimationData.zip`** : quand les 63 audios sont générés, **je relance `envoyer_animation.py`** (il repousse tout seul : un seul zip, un seul commit). Les `audio/sequenceN/PlanN.<ext>` et les `speech.txt` modifiés partent avec. Tu **télécharges le zip** et tu fais le contrôle « Audio » de l'étape 13 ; **l'étape 14 ne commence qu'une fois ce contrôle passé**.
- **L'audio est intégré directement dans la page HTML de chaque plan** (étape 14), mais **l'animation ne se cale pas sur lui** : les `speech.txt` contiennent maintenant des **balises `[...]`** et du texte en anglais ; tu **ignores les balises** et tu te sers du texte seulement pour le **sens**.

**Étape suivante : l'étape 14 (réalisation de l'animation de chaque plan).**

---

## Étape 14 : réaliser l'animation de chaque plan (rendu web, directement ici)

Cette étape commence quand **l'archive de l'étape 13 est validée**, que **l'audio de l'étape 13 bis est généré** et que **l'archive a été repoussée avec l'audio** (`audio/` dans `AnimationData.zip`). Le but : **tu animes, plan par plan, directement en web** (HTML, CSS, JavaScript), **et c'est toi qui me montres le rendu dans la conversation**, sous forme d'une **page web animée par plan**, publiée en artefact. Je regarde, je te dis ce qui marche ou non, tu corriges, on passe au plan suivant. **Aucun logiciel externe n'est utilisé pour animer.** **C'est toi qui écris tout, y compris le détourage** : je n'écris, ne règle et ne lance rien, je regarde et je décide. **Les plans sont répartis et suivis par ClaudeAnimatorAgent** (voir « Les tâches dans ClaudeAnimatorAgent : comment elles sont rangées ») : **cette section prime sur tout ce qui suit là où elles diffèrent** (livraison en fichier joint au lieu d'un artefact, plan attribué par le logiciel, validation faite par moi dans le logiciel).

**Hors périmètre, toujours** : le montage (logo, polices, cartons, étiquettes de date, de lieu et de source, badges) et la **synchronisation de l'animation sur l'audio** (on n'anime pas sur la voix off). **L'audio, lui, est intégré directement dans le HTML de chaque plan** (voir « L'audio du plan, intégré dans la page »). Les consignes de montage restent dans les fiches, sans être animées.

### Les tâches dans ClaudeAnimatorAgent : comment elles sont rangées

ClaudeAnimatorAgent (« le logiciel ») range les 64 plans en **tâches** (**un plan = une tâche**), les distribue à des **agents** (un agent = une conversation Claude pilotée par le logiciel) et garde la trace de ce qui est fait. Dans ce mode :

- **chaque agent anime un seul plan** et reçoit tout du logiciel : le registre des exigences, le speech, le dossier des SVG, les directives de cette étape et, si son plan en continue d'autres, la page de ces plans. **Il ne demande rien** (ni le registre, ni le plan précédent) ;
- l'agent livre **`planN.html` comme fichier joint**, sans artefact ni lien ;
- **je regarde l'animation dans le logiciel, puis c'est moi qui la valide** (bouton « Valider comme animation » de la carte du fichier, ou en glissant le `.html` sur l'aperçu d'un plan sans animation, puis « Valider comme animation ») ; elle est copiée dans `Animation/Plan N – rendu animé.html`, et l'ancienne version, s'il y en avait une, est archivée dans `Animation/_versions`.

#### Les états d'une tâche

| État affiché | Sens | Attribuable à un agent ? |
| --- | --- | --- |
| **À faire** | pas d'animation validée, aucun agent dessus, aucun plan en attente | **oui** |
| **🔒 attend N** | à faire, mais un plan dont il dépend (N) n'est **pas encore validé** | **non, jamais** |
| **Désactivé** | mis de côté par moi (voir plus bas) | **non, jamais** |
| **En cours** | un agent y travaille | non |
| **Validé** | animation validée | non (je peux le réinitialiser) |

« 🔒 attend N » se **calcule** tout seul (il disparaît dès que les plans dont dépend la tâche sont validés) ; « Désactivé » est **enregistré** dans le projet.

#### L'ordre d'attribution

1. Le logiciel donne les plans **attribuables** aux agents libres, **dans l'ordre des numéros**.
2. Un plan **bloqué (🔒) ou désactivé est sauté** : l'agent libre prend le plan attribuable suivant.
3. Un plan se **débloque tout seul** dès que le dernier plan dont il dépend est validé.
4. Les plans **indépendants** avancent **en parallèle** ; les plans **liés** (une chaîne) avancent **l'un après l'autre**. « De Plan 1 à Plan 64 » est donc un ordre de préférence, pas un ordre strict.
5. Un plan qui **réutilise** un asset d'un autre plan **dépend de son plan source** : le plan source est toujours fait avant, sans que personne ait à y penser.

#### Déclarer les dépendances : le champ `depend_de`

Chaque plan porte la **liste des plans qui doivent être validés avant lui** (`[]` s'il est indépendant). **C'est toi qui la remplis**, à partir des fiches : je ne te la dicte pas.

- **Un plan dépend d'un autre quand il le continue** (même scène : même décor, mêmes personnages ou objets, même caméra qui poursuit son mouvement), **ou quand il réutilise un de ses assets** (`_reutilise.txt` : le plan source est celui qui figure dans `Registre_elements_animation.md` et dans la fiche du plan). **Dans le doute, il dépend** (comme dans « Plan qui continue le précédent »).
- **Où tu cherches** : `Sequences.md` et les dossiers `sequenceN` du storyboard (les plans consécutifs d'une même séquence partagent décor et personnages : ils se suivent), la fiche du plan dans `Liste_assets_animation.md`, son `PlanN.txt`, `Registre_elements_animation.md` (plan source et plans qui réutilisent), les `_reutilise.txt`.
- **Le premier plan d'une séquence est indépendant** (`[]`), **sauf** s'il réutilise un asset ou si sa fiche montre la même scène que le plan d'avant malgré le changement de séquence.
- **Dépendances directes seulement** : le plan 12 qui continue le 11, lui-même dépendant du 10, s'écrit `[11]`, pas `[10, 11]`. Un plan qui continue **et** réutilise un autre plan en liste les deux : `[11, 9]`.
- **Jamais de boucle, jamais le plan lui-même.** Un plan `_rien_a_generer.txt` est aussi une tâche (une page courte) et suit la même règle.
- **N'enchaîne pas ce qui n'a pas de lien** : tout chaîner reviendrait à n'avoir qu'un agent à la fois. Mais **n'omets pas une vraie continuité** : un raccord cassé coûte plus cher qu'une attente.

#### Désactiver un plan : le champ `desactive`

- Il vaut **`false` pour tous les plans** dans le JSON : c'est moi qui désactive ensuite, dans le logiciel (**clic droit sur le plan dans la liste : « Désactiver / Réactiver ce plan »**, possible seulement sur un plan « À faire »). Le choix est **enregistré dans le projet**.
- Un plan **désactivé n'est jamais attribué**. **Les plans qui en dépendent restent bloqués (🔒) tant qu'il n'est pas validé** : on n'anime pas la suite d'un plan qui n'existe pas. Je le réactive, ou je valide un `.html` à sa place, ou tu retires la dépendance si elle était fausse.
- Sert à **mettre de côté** un plan (en attente d'une décision de ma part, ou problématique) sans bloquer les plans indépendants.
- **Réinitialiser un plan validé** le remet « À faire » : ses dépendants **pas encore commencés** redeviennent 🔒 ; ceux **déjà validés restent validés**, mais le logiciel me prévient que leur raccord est à revoir, et c'est alors à moi de décider de les refaire.

#### Ce que reçoit chaque agent

- **Toujours** : le registre des exigences (à jour), le speech de la séquence, le dossier des SVG et la liste de ses fichiers, le dépôt à cloner, ces directives.
- **Plan avec dépendances** : le chemin de la page validée de **chacun** des plans dont il dépend. L'agent reprend leur état final tel quel et contrôle le raccord. **Le logiciel ne lui attribue le plan qu'après leur validation** : il ne peut donc jamais travailler sur un plan dont le précédent manque.
- **Plan indépendant** : rien de plus ; il part de l'état décrit par sa fiche. Si sa fiche montre pourtant la même scène qu'un plan d'avant, l'agent le dit en une phrase avant de livrer (la dépendance est alors à corriger).

#### Ton travail avant les agents : `projet_caa.json`

**Ce que je te fournis** : l'**arborescence réelle** du projet (chemin complet inclus). Rien d'autre : tu ne me demandes ni les dépendances ni les chemins.

**Ce que tu fais** : tu écris **`projet_caa.json`**, un seul bloc JSON livré **comme fichier** (même nom), que je colle dans le logiciel (« Nouveau projet » → « Vérifier » → « Créer le projet »).

```json
{
  "projet": "6-musk_starlink",
  "racine": "D:/ScaleTube/CHANNELS/IngeniaX/<chemin recopié de l'arborescence>/Video/6-musk_starlink",
  "depot": "https://github.com/officecenter632-maker/ShaderiaxAnim",
  "registre": "Animation/Registre_exigences_animation.md",
  "plans": [
    { "n": 10, "speech": "Storyboard/sequence9/speech.txt", "svg": "AssetAnimation/Plan10",
      "html": "Animation/Plan 10 – un nerf de la guerre.html", "depend_de": [], "desactive": false },
    { "n": 11, "speech": "Storyboard/sequence10/speech.txt", "svg": "AssetAnimation/Plan11",
      "html": null, "depend_de": [], "desactive": false },
    { "n": 12, "speech": "Storyboard/sequence10/speech.txt", "svg": "AssetAnimation/Plan12",
      "html": null, "depend_de": [11], "desactive": false }
  ]
}
```

| Champ | Règle |
| --- | --- |
| `projet`, `racine`, `depot` | `projet` = nom du dossier ; `racine` = chemin absolu **recopié de l'arborescence** (emojis compris, avec des `/`, jamais de `\`) ; `depot` = le dépôt que l'agent clone (**l'application ne le clone jamais**). |
| `registre` | chemin relatif de `Registre_exigences_animation.md` s'il figure dans l'arborescence, sinon `null` (je le choisis dans le logiciel). Il est envoyé à chaque agent. |
| `n` | un objet par plan, **de 1 à 64, dans l'ordre, sans en oublier**. |
| `speech` | le `speech.txt` de la **séquence qui contient** le `PlanN.txt` de ce plan. |
| `svg` | le dossier `AssetAnimation/PlanN` de ce plan **sur mon ordinateur** (chemin relatif à `racine`), **même s'il ne contient que** `_reutilise.txt` ou `_rien_a_generer.txt`. Dans le dépôt `ShaderiaxAnim` cloné, ce même dossier est `AnimationData/assets/PlanN/` (voir l'étape 13) : **il n'y a pas de dossier `AssetAnimation` dans le dépôt**. |
| `html` | le nom **exact** de la page déjà validée dans `Animation/` (les noms ne sont pas uniformes : `plan 9.html`, `plan12.html`…), ou `null`. |
| `depend_de` | **obligatoire pour chaque plan** (voir plus haut). |
| `desactive` | `false` pour tous. |

Tous les chemins sont **relatifs à `racine`**, avec des `/` ; les fichiers `.part-*` sont ignorés ; **aucun chemin n'est écrit de mémoire**, seulement ceux de l'arborescence.

**Ce que tu contrôles par programme avant de livrer** : 64 plans de 1 à 64 sans doublon ; chaque `speech`, `svg` et `html` existe dans l'arborescence ; chaque `depend_de` ne cite que des plans existants, autres que le plan lui-même, **sans boucle** ; **chaque plan dont le dossier contient `_reutilise.txt` a son plan source dans `depend_de`** ; tous les `desactive` valent `false`.

**Ton bilan** (court) : les **chaînes** de plans liés (par exemple 10 → 11 → 12), le nombre de plans **indépendants** (qui pourront partir en parallèle), et les **cas douteux** que tu as traités en « dépend », chacun avec sa raison en une phrase. **Je te corrige si besoin**, tu mets le fichier à jour et tu me le livres de nouveau.

### Le travail à faire, en résumé

**Avant le premier plan (une seule fois)**

1. Tu clones `ShaderiaxAnim`, tu télécharges `AnimationData.zip` et tu le décompresses. **Si le clone échoue ou si le dépôt n'a pas les SVG attendus, applique « Erreurs de méthode à ne jamais refaire » : tu ne prends aucun autre dépôt à la place.**
2. **Tu apprends le scénario** : tu lis `Plan_animation.md` et `Sequences.md` en entier et tu en tires `scenario_notes.md` (voir « Avant le premier plan : tu apprends le scénario »).
3. Tu écris le **moteur commun** (`moteur_plan.js` et le générateur `generer_plan.py`, dans ton espace de travail) : lecture de la chronologie, caméra, détourage, calques, contrôle lecture / pause / barre de temps. Tu notes ses règles dans `animation_notes.md` et tu crées `animation_status.md`. **Tu me demandes `Registre_exigences_animation.md` et tu le lis en entier** (voir « Le registre des exigences : ne jamais refaire une erreur, ne jamais oublier une demande »).
4. Tu me dis en une phrase si quelque chose bloque (par exemple une méthode de détourage impossible), **avant** de livrer un plan.

**Pour chaque plan, de Plan 1 à Plan 64**

1. **Si le plan continue le précédent, tu exiges d'abord le plan précédent** (voir « Plan qui continue le précédent »). Tu repasses **le registre des exigences**, puis **la ligne du plan dans le scénario, celles du plan précédent et du plan suivant**, sa fiche dans `Liste_assets_animation.md`, son entrée du registre, son `PlanN.txt` et le `speech.txt` de sa séquence, et son image de `storyboard/`.
2. Tu formules **l'intention du plan en une phrase** (ce que le spectateur doit comprendre ou ressentir) : l'animation est là pour la servir.
3. Tu génères la page du plan avec les valeurs des fiches.
4. **Tu la regardes toi-même** (voir « Vérifier avant de livrer »), puis tu la publies et tu me donnes le lien avec **une ligne**.
5. Je regarde et je te réponds ; **chaque défaut ou demande que je te signale est noté par toi dans le registre des exigences**, puis tu corriges **dans la même page** ; **tu n'enchaînes qu'après mon « ça marche »**, et tu mets `animation_status.md` à jour (avec le lien de la page).

**À la fin** : un bilan court (voir « Fin de l'étape »).

### Ce que je te fournis

**Dans ClaudeAnimatorAgent**, je te fournis seulement, une fois, l'**arborescence réelle** du projet pour `projet_caa.json` ; ensuite chaque agent reçoit tout du logiciel. **Sinon : rien**, sauf mon verdict après chaque plan, le registre des exigences au début de la session et, pour un plan qui **continue** le précédent, **le plan précédent** (voir « Plan qui continue le précédent : tu exiges le plan précédent »). L'archive est dans le dépôt `ShaderiaxAnim` : tu **clones le dépôt et tu télécharges le zip toi-même**, tu **gardes la copie** dans ton espace de travail. Tu ne me demandes **jamais** un chemin de fichier (le `manifest.json` donne tout), ni une explication, ni une décision déjà prise (les fiches et le `README.md` la donnent, ou la lecture par défaut).

### Le détourage et le moteur commun

1. Les SVG gardent leur fond de détourage plein cadre (vert `#00FF00` ou magenta `#FF00FF`, le premier `<path>`), et **ce fond ne doit jamais être visible dans l'animation**. **Tu retires toi-même ce premier `<path>` dans la copie intégrée à la page** : la méthode est simple, fiable et sans frange colorée sur les bords. **Les SVG d'origine ne sont jamais modifiés.** Les fonds de décor (`01_fond_…`) sont opaques par nature et ne sont pas détourés.
2. **Le gros plan reste net** : un SVG est vectoriel, donc il est **redessiné à la bonne taille à chaque image** (SVG en ligne dans la page, ou dessin sur canvas à la résolution d'affichage). Tu ne le convertis jamais en image basse résolution « pour simplifier ».
3. **Recadrage sans perte** : pour ne garder qu'une partie d'un SVG (par exemple un objet isolé dans un SVG qui en contient plusieurs), tu changes le **`viewBox`** de la copie intégrée, jamais le fichier d'origine.
4. **Les SVG d'origine sont « à plat »** (des centaines de chemins sans noms ni groupes). Pour animer un petit élément qui en fait partie (pastille, barre, radar…), tu **mesures** sa position et sa couleur, tu le **masques** dans le fond, puis tu le **redessines** animé en JavaScript **dans le même repère que le fond**, pour qu'il suive la caméra. Si l'élément existe déjà comme asset séparé (fiche de calque), tu l'utilises tel quel.
5. **Ordre de superposition d'abord** : avant de bouger un personnage, tu te demandes ce qui est devant et derrière lui, vu depuis la caméra (un élément du fond qui passe devant un personnage est extrait et redessiné après lui).
6. **Mesurer le corps, pas l'image** : l'échelle d'un personnage se règle sur le dessin visible, pas sur l'image entière qui contient des marges.
7. **Si la page ne permet vraiment aucune méthode** pour un plan, tu me le dis **avant** de le livrer, en une phrase, avec la raison et la seule solution possible.

### Avant le premier plan : tu apprends le scénario


**Animer sans connaître le scénario donne une animation juste en positions mais fausse en sens.** Avant d'écrire la moindre ligne d'animation, tu dois savoir **comment le scénario a été rédigé** et **ce qu'il veut dire**, plan par plan. Le scénario, c'est **`directives/Plan_animation.md`** (et non une simple « charte de couleurs » : il contient tout), complété par `directives/Sequences.md`.

1. **Tu lis `Plan_animation.md` en entier**, une seule fois, dans l'ordre :
   - la **section 0** : charte visuelle et choix de production (durée totale, nombre de plans, durée moyenne), la **palette**, les **éléments qui reviennent**, les **contradictions du registre et mes arbitrages**, et **« ce que j'ai décidé à ta place »** ;
   - les **9 parties**, plan par plan : pour chaque plan, la **durée**, la **voix off** (mot pour mot), le **visuel et la caméra**, le **texte à l'écran** et la **couleur** ;
   - les **annexes** (contrôles effectués, décisions prises, ce qui reste à fournir, rappel sur les faits).
2. **Tu comprends la mécanique de rédaction**, c'est-à-dire : comment un plan est construit (la voix off dit, l'image **traduit** : foules de silhouettes, symboles, objets fil rouge), comment les plans s'enchaînent dans une partie, comment le décor et la teinte changent d'un plan à l'autre, ce qui est **animé** (les assets) et ce qui est **fait au montage** (texte, étiquettes, logo, mouvements de caméra du scénario), et les règles de style (aplats, pas d'ombre portée, ellipse sous les pieds).
3. **Tu lis `Sequences.md`** (les 51 séquences, leur décor, leur teinte, leur durée) **et `scenario/`** : les `speech.txt` (la voix off de chaque séquence, mot pour mot) et les `PlanN.txt` (ce que chaque plan représente, sa composition, et ce qui est **fait au montage**). Ce sont ces textes qui disent **comment chaque plan a été pensé** ; tu lis aussi `directives/Liste_assets.md` (assets de base, consignes de montage) et, pour un asset dont tu as besoin du détail, son JSON dans `prompts_assets/PlanN/`.
4. **Tu écris `scenario_notes.md`** (dans ton espace de travail, **court**) : le fil de l'histoire en une ligne par partie ; la liste des **éléments récurrents** (opérateur de drone, télécommande, bâtiment à cinq côtés, satellite…) avec **le plan où chacun apparaît pour la première fois, ceux où il revient et ce qu'il devient** ; **l'intention de chaque plan en une phrase** ; les **arbitrages** et décisions de la section 0 ; les règles de style. Ce fichier remplace toute relecture du scénario en entier.
5. **Le speech sert à comprendre**, pas à synchroniser : l'audio est intégré à la page (voir « L'audio du plan, intégré dans la page ») mais on n'anime pas dessus, donc tu n'animes pas sur la voix off ; les `speech.txt` peuvent contenir des **balises `[...]`** et du texte en anglais (étape 13 bis) : **tu ignores les balises** et tu t'en sers pour le sens ; tu tu t'en sers pour le **sens** (ce qui doit être mis en valeur) et le **rythme** (un plan de 3 s ne s'anime pas comme un plan de 8 s). Les durées viennent de `Sequences.md`.
6. **En cas de désaccord** entre la ligne du scénario et la fiche d'un plan : pour les **valeurs** (positions, tailles, instants), la fiche l'emporte, car elle applique les arbitrages ; pour le **sens**, le scénario l'emporte. Tu notes l'écart dans `animation_notes.md`. Tu ne me poses la question que s'il bloque vraiment, et tu appliques sinon la **lecture par défaut** des fiches.
7. **Tu n'inventes rien** qui ne soit dans le scénario, les fiches ou le registre. Une animation qui « embellit » le scénario (un élément en plus, un geste qui change le sens) est une erreur, au même titre qu'un élément oublié.

### Un fichier média est intégré à la page ; un élément créé de zéro est dessiné en JavaScript

**Deux cas, et un seul critère : l'élément a-t-il un fichier média dans l'archive ?**

- **Oui (un SVG de `assets/PlanN/`) : tu le lis dans ton clone** (avec `chemin_relatif` du `manifest.json`) **et tu l'intègres à la page**, en base64 (`data:`), parce que la page publiée est **autonome** : elle ne peut charger aucun fichier extérieur. Tu n'écris jamais un SVG à la main à la place de l'asset existant.
- **Non (un élément à créer de zéro, sans fichier média) : tu le dessines directement en JavaScript** (canvas ou SVG en ligne). C'est le cas des éléments de la technique 4 (une fiche `NN_nom_code.md`, jamais une image) : trait qui se trace, pointillés, barres ou jauges, particules, pixellisation, effets. Il est **complet dans la page** (forme, couleurs, mouvement, paramètres), jamais décrit ni laissé à compléter.
- **Interdit dans les deux sens** : redessiner en code un élément qui a déjà un fichier SVG, et inventer un élément que la fiche ne prévoit pas.
- **Un chemin du manifest qui ne mène à rien est un défaut de l'archive** : tu me le signales, tu ne me demandes pas de te le dicter.

### L'audio du plan, intégré dans la page

**Chaque page `planN.html` contient l'audio de son plan, directement dans le fichier.** C'est le même principe que pour les SVG : la page est **autonome** et ne peut charger aucun fichier extérieur.

1. **Où il est** : `audio/sequenceN/PlanN.<ext>` dans ton clone (clé `audio` du `manifest.json`, `chemin_relatif`). Tu ne me demandes jamais l'audio ni son chemin.
2. **Comment tu l'intègres** : en **base64 dans une balise `<audio>`** (`data:audio/<type>;base64,…`), le type MIME venant de l'**extension réelle** du fichier (`.wav` → `audio/wav`, `.mp3` → `audio/mpeg`, `.ogg` → `audio/ogg`, `.flac` → `audio/flac`, `.m4a` → `audio/mp4`). **Tu ne modifies, ne coupes et ne convertis jamais l'audio.**
3. **Comment il joue** : il est **dans le lecteur de la page**. Le bouton lecture lance l'animation **et** l'audio ensemble ; la pause, la reprise et le retour au début les concernent tous les deux ; la barre de temps suit l'animation. **L'animation ne se cale pas sur la voix off** (hors périmètre) : l'audio est seulement joué avec elle, depuis le début du plan.
4. **Plan 64** : il n'a **pas de voix off**, donc pas d'audio ni de balise `<audio>`.
5. **Audio manquant ou trop lourd** : si l'audio d'un plan parlé est absent de l'archive, c'est un **défaut de l'archive** (tu me le signales en une phrase, sans animer ce plan sans voix). S'il rend la page trop lourde pour être livrée (plus de 5 Mo), tu me le dis en une phrase avant de livrer.
6. **Contrôle avant livraison** : la page contient **une seule** balise `<audio>`, dont la source est bien celle du bon plan (`PlanN`), et elle se lit.

### Plan qui continue le précédent : tu exiges le plan précédent

**Dans ClaudeAnimatorAgent**, la continuité est **déclarée** (`depend_de`) et **garantie par le logiciel** : il n'attribue le plan qu'une fois les plans dont il dépend validés, et il fournit leur page à l'agent. Les points 1 et 6 ci-dessous se font donc **sans rien me demander** ; les points 2 à 5 (état final repris tel quel, raccord contrôlé, plan précédent jamais modifié) **s'appliquent tels quels**.

**Quand un plan continue le précédent, son début doit être parfaitement synchronisé avec la fin de celui-ci, sans aucun écart.** Un plan **continue** le précédent quand son `PlanN.txt`, sa fiche, sa ligne dans le scénario ou le storyboard montrent la **même scène** (même décor, mêmes personnages ou objets, même caméra qui poursuit son mouvement), quand il **réutilise** un asset du précédent (`_reutilise.txt`) ou quand un doute existe. **Dans le doute, tu le traites comme un plan qui continue.**

1. **Tu exiges le plan précédent avant d'écrire la moindre ligne.** Si la page du plan précédent n'est **pas dans cette conversation** (nouvelle session), tu me demandes, en **une phrase**, de te la donner (le lien de la page, ou le fichier `planN-1.html`). Si elle est déjà dans la conversation, ou si son lien est dans `animation_status.md`, tu l'utilises sans me la demander. **Tu ne commences pas le plan tant que tu ne l'as pas.**
2. **Tu lis l'état final du plan précédent**, pas une estimation : **position, taille et rotation de chaque élément**, **pose des personnages**, **état des écrans, cartes et jauges**, **caméra** (position, zoom, inclinaison, oscillation en cours), **ordre des calques**. Tu notes ces valeurs dans `animation_status.md`.
3. **Le plan commence exactement dans cet état** : chaque valeur de départ est reprise **telle quelle**, sauf ce que la fiche du plan change **volontairement** au tout début. Tu ne « reconstruis » pas le décor de mémoire ou à partir du storyboard.
4. **Tu contrôles le raccord** : tu captures la **dernière image du plan précédent** et la **première image du plan**, tu les compares de près (cadrage, échelle, position, détourage, états), et tu corriges tout écart non voulu **avant** de me livrer. Un saut visible au raccord est une erreur.
5. **Tu ne modifies jamais le plan précédent** (règle des plans validés) : si le raccord montre qu'il faudrait le changer, tu me le dis en une phrase et tu attends mon accord.
6. **Les liens des pages** de tous les plans validés sont dans `animation_status.md`, pour retrouver sans effort le plan précédent.

### Le format que j'attends (à respecter à chaque livraison)

- **Une page par plan, `planN.html`** : **un seul fichier HTML autonome** (CSS et JavaScript dedans, SVG intégrés), **publié en artefact** (dans ClaudeAnimatorAgent : **livré comme fichier joint**, sans artefact ni lien). Une page ne dépasse pas 16 Mo ; les bibliothèques éventuelles viennent uniquement d'un hôte autorisé, en version précise. Les corrections se font **dans la même page** (même lien), jamais dans une seconde page.
- **Contenu de la page** : (1) l'en-tête du plan (nom, durée, caméra), (2) le moteur commun et le détourage, (3) les objets, du fond vers le devant, nommés `NN_nom` comme dans `assets/PlanN/`, (4) les éléments dessinés en code, (5) la chronologie complète, (6) un **lecteur** avec lecture / pause et barre de temps, et une lecture en boucle de la durée du plan.
- **Un plan = sa durée exacte** (celle de `Sequences.md` ou de la fiche) ; la boucle ne doit pas produire de saut visible quand c'est évitable.
- **Aucune phrase d'explication dans la page**, aucun « à compléter », aucun « idem plan précédent » : la page est complète à elle seule.
- **Nommage** : un objet = `NN_nom` ; le groupe = `Plan N` ; aucun nom en double.
- **Ma seule consigne par plan** : le lien de la page, **une ligne**, et, si besoin, **une phrase** sur ce que tu n'as pas pu vérifier.
- **Le résultat est une page web, pas un fichier vidéo.** L'export en vidéo n'est **pas** demandé pour l'instant : tu n'en parles pas et tu n'y travailles pas.

### Vérifier avant de livrer

**Tu ne dis jamais « terminé » sans avoir regardé.** Avant de me donner le lien :

00. **Si le plan continue le précédent, tu contrôles le raccord** : tu captures **la dernière image du plan précédent** et **la première du plan** et tu les compares (voir « Plan qui continue le précédent »). Tu ne livres pas tant qu'un écart non voulu subsiste.
0. Tu **repasses le registre des exigences ligne par ligne** sur ce plan : pour chaque règle, tu vérifies qu'elle est respectée, et tu ne livres pas tant qu'une règle est violée.
1. Tu **captures au moins 4 images** à des instants clés (début, milieu du mouvement principal, plan large ou état final, fin) et tu **les regardes vraiment, de près**.
2. Tu **compares** avec l'image du plan dans `storyboard/` : position, échelle, perspective, ordre des calques, cadrage au début du plan.
3. Tu **cherches toi-même** les défauts (personnage flottant, mauvaise échelle, élément devant ou derrière à tort, frange de détourage, animation qui se fige, saut au retour de boucle) : **je ne dois pas avoir à te les signaler**.
4. Un **mouvement trop faible ne compte pas** : s'il est invisible à l'écran, il est trop petit. Tu vises un mouvement lisible, puis tu le gardes « léger » par la lenteur et l'irrégularité.
5. **Le mouvement ne se fige pas** : si le temps est borné pour la caméra, les autres mouvements continuent jusqu'à la fin du plan.
6. Tu me dis **honnêtement ce que tu n'as pas pu vérifier**.

### Le registre des exigences : ne jamais refaire une erreur, ne jamais oublier une demande

**Principe : tout ce que je te dis qui doit compter dans la suite doit être noté et respecté : les erreurs que j'ai dû te signaler, et aussi mes remarques, mes demandes de modification, mes détails et mes préférences.** Si j'ai dû te montrer du doigt un défaut, c'est une faute de ta part ; si j'ai dû te répéter une demande, c'en est une aussi. Ni l'un ni l'autre ne doit se reproduire, ni dans ce plan, ni dans les suivants, ni dans une autre session. Tu n'as pas de mémoire d'une conversation à l'autre : le fichier `Registre_exigences_animation.md` est donc **ta mémoire**, et tu le tiens avec rigueur. Il a **deux parties** : **A. Erreurs à ne plus commettre** et **B. Exigences, remarques et détails voulus**.

1. **Tu me le demandes d'abord** (sauf dans ClaudeAnimatorAgent : le logiciel l'envoie à chaque agent avec son plan, tu ne le demandes pas). **Avant de commencer l'animation d'un plan, au début de chaque session, tu me demandes de t'envoyer `Registre_exigences_animation.md`**, en une phrase (« envoie-moi d'abord `Registre_exigences_animation.md` »). **Tu ne commences aucun plan tant que tu ne l'as pas lu**. C'est, avec **le plan précédent** quand le plan continue (voir « Plan qui continue le précédent »), la **seule chose** que tu as le droit de me demander avant d'animer. S'il n'existe pas encore (première fois), tu le crées toi-même et tu me le livres.
2. **Tu le lis en entier**, puis tu le **repasses comme une liste de contrôle, en commençant par les priorités les plus hautes** : avant chaque nouveau plan, et avant chaque livraison (étape 0 de « Vérifier avant de livrer »). Tu fais le maximum pour qu'aucune erreur déjà notée ne revienne et qu'aucune demande déjà notée ne soit oubliée.
3. **Quand tu notes.** **Chaque fois que je te signale un défaut, une erreur ou une exigence non respectée, et chaque fois que je te fais une remarque, une demande de modification, un détail ou une préférence** (même petite), tu la notes **dans la même réponse**, **avant ou en même temps que la correction**, sans attendre que je te le demande. Ce que j'ai dit et que tu n'as pas noté est une faute de plus.
4. **Jamais de doublon : un sujet = une seule ligne.** **Avant d'écrire**, tu cherches si le sujet (même cause, même demande, même contrôle) est déjà dans le registre.
   - **S'il y est déjà** et que l'erreur est recommise, ou que je dois répéter la demande : **tu n'ajoutes pas de ligne**. Tu **augmentes sa priorité d'une étoile (★)**, tu mets à jour la colonne « Signalée » (plans et nombre de fois), tu précises la règle ou la portée si besoin, et tu retries le tableau **par priorité décroissante**.
   - **S'il n'y est pas** : tu ajoutes une ligne à **★**. Dans **A** (erreur) : le **plan**, **ce que j'ai vu de faux** (mes mots), **la vraie cause** (pas « j'ai oublié » : ce qui, dans ta méthode, a permis l'erreur), la **règle + le contrôle précis** qui l'aurait détectée avant moi. Dans **B** (exigence) : **ce que je veux, dans mes mots**, et **comment l'appliquer**.
   - **Si je change d'avis**, tu **modifies la ligne existante** (jamais deux lignes contradictoires) et tu notes « remplace : … ».
5. **La portée.** Chaque ligne dit si elle vaut pour **tous les plans**, une **famille d'éléments** (décor, personnages, caméra…) ou **un plan précis**. Une demande propre à un plan ne s'applique pas aux autres ; une règle qui vaut pour tous les plans, tu l'appliques **sans que je te la redise**.
6. **Les niveaux de priorité.** **★** : sujet noté. **★★ ou plus** : il est revenu ; tu cherches **la cause profonde** et tu **corriges le moteur commun ou le générateur** pour que cela devienne impossible, au lieu de corriger plan par plan, et tu me le dis en une phrase. **★★★ ou plus** : grave ; son contrôle est fait **en premier** avant chaque livraison et il est relu **en tête** à chaque plan.
7. **Tu me livres le registre à jour.** À chaque fois que tu l'as modifié, tu me le livres **comme fichier** (même nom), avec la correction, en **une ligne** (« registre à jour »). **Mon seul geste** : garder cette dernière version et te la renvoyer au début de la prochaine session. Tu me préviens de ce geste **avant** (une phrase), et tu ne me le fais faire qu'ici.
8. **Tu cherches seul les défauts de même famille.** Quand je signale un défaut sur un plan, tu **cherches le même défaut dans les plans déjà livrés et dans le plan en cours**, et tu le corriges **avant** que j'aie à le redire (échelle, perspective, ordre des calques, mouvement figé ou trop faible, objet non demandé…).
9. **Je n'ai jamais à te répéter une règle ou une demande déjà notée.**

### Ménager mes crédits (règle de toute l'étape 14)

L'étape 14 est longue (64 plans) : **je ne dois pas arriver à court de crédits avant le dernier plan**. Tu travailles donc de façon économe, **sans jamais sacrifier l'exactitude** :

- **Tu lis une fois, tu notes, tu ne relis pas.** Le README, `manifest.json` et les directives sont lus **une seule fois** ; tu en tires `animation_notes.md` (conventions, méthode de détourage, règles du moteur commun, pièges) et tu t'appuies ensuite sur lui.
- **Tu lis le strict nécessaire** : pour un plan, seulement sa fiche dans `Liste_assets_animation.md`, son entrée du registre, son `PlanN.txt` et le `speech.txt` de sa séquence, son image de `storyboard/` et ses fichiers de `assets/PlanN/`. **Jamais** les 64 fiches d'un coup (le scénario, lui, est lu **en entier une seule fois** et résumé dans `scenario_notes.md`), jamais un SVG en entier (tu lis son en-tête, ou tu le rends en petit).
- **Tu écris par script** : un petit programme (`generer_plan.py`) lit le manifest et la fiche et produit la page ; **le moteur commun** (caméra, détourage, recadrage, perspective, découpe d'un personnage en parties, lecteur) **sert à tous les plans** : tu le corriges une fois, tous les plans en profitent. Chaque plan reste du travail sur mesure pour sa chronologie, mais les parties répétées sont mises en commun.
- **Les petites modifications se font par édition de la page publiée** (remplacer un passage) plutôt qu'en tout régénérer.
- **Pas d'essais inutiles** : tu ne livres pas deux versions d'un plan « pour voir », tu ne refais pas un plan validé, tu ne livres pas un plan que tu sais incomplet. **Un plan correct du premier coup coûte moins cher que trois corrections.**
- **Réponses courtes** : le lien, une ligne, une phrase sur ce qui n'est pas vérifié, rien d'autre. Pas de récapitulatif, pas de tableau, pas de relecture à voix haute.
- **Tu me préviens avant un travail lourd** : si une étape va coûter nettement plus que la moyenne (un plan à très nombreux éléments, une réécriture de plusieurs plans), tu me le dis **en une phrase avant de la faire**, avec la raison et une alternative moins chère.
- **Tu travailles pour pouvoir reprendre** : après chaque plan validé, tu mets à jour `animation_status.md` (plans validés avec leur lien, plan en cours, décisions, pièges rencontrés), pour qu'une nouvelle session reparte **sans tout relire** : elle lit `animation_notes.md` et `animation_status.md`, pas toute l'archive.

### Ce que contient la page d'un plan

Une **page complète par plan**, `planN.html`, qui **donne à elle seule l'animation entière du plan**. Elle contient :

- **tous les objets** du plan (fonds, personnages, groupes d'assets, parties décomposées, feuilles de sprites découpées, éléments en code), **rangés dans un groupe nommé** `Plan N`, chaque SVG étant **intégré** à la page ;
- **le détourage** de chaque SVG qui en a besoin ;
- **la chronologie** du plan : caméra, durée, placement initial de chaque élément, ordre des calques, et **toute la chronologie** de `Liste_assets_animation.md` (ce qui apparaît, bouge, change d'état, disparaît, à quelle seconde) ;
- **les fiches de code** (`NN_nom_code.md`, technique 4, éléments sans fichier média) **dessinées en JavaScript, complètes**, jamais laissées en description ;
- **les assets réutilisés d'un autre plan** (`_reutilise.txt`), repris au bon endroit avec la retouche demandée, jamais regénérés ni redessinés à la main ;
- **les éléments communs** (le moteur, le détourage) **inclus dans chaque page** : chaque page est **autonome**.

**Les valeurs viennent des fiches, jamais de ton imagination** : positions en % de la largeur (x) et de la hauteur (y), taille en % de la hauteur, rotation en degrés (sens horaire), image de 1672×941, durées de `Sequences.md`, couleurs et caméra de `Plan_animation.md`, **lecture par défaut** des points à trancher. Tu n'inventes aucun élément, tu n'en oublies aucun, tu n'ajoutes ni audio ni montage. **Tu ne dessines rien que je n'ai pas demandé** (objet dans une main, clavier animé…).

### Comment on avance : un plan à la fois

1. Tu relis **la ligne du plan dans `scenario_notes.md` (et dans `Plan_animation.md` si un détail manque), avec le plan précédent et le suivant**, puis tu écris le plan **complet** (jamais un morceau « à compléter ») ; tu **vérifies tout ce qui peut l'être** avant de me le livrer (voir « Vérifier avant de livrer ») : fichiers cités existants dans le clone, durées et positions venant des fiches, rien en double, aucune erreur dans la page.
2. Tu me livres **le lien de la page**, avec **une ligne**, sans rien d'autre à faire pour moi.
3. Je regarde et je te dis : **« ça marche »**, ou ce que je vois de faux (une phrase, ou une capture).
4. Si quelque chose est faux, tu **corriges la même page** (même lien) et tu me redis en une ligne ce qui a changé. Tu n'enchaînes sur le plan suivant **qu'après mon « ça marche »**.
5. Ordre : **dans ClaudeAnimatorAgent, l'ordre est géré par le logiciel** (dépendances : un plan n'est attribué qu'après la validation de ceux dont il dépend ; plans indépendants en parallèle). Sinon, de **Plan 1 à Plan 64**, sauf si un plan en réutilise un autre qui n'est pas encore fait (tu fais alors le plan source d'abord, et tu me le dis en une phrase). Un plan sans asset à animer (`_rien_a_generer.txt`, `_reutilise.txt` seul) se traite aussi : tu me livres sa page, même courte.
6. Un plan qui réutilise ou continue un autre ne **casse jamais** un plan déjà validé : tu ne modifies un plan validé que si je te le demande.

**Aucun travail manuel pour moi** (règle de tout ce document) : pas de fichier à copier, de dossier à créer, de chemin à écrire, de SVG à préparer. Mon seul geste : regarder la page et te dire ce que je vois.

### Fin de l'étape

Quand les 64 plans sont validés, tu me livres un bilan court : plans validés (avec leurs liens), plans qui en réutilisent d'autres, limites connues, et, si tu peux le faire, une page qui enchaîne les 64 plans. Le montage est l'étape suivante (l'audio a été généré à l'étape 13 bis).

---

## Contrôle final

- [ ] **Tous les envois sur Git ont été faits par les scripts** (sélection, contrôle, zip, push, vérification) : aucun zip glissé dans Lexiax, aucun clic sur « Push sur GitHub », aucune commande `git` tapée par moi.
- [ ] **Je n'ai eu à faire aucun travail manuel** : aucun fichier copié, déplacé, renommé ou rangé à la main, aucun dossier créé à la main ; mon seul geste a été de lancer les scripts livrés.
- [ ] La collecte Lexiax a été faite en **une seule passe** : un seul script, un seul zip, tous les assets.
- [ ] Le zip a été téléchargé depuis https://github.com/officecenter632-maker/ImageReferenceData et sa **structure a été vérifiée** (assets, mots, images, `index.json`) par rapport à la recherche.
- [ ] Peu de mots par asset (3 à 5 pour un élément clé, 2 à 4 pour un petit élément), tous précis, sans saturation.
- [ ] Le fichier `Liste_assets.md` a été envoyé à l'étape 1.
- [ ] Chaque asset de la liste de l'étape 1 est couvert : soit par son propre dossier (élément clé), soit par une planche (petit élément).
- [ ] Chaque dossier contient un sous-dossier `generation`.
- [ ] Un élément clé a exactement deux fichiers : `reference.<extension>` et `prompt.txt`.
- [ ] Une planche a une image de référence par petit élément, plus un seul `prompt.txt` qui dit quelle référence correspond à quel élément.
- [ ] Aucun nom de dossier ne contient `\ / : * ? " < > |`.
- [ ] Chaque prompt est complet et correspond à son asset ou à sa planche.
- [ ] Un seul `copier_assets.pyw`, livré à la racine du lot 1 (donc à la racine de `assets`) : grille « label + Copier » (label vert quand l'image générée existe), bouton « Move » (Permuter, Valider) qui range et renomme les images d'après leur dossier, fenêtre étirée en largeur ; il a été testé sur de faux dossiers.
- [ ] Le travail a été **livré par lots** (`assets_lot_NN.zip`), avec `Images_deja_validees_NE_PAS_RETRIER.md` à jour à chaque lot.
- [ ] Une fois les images générées, l'**arborescence réelle** du dossier `Assets` (chemin complet inclus) a été fournie et comparée à `Liste_assets.md`.
- [ ] Le script `collecter_images.py` utilise les **chemins et noms de fichiers réels** de l'arborescence (chemin en dur, dictionnaire `IMAGES`), se lance depuis un éditeur sans ligne de commande, a été testé, puis livré en un seul bloc de code, à placer dans le dossier parent de `assets`.
- [ ] Après exécution, les images ont été **copiées** (les originaux restent dans `assets`) : `assetsBrute1` contient une image par asset, nommée d'après son dossier, plus `index.csv` avec la colonne `chemin_copie`, et le bilan ne signale aucun écart.
- [ ] Le zip produit s'appelle `assetsBrute1.zip` (puis `assetsBrute2`, etc. pour une nouvelle version) et contient un dossier du même nom avec les images copiées et `index.csv`.
- [ ] `assetsBrute1.zip` a été poussé sur GitHub (par le script de l'étape 5, sans aucun geste manuel) et téléchargé au lien direct de l'étape 6 ; le checkup (structure, 30 images, comparaison aux prompts) a été fait et son bilan par asset m'a été remis.
- [ ] Le découpage en **séquences** a été proposé puis **validé par moi** avant toute création de dossier.
- [ ] Le dossier `Storyboard` contient un dossier `sequenceN` par séquence, chacun avec `speech.txt` (voix off mot pour mot, une ligne par plan) et un `PlanN.txt` par plan (tous remplis). Il n'y a pas de dossier `temp`.
- [ ] Les plans sont numérotés de façon **continue de 1 à 64**, sans réinitialisation ; chaque prompt rappelle le numéro d'origine du scénario.
- [ ] Chaque `PlanN.txt` liste les images à joindre (assets, et l'image du plan précédent de la même séquence), donne le prompt et précise que l'image ne contient aucun texte ni logo.
- [ ] Les images sont posées dans le dossier de leur séquence, dans l'ordre de chaque séquence, avec l'image du plan précédent jointe à chaque plan suivant. Aucune validation ni vérification : c'est un storyboard pour se faire une idée.
- [ ] Pour ImGen : j'ai fourni l'arborescence réelle de `Storyboard` (et de `Assets` si elle a changé) et le lien du dépôt GitHub, qui contient le zip des assets (aucun autre push pendant la génération).
- [ ] `projet_imgen.json` contient 64 images (`Plan1` à `Plan64`), chacune avec son chemin de sauvegarde complet en `.webp` dans `Storyboard\sequenceN`, son prompt identique à celui de `PlanN.txt`, et ses références (assets en `depot` avec les chemins vus dans le zip, plan précédent et plans repris en `local` en `.webp`, jamais la même image dans les deux, 10 références au plus par plan).
- [ ] Le JSON a passé `parse_project_text` d'ImGen sans erreur, tous les chemins du dépôt ont été vérifiés par clonage et extraction du zip, et les images sont ordonnées par vagues de dépendance, avec le plan qui ouvre chaque vague indiqué dans le bilan.
- [ ] Premier essai fait sur `Plan1` puis `Plan2` (référence reçue, format d'enregistrement vérifié) avant de lancer les 64 plans.
- [ ] `envoyer_storyboard.py` a été **recopié du modèle du Director** (aucune réécriture) : seuls le chemin, les compteurs et le dépôt ont été adaptés ; une demande de mise à jour renvoie ce même modèle.
- [ ] J'ai fourni l'**arborescence réelle** du projet (chemin complet inclus) ; `envoyer_storyboard.py` utilise ce chemin en dur, a été testé, et a été livré en un seul bloc de code. Il ne zippe que le storyboard (`Sequences.md`, `speech.txt`, `PlanN.txt`, images des plans) et pousse vers le dépôt dédié **`Storyboard`** (pas `ImageReferenceData`) : `assetsBrute1.zip` reste intact, et j'ai gardé ma copie locale de `assetsBrute1`.
- [ ] `Storyboard.zip` a été poussé sur GitHub dans le dépôt `Storyboard` par `envoyer_storyboard.py` (contrôle de structure passé avant l'envoi), téléchargé au lien direct de l'étape 9, et sa structure a été vérifiée (51 séquences, 64 `PlanN.txt`, 64 images, 51 `speech.txt`) ; **les images suspectes (noires, blanches, vides, minuscules, de mauvaise taille, ou qui ne correspondent pas à leur plan) ont été cherchées par programme puis à l'œil, et listées dans un tableau avant l'analyse** ; les écarts m'ont été signalés avant l'analyse, et aucun plan suspect n'a été analysé avant d'être regénéré.
- [ ] Les **défauts de détail** (texte ou chiffre dessiné, élément coupé, en trop, déformé, mauvaise pose) n'ont **pas** fait regénérer d'image : chacun est corrigé dans le prompt concerné et listé dans la section G du registre. Seuls les écarts bloquants (image noire, blanche, vide, sans rapport avec son plan) sont allés dans `reinitialisation_imgen.html`.
- [ ] **Avant la passe d'inventaire**, je t'ai confirmé si j'avais regénéré les images signalées ; si oui, tu m'as **renvoyé `envoyer_storyboard.py` en entier**, j'ai poussé, tu as **re-téléchargé** `Storyboard.zip`, refait les contrôles et validé (ou renvoyé en vague) chaque plan regénéré. Aucun prompt n'a été écrit à partir d'une image périmée.
- [ ] Pour chaque plan « à regénérer » ou « à confirmer », `reinitialisation_imgen.html` a été livré **dans la même réponse que le tableau des écarts**, sans que je le demande : une carte par vague (zone de texte en lecture seule + bouton « Copier »), JSON générés par script, passés dans `parse_reset_json` d'ImGen sans erreur ni avertissement, une raison par plan, vagues ordonnées selon les `references.local`, plans « à confirmer » à part, et prompts fautifs corrigés d'abord.
- [ ] **Avant tout prompt**, les 64 plans ont été parcourus asset par asset et `Registre_elements_animation.md` a été livré (**sans attendre ma validation**) : pour chaque asset, sa configuration et son rôle dans chaque plan, la technique choisie (tel quel, calque séparé, décomposé, animation en code, feuille de sprites, nouvelle configuration), le schéma de décomposition (sous-assets, points d'attache, zones cachées, mouvements, calques), les feuilles de sprites (grille, images, cadence), les fiches de code, le plan source, les plans qui le réutilisent et les retouches de montage ; les fonds ; les plans à regénérer.
- [ ] Chacun des 64 plans a été **regardé image par image**, visualisé comme une suite de scènes (de la fin du précédent au début du suivant), et chaque chose visible est classée : FOND (statique), ASSET (dynamique) ou MONTAGE, sans rien d'oublié ni d'inventé. Le speech n'a servi qu'à comprendre la scène, pas à caler les plans.
- [ ] L'archive `animation_lot_NN.zip` a un dossier par plan du lot ; chaque dossier a un JSON par **nouvelle** génération (fond vide, asset ou groupe d'assets), ou `_reutilise.txt` / `_rien_a_generer.txt` ; chaque JSON a `nom`, `prompt` et une seule référence `depot` (l'image du plan dans le dépôt `Storyboard`, casse exacte), sans `chemin_sauvegarde`.
- [ ] Un élément qui revient dans plusieurs plans est **généré une seule fois**, dans le dossier de son plan source ; les autres plans écrivent « réutilise `PlanN/NN_nom` » avec la retouche de montage, et ne reçoivent un nouveau JSON que pour une **variante** (autre pose, autre état).
- [ ] Les feuilles de sprites sont demandées en **une image à grille régulière** (cellules de même taille, même ancrage), et les éléments en code ont une **fiche de code** complète à la place d'un JSON d'image.
- [ ] Chaque prompt d'asset donne la couleur de détourage (vert `#00FF00` par défaut), « aplat », « sans ombre », « aucun texte » ; chaque prompt de fond liste les éléments à retirer et les zones à reconstruire.
- [ ] `Liste_assets_animation.md` a une fiche complète par plan (ce qui se passe, fond, assets avec tous leurs champs, chronologie, montage, couverture, points à trancher), livrée **par lots cumulatifs**, et les contrôles programmatiques sont passés (couverture, JSON valides, références existantes dans `Storyboard.zip`, noms sans caractère interdit).
- [ ] Le travail a été **livré progressivement** (tous les 3 plans environ, archive cumulative) avec `asset_profond_status.md` à jour, pour pouvoir reprendre dans une autre session.
- [ ] Les lots ont été enchaînés sans attendre ma validation (le registre non plus n'a pas attendu ma validation) ; ce que j'ai corrigé a été mis à jour dans la fiche **et** dans le JSON, sans changer les noms de fichiers ; aucune image n'a été générée par l'IA.
- [ ] `AssetAnimation.zip` contient un dossier racine `AssetAnimation/` avec exactement 64 dossiers `Plan1` à `Plan64`, les JSON, fiches de code et fichiers `_reutilise.txt` / `_rien_a_generer.txt` des lots **recopiés sans modification**, et rien d'autre ; les contrôles programmatiques (dossiers, JSON, références dans `Storyboard.zip`, fichiers, `testzip`) sont passés.
- [ ] J'ai fourni le **chemin réel** et l'arborescence de `AssetAnimation` ; `projet_imgen_assets.json` a une image par fichier JSON de génération, avec `nom`, `prompt` et `references` identiques au JSON d'origine, et un `chemin_sauvegarde` en `.webp` à côté du JSON, dans le bon dossier de plan ; il a passé `parse_project_text` d'ImGen, sans vague ni référence locale.
- [ ] Premier essai fait sur la première image du `Plan1` puis du `Plan2` avant de lancer toutes les générations.
- [ ] Étape 11 : j'ai fourni l'arborescence réelle du dossier des assets d'animation générés ; le script d'envoi a poussé le zip dans `Assets_Animation`, tu l'as téléchargé et contrôlé, et tu m'as signalé **uniquement les générations graves** (avec `reinitialisation_imgen.html` si besoin), sans parler des défauts mineurs.
- [ ] Étape 12 : la vectorisation commence seulement quand plus aucune génération grave ne reste ; j'ai fourni l'**arborescence réelle** de `AssetAnimation` (tu me l'as demandée si tu ne l'avais pas) ; `projet_gensvg.json` a une ligne par image `.webp`, avec `nom` identique à celui de l'étape 10, `source.depot` (dépôt `Assets_Animation`, chemin vu dans le zip, jamais `local`) et `chemin_sauvegarde` (chemin sur mon PC en `.svg`), a passé `parse_project_text` de GenSVG sans erreur, et un premier essai a été fait sur `Plan1` puis `Plan2`.
- [ ] Étape 13 : j'ai fourni l'**arborescence réelle** du projet (tu me l'as demandée si elle manquait) ; mes décisions sur les points à trancher sont dans le `README.md`, ou la lecture par défaut y est notée.
- [ ] Étape 13 : `envoyer_animation.py` a été **recopié du modèle `envoyer_storyboard.py`** (seuls chemins, contenu, zip et dépôt adaptés), testé, livré en un seul bloc de code ; ses contrôles (64 plans, un `.svg` par `.webp`, SVG lisibles, aucun `.part*`, 64 images de storyboard, documents présents) sont passés avant l'envoi.
- [ ] Étape 13 : `manifest.json` donne, pour **chaque SVG**, `chemin_zip`, `chemin_relatif` et `taille` (plus les images du storyboard) ; le script les a générés à partir de `PROJET` et a vérifié que les fichiers existent sur mon disque ; tu ne me demandes **jamais un chemin**.
- [ ] Étape 13 : `AnimationData.zip` a été poussé dans le dépôt `ShaderiaxAnim` (un seul zip, un seul commit) et contient `assets/` (64 dossiers `PlanN`), `directives/` (les quatre documents, `Liste_assets.md`, `Director.md`), `scenario/` (51 `speech.txt`, 64 `PlanN.txt`), `prompts_assets/`, `assets_images/`, `assets_base/`, `storyboard/` (64 images), **`audio/` (63 audios, `Plan1` à `Plan63`, après l'étape 13 bis)**, `README.md` et `manifest.json`, **sans montage** ; **rien n'a été omis en silence** : le bilan du script liste tout ce qui n'est pas envoyé, avec la raison.
- [ ] Étape 13 : le zip a été téléchargé et contrôlé (structure, références, rendu des SVG ; le fond de détourage est retiré plus tard, dans l'animation) ; le bilan est limité aux problèmes graves ; **aucun code d'animation n'a été écrit à cette étape**.
- [ ] Étape 13 : le garde-fou des secrets est passé sur tous les textes ajoutés (fichier concerné exclu et listé, jamais la valeur affichée).
- [ ] Étape 13 bis : j'ai fourni l'**arborescence réelle** du projet et mes décisions (langue, voix) ; tu as **cloné le dépôt `Storyboard`** toi-même, relu les règles de traduction et de balisage de l'étape 13 bis, et traduit puis balisé **un speech par plan** (63 plans ; le plan 64 ignoré) : une seule balise au début de chaque segment, balises autorisées uniquement, durées contrôlées à 2,5 à 3 mots par seconde, dépassements signalés.
- [ ] Étape 13 bis : j'ai reçu **`Speech_audio.zip`** (51 `speech.txt` modifiés, format `PlanN : [balise] texte`), **`ecraser_speeches.py`** (chemin en dur, textes intégrés, sauvegarde des originaux dans `Audio\speech_originaux_fr`, testé, un seul bloc de code, aucun geste manuel) et **`projet_audiogen.json`** (63 speeches `Plan1` à `Plan63`, `chemin_sauvegarde` en `.wav` dans `Audio/sequenceN`) ; **aucune page HTML** n'a été produite.
- [ ] Étape 13 bis : `projet_audiogen.json` a passé `lire_liste_speech` d'AudioGen sans erreur ni avertissement, ses textes sont identiques aux `speech.txt` modifiés, et un **premier essai** a été fait sur `Plan1` puis `Plan2` avant de générer les 63 audios.
- [ ] Étape 14 : l'animation est faite **directement en web**, sans aucun logiciel externe ; **avant le plan 1**, tu as lu **en entier** `Plan_animation.md` (section 0, les 9 parties, annexes) et `Sequences.md`, et écrit `scenario_notes.md` (fil de l'histoire, éléments récurrents avec premier plan et retours, intention de chaque plan en une phrase, arbitrages, style) ; **chaque plan** a été animé après relecture de sa ligne, de la précédente et de la suivante, au service de son intention, **sans rien inventer** ni oublier.
- [ ] Étape 14 : chaque plan est livré en **une page `planN.html` autonome** publiée en artefact (SVG intégrés, détourage, objets du fond vers le devant, éléments en code, chronologie complète, lecteur avec pause et barre de temps), **avec l'audio du plan intégré en base64 dans la page** (sauf le plan 64), **sans montage** ; les SVG d'origine ne sont jamais modifiés, le fond de détourage n'est jamais visible ; aucun élément n'a été dessiné sans être demandé.
- [ ] Étape 14 : **avant chaque livraison**, tu as capturé au moins 4 images clés, les as **regardées de près** et comparées au storyboard ; tu as trouvé toi-même les défauts (échelle, perspective, ordre des calques, mouvement figé ou trop faible) et tu n'as jamais dit « terminé » sans vérifier.
- [ ] Étape 14 : **mes crédits ont été ménagés** : lecture unique du README et des directives avec `animation_notes.md`, lecture limitée à la fiche du plan, moteur commun partagé, petites modifications par édition de la page, réponses courtes, `animation_status.md` à jour (avec les liens), et tu m'as prévenu avant tout travail lourd.
- [ ] Étape 14 : pour **chaque plan qui en continue un autre**, tu as exigé le **plan précédent** avant de commencer (sans me le redemander s'il était déjà disponible), repris son **état final tel quel**, et contrôlé le **raccord** (dernière image du précédent comparée à la première du plan), sans écart non voulu et sans modifier le plan précédent.
- [ ] Étape 14 : tu m'as demandé `Registre_exigences_animation.md` **avant tout plan**, tu l'as lu en entier et repassé avant chaque plan et chaque livraison ; **chaque défaut, remarque, demande de modification ou détail que j'ai donné y a été noté par toi, sans doublon** (un sujet qui revient a gagné une ★ au lieu d'une nouvelle ligne), avec sa portée, dans la même réponse que la correction, et tu m'as livré le fichier à jour ; **aucune erreur déjà notée n'est revenue et je n'ai jamais eu à répéter une demande notée** (sinon, le moteur commun a été corrigé).
- [ ] Étape 14 : après chaque plan, une correction est faite **dans la même page** ; le plan suivant n'est commencé qu'après mon « ça marche » ; les 64 plans sont validés.
- [ ] Étape 14 (ClaudeAnimatorAgent) : j'ai fourni l'**arborescence réelle** ; `projet_caa.json` a **64 plans** de 1 à 64, tous les chemins (`speech`, `svg`, `html`) existent dans l'arborescence, `racine` est recopiée avec ses emojis et des `/`, `depot` = `ShaderiaxAnim`, `registre` renseigné ou `null`.
- [ ] Étape 14 (ClaudeAnimatorAgent) : chaque plan a son champ **`depend_de`** (liste, `[]` si indépendant), rempli **par toi** d'après les fiches, `Sequences.md`, `Registre_elements_animation.md` et les `_reutilise.txt` : dépendances **directes**, **sans boucle**, aucun plan cité inexistant, **chaque plan `_reutilise` dépend de son plan source**, le premier plan d'une séquence indépendant sauf réutilisation ou continuité ; **dans le doute, le plan dépend**.
- [ ] Étape 14 (ClaudeAnimatorAgent) : tous les `desactive` valent `false` dans le JSON ; tu m'as expliqué le **blocage** (🔒, plan jamais attribué avant la validation de ceux dont il dépend, déblocage automatique) et la **désactivation** (clic droit ; un plan désactivé n'est jamais attribué et **bloque ses dépendants**) ; le bilan (chaînes, plans indépendants, cas douteux) m'a été remis, le JSON a passé « Vérifier » dans le logiciel sans erreur.
