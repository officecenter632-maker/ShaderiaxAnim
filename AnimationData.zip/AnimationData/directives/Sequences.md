# Découpage du scénario en séquences

Une séquence est une suite de plans consécutifs qui partagent le même décor et les mêmes personnages. Les numéros de plan sont continus de Plan1 à Plan64 ; la colonne « Plans du scénario » donne les numéros d'origine de `Plan_animation.md`. Les assets viennent de `Liste_assets.md`.

**51 séquences, 64 plans.** 41 séquences n'ont qu'un seul plan : le scénario change presque à chaque plan de décor et de teinte.

| Séq. | Plans | Plans du scénario | Durée | Type | Décor et teinte | Assets (liste) | Remarque |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sequence1 | Plan1 à Plan2 | 1.1 à 1.2 | 7 s | décor + personnage | Poste de pilotage, vert olive #6C7A4A (opérateur de dos) | 01 Opérateur de drone, de dos, en camouflage; 12 Drone; 15 Poste de pilotage avec écrans |  |
| sequence2 | Plan3 | 1.3 | 3 s | icône sur fond uni | Fond bleu nuit uni #241E45 | P1 Antenne de brouillage | Antenne de brouillage barrée d'une croix rouge |
| sequence3 | Plan4 | 1.4 | 4 s | décor + personnage | Bureau d'angle vitré, vert menthe #86DDAB (propriétaire, télécommande, satellite) | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 08 Télécommande géante à un bouton, avec mains rondes; 10 Satellite et constellation; 17 Bureau d'angle vitré |  |
| sequence4 | Plan5 | 1.5 | 3 s | interface | Fond jaune doré #F9C96B, téléphone | P4 Téléphone générique; P5 Pouce rond | Tampon fait au montage |
| sequence5 | Plan6 | 1.6 | 5 s | carton | Carton violet #5A1470 à traînées | — | Fond seul, texte au montage |
| sequence6 | Plan7 | 2.1 | 3 s | carton | Carton vert forêt #1E3A14 | — | Fond seul, texte au montage |
| sequence7 | Plan8 | 2.2 | 7 s | carte / infographie | Fond crème #FBF8EA, carte de l'Ukraine + constellation | 10 Satellite et constellation; 11 Carte plate de l'Ukraine |  |
| sequence8 | Plan9 | 2.3 | 6 s | carte / infographie | Fond bleu clair #66C8F7, trois cartes (combiné, drone, radar) | 12 Drone; P1 Combiné radio; P2 Radar sous bouclier |  |
| sequence9 | Plan10 | 2.4 | 4 s | décor + personnage | Tranchée ocre #C98A4B, soldat relié à un satellite | 03 Soldat générique; 20 Tranchée |  |
| sequence10 | Plan11 à Plan12 | 2.5 à 2.6 | 12 s | écran partagé | Écran partagé 50/50 : bleu ciel #A9D6EE / vert olive #6C7A4A | 09 Bâtiment à cinq côtés; P1 Parabole blanche sur maison; P1 Parabole camouflée | Enchaîné sans coupe (2.5 vers 2.6) |
| sequence11 | Plan13 | 3.1 | 5 s | décor + personnage | Poste de commandement de nuit, violet #2A1A55 (trois opérateurs de dos) | 16 Poste de commandement de nuit, mur d'écrans |  |
| sequence12 | Plan14 | 3.2 | 5 s | décor | Bureau turquoise #2EA89E vu du dessus, dossiers et journal | 22 Bureau turquoise avec dossiers; P3 Journal plié; P3 Dossier titré |  |
| sequence13 | Plan15 | 3.3 | 4 s | décor + personnage | Console de nuit, bleu violet #2B1F4F, lune (propriétaire, cadran) | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 23 Console de nuit avec fenêtre et lune; P4 Cadran « VITESSE »; P4 Panneau rond de limitation |  |
| sequence14 | Plan16 à Plan17 | 3.4 à 3.5 | 8 s | carte / infographie | Fond bleu clair #66C8F7, règle de vitesse 0 à 450 | — | Même décor, sans coupe |
| sequence15 | Plan18 | 3.6 | 7 s | carte / infographie | Règle (marqueur vert à 450) puis ciel de nuit #1B1738 (drone, engin à réaction) | 12 Drone; P2 Engin à réaction | Plan en deux temps : à trancher (voir plus bas) |
| sequence16 | Plan19 à Plan20 | 3.7 à 3.8 | 9 s | interface | Fond rouge sombre #5F0000 : quatre badges, puis calendrier orange | 12 Drone; P2 Camion; P2 Jumelles; P4 Calendrier orange | Même fond |
| sequence17 | Plan21 | 4.1 | 3 s | carton | Carton violet #5A1470 à traînées | — | Fond seul, texte au montage |
| sequence18 | Plan22 | 4.2 | 6 s | décor + personnage | Vert sauge #9BA68A, propriétaire « pas moi », parabole camouflée | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 09 Bâtiment à cinq côtés; P1 Parabole camouflée | Plan 27 y revient |
| sequence19 | Plan23 | 4.3 | 7 s | décor + personnage | Fond bordeaux #5E0510, journal, deux silhouettes, propriétaire avec télécommande | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); 08 Télécommande géante à un bouton, avec mains rondes; P3 Journal plié |  |
| sequence20 | Plan24 | 4.4 | 6 s | interface | Fond orange #F28C3A, téléphone, propriétaire au fond | 02 Propriétaire du réseau (costume sombre, plusieurs poses); P4 Téléphone générique |  |
| sequence21 | Plan25 | 4.5 | 7 s | carte / infographie | Fond crème #FBF8EA, contrat et cartes vues du dessus | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 12 Drone; 13 Document (contrat « Conditions d'utilisation », lettre d'intention) | Plan 41 reprend le contrat |
| sequence22 | Plan26 | 4.6 | 4 s | interface | Fenêtre « CORRECTIF » sur fond bleu nuit #1B2A55 | 02 Propriétaire du réseau (costume sombre, plusieurs poses); P4 Fenêtre « CORRECTIF » |  |
| sequence23 | Plan27 | 4.7 | 5 s | décor + personnage | Retour au vert sauge #9BA68A du plan 22, même cadrage | 02 Propriétaire du réseau (costume sombre, plusieurs poses); 09 Bâtiment à cinq côtés | Réutilise le plan 22 |
| sequence24 | Plan28 | 4.8 | 4 s | foule / symboles | Fond bleu clair #66C8F7, foule de dos qui lève la tête vers trois étiquettes | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1) |  |
| sequence25 | Plan29 | 5.1 | 5 s | carton | Carton vert forêt #1E3A14, coupé en deux | — | Fond seul, texte au montage |
| sequence26 | Plan30 à Plan32 | 5.2 à 5.4 | 15 s | décor + personnage | Salle de presse gris-vert #7F9490, écran partagé puis plein écran (pupitres) | 04 Personnage au pupitre (sert pour Trump, Zelensky, Wadephul); 18 Salle de presse gris-vert (pupitre, micros); 05 Responsable ukrainien, sans visage détaillé | Même décor des prises de parole |
| sequence27 | Plan33 à Plan34 | 5.5 à 5.6 | 11 s | décor | Table de négociation ronde vue du dessus, fond bleu clair #8DE3FA, puis brouillard gris #B8BEC4 avec la carte | 19 Table de négociation ronde avec trois jetons; 11 Carte plate de l'Ukraine; 24 Brouillard gris en lobes | Fondu enchaîné de l'un à l'autre |
| sequence28 | Plan35 | 5.7 | 6 s | carton | Carton bordeaux #4A0A28, petit câble depuis la carte de l'Ukraine | 08 Télécommande géante à un bouton, avec mains rondes |  |
| sequence29 | Plan36 à Plan37 | 6.1 à 6.2 | 11 s | foule / symboles | Fond bleu clair #66C8F7, grande foule en quatre groupes, pouces et bulles vides | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1) |  |
| sequence30 | Plan38 | 6.3 | 3 s | carton | Fond violet #4F1C80, trois cases numérotées | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1) | Numéros et cases au montage ? |
| sequence31 | Plan39 à Plan40 | 6.4 à 6.5 | 10 s | foule / symboles | Fond turquoise #3FD6B5, silhouette couronnée au levier, puis balance | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); 07 Silhouette couronnée au levier géant; 14 Balance géante | « Même décor » |
| sequence32 | Plan41 à Plan42 | 6.6 à 6.7 | 10 s | foule / symboles | Fond violet #8E5BD0, contrat qui passe dans la foule, puis drapeau blanc | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); 13 Document (contrat « Conditions d'utilisation », lettre d'intention); P5 Masque comique; P6 Mât avec drapeau blanc |  |
| sequence33 | Plan43 | 6.8 | 5 s | foule / symboles | Fond rouge sombre #3D0A0E, trois étiquettes et loupes | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); P5 Loupe |  |
| sequence34 | Plan44 | 6.9 | 7 s | carton | Carton violet nuit #2B1030 | — | Fond seul, texte au montage |
| sequence35 | Plan45 | 7.1 | 3 s | décor + personnage | Mur à panneaux et rideaux, bleu #2A74BF, trois silhouettes de dos | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); 21 Mur à panneaux, arches et rideaux |  |
| sequence36 | Plan46 à Plan49 | 7.2 à 7.5 | 18 s | décor + personnage | Salle de presse gris-vert #7F9490 : cadenas, ministre au pupitre, caisses, bulle, puzzle | 18 Salle de presse gris-vert (pupitre, micros); P6 Cadenas; 04 Personnage au pupitre (sert pour Trump, Zelensky, Wadephul); P6 Caisses « ÉQUIPEMENT » avec billets; P5 Point d'interrogation; P6 Puzzle incomplet | Même décor, sans coupe |
| sequence37 | Plan50 | 7.6 | 5 s | foule / symboles | Fond bleu clair #66C8F7, foule, point d'interrogation, caisse militaire | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); P2 Caisse de matériel militaire; P5 Point d'interrogation |  |
| sequence38 | Plan51 | 7.7 | 6 s | carton | Carton violet #5A1470 à traînées | — | Fond seul, texte au montage |
| sequence39 | Plan52 | 8.1 | 3 s | carton | Carton bleu roi #3355B8 à formes liquides | — | Fond seul, texte au montage |
| sequence40 | Plan53 | 8.2 | 7 s | décor | Table vue du dessus, fond bleu glacier #A9EEE6, lettre d'intention, trois mains | 13 Document (contrat « Conditions d'utilisation », lettre d'intention) |  |
| sequence41 | Plan54 | 8.3 | 5 s | carte / infographie | Fond crème #FBF8EA, carte de l'Ukraine avec satellite et fil plein | 10 Satellite et constellation; 11 Carte plate de l'Ukraine | Reprend le plan 8 |
| sequence42 | Plan55 | 8.4 | 8 s | carte / infographie | Fond bleu clair #66C8F7, trois cartes, câble et ciseaux | 08 Télécommande géante à un bouton, avec mains rondes; P1 Antenne au sol; P1 Terminal; P6 Ciseaux avec câble |  |
| sequence43 | Plan56 | 8.5 | 4 s | décor | Fond ocre #DDB07A, lettre au pied d'un long chemin vers un satellite | 10 Satellite et constellation; 13 Document (contrat « Conditions d'utilisation », lettre d'intention); P6 Sablier |  |
| sequence44 | Plan57 | 8.6 | 6 s | foule / symboles | Fond bleu #A9D6EE, carte annonce, foule et cœurs | 06 Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1); P5 Cœur |  |
| sequence45 | Plan58 | 9.1 | 4 s | décor + personnage | Retour au poste de pilotage vert olive, un peu assombri | 01 Opérateur de drone, de dos, en camouflage; 15 Poste de pilotage avec écrans | Reprend le plan 1 |
| sequence46 | Plan59 | 9.2 | 5 s | carte / infographie | Fond bleu nuit #1B1738, disque PAYS, constellation, point d'interrogation | 10 Satellite et constellation; P5 Point d'interrogation |  |
| sequence47 | Plan60 | 9.3 | 5 s | carte / infographie | Trois panneaux : violet, bleu, rouge sombre #5F0000 | 08 Télécommande géante à un bouton, avec mains rondes; 09 Bâtiment à cinq côtés; P3 Tour de bureaux |  |
| sequence48 | Plan61 | 9.4 | 5 s | décor | Brouillard gris #B8BEC4, dossier ORDRE | 24 Brouillard gris en lobes; P3 Dossier « ORDRE »; P5 Point d'interrogation | Reprend le plan 34 |
| sequence49 | Plan62 | 9.5 | 4 s | carton | Carton violet #5A1470 à traînées, bulle de commentaires | P5 Bulle de commentaires | Fond seul, texte au montage |
| sequence50 | Plan63 | 9.6 | 6 s | icône sur fond uni | Fond bleu #1277C4, pouce rond | P5 Pouce rond |  |
| sequence51 | Plan64 | 9.7 | 6 s | carton | Écran de fin : dégradé bleu #0A97CE vers #0CD4F3 | — | Fond seul, rien à générer ou presque |

## Points à trancher

1. **Cartons de texte.** Les plans Plan6, Plan7, Plan21, Plan29, Plan35, Plan44, Plan51, Plan52 et Plan62 sont des cartons : une fois le texte retiré (il se fait au montage), il ne reste qu'un fond violet, vert, bordeaux ou bleu à traînées. À générer, ou à faire directement au montage ?
2. **Écran de fin (Plan64).** Dégradé bleu uni sans rien dedans : à faire au montage ?
3. **Plan18 (3.6).** Il a deux temps : la règle de vitesse (2 s), puis un ciel de nuit avec un drone qui poursuit un engin à réaction. L'image serait celle du ciel de nuit, la règle étant reprise du plan précédent au montage ?
4. **Reprises d'un autre plan.** Plan23 (télécommande de Plan4), Plan27 (décor de Plan22), Plan41 (contrat de Plan25), Plan54 (carte de Plan8), Plan58 (poste de Plan1), Plan61 (brouillard de Plan34) : leur prompt joindra l'image validée du plan repris.
