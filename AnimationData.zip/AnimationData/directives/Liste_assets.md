# Liste des assets de l'animation

Les textes et éléments d'interface (cartons, badges, tampons, étiquettes de date, de lieu et de source, règle de vitesse graduée, barres de signal, jauges, pastilles) ne sont pas dans cette liste : ils sont faits au montage, pas générés.

## Éléments clés (une génération chacun)

| # | Asset | Plans |
| --- | --- | --- |
| 1 | Opérateur de drone, de dos, en camouflage | 1.1, 1.2, 9.1 |
| 2 | Propriétaire du réseau (costume sombre, plusieurs poses) | 1.4, 3.3, 4.2 à 4.7 |
| 3 | Soldat générique | 2.4 |
| 4 | Personnage au pupitre (sert pour Trump, Zelensky, Wadephul) | 5.2, 5.4, 7.3, 7.5 |
| 5 | Responsable ukrainien, sans visage détaillé | 5.3 |
| 6 | Silhouettes anonymes de foule, avec les silhouettes en costume (4.3, 7.1) | 4.3, 4.8, 6.1 à 6.8, 7.1, 7.6, 8.6 |
| 7 | Silhouette couronnée au levier géant | 6.4, 6.5 |
| 8 | Télécommande géante à un bouton, avec mains rondes | 1.4, 4.3, 5.7, 8.4, 9.3 |
| 9 | Bâtiment à cinq côtés | 2.5, 4.2, 4.7, 9.3 |
| 10 | Satellite et constellation | 1.4, 2.2, 8.3, 8.5, 9.2 |
| 11 | Carte plate de l'Ukraine | 2.2, 5.6, 8.3 |
| 12 | Drone | 1.1, 2.3, 3.6, 3.7, 4.5 |
| 13 | Document (contrat « Conditions d'utilisation », lettre d'intention) | 4.5, 6.6, 6.7, 8.2, 8.5 |
| 14 | Balance géante | 6.5 |
| 15 | Poste de pilotage avec écrans | 1.1, 1.2, 9.1 |
| 16 | Poste de commandement de nuit, mur d'écrans | 3.1 |
| 17 | Bureau d'angle vitré | 1.4 |
| 18 | Salle de presse gris-vert (pupitre, micros) | 5.2, 5.4, 7.2 à 7.5 |
| 19 | Table de négociation ronde avec trois jetons | 5.5 |
| 20 | Tranchée | 2.4 |
| 21 | Mur à panneaux, arches et rideaux | 7.1 |
| 22 | Bureau turquoise avec dossiers | 3.2 |
| 23 | Console de nuit avec fenêtre et lune | 3.3 |
| 24 | Brouillard gris en lobes | 5.6, 9.4 |

## Petits éléments (planches)

### Planche 1 : télécom

| Élément | Plans |
| --- | --- |
| Parabole blanche sur maison | 2.5 |
| Parabole camouflée | 2.5, 4.2 |
| Antenne au sol | 8.4 |
| Terminal | 8.4 |
| Combiné radio | 2.3 |
| Antenne de brouillage | 1.3 |

### Planche 2 : militaire

| Élément | Plans |
| --- | --- |
| Radar sous bouclier | 2.3 |
| Camion | 3.7 |
| Jumelles | 3.7 |
| Engin à réaction | 3.6 |
| Caisse de matériel militaire | 7.6 |

### Planche 3 : bureau

| Élément | Plans |
| --- | --- |
| Journal plié | 3.2, 4.3 |
| Dossier titré | 3.2 |
| Dossier « ORDRE » | 9.4 |
| Tour de bureaux | 9.3 |

### Planche 4 : interface

| Élément | Plans |
| --- | --- |
| Téléphone générique | 1.5, 4.4 |
| Fenêtre « CORRECTIF » | 4.6 |
| Calendrier orange | 3.8 |
| Cadran « VITESSE » | 3.3 |
| Panneau rond de limitation | 3.3 |

### Planche 5 : symboles

| Élément | Plans |
| --- | --- |
| Pouce rond | 1.5, 9.6 |
| Cœur | 8.6 |
| Loupe | 6.8 |
| Masque comique | 6.6 |
| Bulle de commentaires | 9.5 |
| Point d'interrogation | 7.5, 7.6, 9.2, 9.4 |

### Planche 6 : objets de scène

| Élément | Plans |
| --- | --- |
| Cadenas | 7.2 |
| Ciseaux avec câble | 8.4 |
| Sablier | 8.5 |
| Puzzle incomplet | 7.5 |
| Caisses « ÉQUIPEMENT » avec billets | 7.3 |
| Mât avec drapeau blanc | 6.7 |
