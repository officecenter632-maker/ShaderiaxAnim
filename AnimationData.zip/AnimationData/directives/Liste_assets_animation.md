# Liste des assets d'animation (cumulatif)

Fiche de chaque plan : ce qui se passe, fond, assets, chronologie, montage. Référence : `Registre_elements_animation.md`. Image analysée : `Storyboard/sequenceN/planN.webp` (dépôt `Storyboard`, commit 5e1a8b6). Positions en % de la largeur (x) et de la hauteur (y) de l'image ; taille en % de la hauteur ; rotation en degrés.

**Lot 1 : Plan1 à Plan10.**

**Lot 2 : Plan11 à Plan20.**

**Lot 3 : Plan21 à Plan30.**

**Lot 4 : Plan31 à Plan40.**

**Lot 5 : Plan41 à Plan50.**

**Lot 6 : Plan51 à Plan60.**

**Lot 7 : Plan61 à Plan64.**

---

## Plan1 (1.1) · sequence1 · 4 s

**1. Identité.** Voix off : « Imagine. Tu pilotes un drone au-dessus d'une ligne de front. » Image : `Storyboard/sequence1/plan1.webp`.

**2. Ce qui se passe.** Le plan ouvre la vidéo : poste de pilotage vu de derrière l'opérateur. Le montage part d'un gros plan sur l'écran central (carte avec le drone) puis recule jusqu'à montrer l'opérateur de dos. Rien d'autre ne bouge.

**3. FOND (statique).** Poste de pilotage vide : bureau en bois sur tréteaux, chaise à roulettes, clavier, joystick, écran central éteint, deux écrans latéraux à interfaces en barres. Couleur dominante vert olive #6C7A4A. À retirer : opérateur, carte et drone de l'écran central. À reconstruire : chaise, bureau et clavier derrière l'opérateur. Fond plus large que 16:9 de 15 % (gros plan puis recul). **Origine :** généré ici (`Plan1/01_fond_poste_pilotage_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Carte de l'écran central | Drone sur la carte | Opérateur assis |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | objet (contenu d'écran) | objet | personnage |
| Description | carte vue du ciel : routes beige, champs verts, bâtiments, ligne de front en pointillés rouges, nette | drone quadricoptère vu de dessus, gris foncé | de dos, uniforme et casquette camouflage, assis droit, bottes noires |
| Position et taille | centre (50 %, 27 %), 33 % de large, 24 % de haut, rotation 0° | centre (50 %, 25 %), 8 % de haut, rotation 0° | centre (50 %, 64 %), 40 % de haut, rotation 0° |
| Calque | 2 (sur l'écran du fond) | 3 | 4 (devant la chaise du fond) |
| Animation | visible dès le début, immobile | immobile | immobile |
| États | net | net | assis droit |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | bas du dos, bottes |
| Détourage | #FF00FF (la carte contient du vert) | sans objet (réutilisé) | #FF00FF (uniforme vert) |
| Groupe de génération | seul | avec le contrat (Plan25) | seul |
| Origine | généré ici (`Plan1/03_carte_ecran_central.json`) | réutilise `Plan25/01_groupe_contrat_drone_dessus` (en attente du lot 3), retouche : taille très réduite, posé sur la carte | généré ici (`Plan1/02_operateur_assis.json`) |
| Remarque | recalée sur l'écran du fond | | pose de gauche de l'asset 01 |

**5. Chronologie.** 0 s : fond avec carte et drone, gros plan sur l'écran central ; 1,5 s : début du recul ; 2,5 s : l'opérateur apparaît à l'image par le recul ; 4 s : cadrage large, fin.

**6. MONTAGE.** Gros plan sur l'écran puis recul vers l'opérateur ; badges de crédit en haut à droite ; logo de la chaîne en bas à gauche.

**7. Couverture.** Chaque chose visible est classée FOND, ASSET ou MONTAGE : oui.

**8. Points à trancher.** Le drone est réutilisé du lot 3 : le lot 3 devra être livré avant l'assemblage du plan.

---

## Plan2 (1.2) · sequence1 · 3 s

**1. Identité.** Voix off : « Soudain, ta connexion ralentit. » Image : `Storyboard/sequence1/plan2.webp`.

**2. Ce qui se passe.** Même poste, même cadrage. La connexion se dégrade : l'image de l'écran central se pixellise en gros carrés, la ligne de front devient à peine lisible. L'opérateur passe d'assis droit à penché, une main sur la tête (coupe).

**3. FOND.** Réutilise `Plan1/01_fond_poste_pilotage_vide`, aucune retouche (même cadrage, même teinte #6C7A4A). Écrans latéraux inchangés.

**4. ASSETS**

| Champ | Carte de l'écran (état dégradé) | Opérateur penché |
| --- | --- | --- |
| Technique | 4 code (sur l'image de la carte et du drone) | 6 nouvelle configuration |
| Type | effet | personnage |
| Description | carte et drone pixellisés en gros carrés ; pointillés rouges à peine lisibles | de dos, penché en avant, une main sur la tête, coude levé |
| Position et taille | mêmes que Plan1 | centre (50 %, 64 %), 40 % de haut, ancrage des bottes identique à Plan1 |
| Calque | 2 | 4 |
| Animation | pixellisation de 0,3 s à 1,5 s (ease-in), état final maintenu | coupe à 0,3 s : l'opérateur droit est remplacé par l'opérateur penché |
| États | net puis pixellisé | penché |
| Parties séparées | non | non |
| Fiche de code | `Plan2/02_pixellisation_ecran_code.md` | non |
| Zones cachées | aucune | bras et main reconstruits |
| Détourage | sans objet | #FF00FF (uniforme vert) |
| Groupe de génération | sans objet | seul |
| Origine | fiche de code, sur `Plan1/03_carte_ecran_central` | généré ici (`Plan2/01_operateur_penche_main_tete.json`) |
| Remarque | | coupe, voir Registre F1 |

**5. Chronologie.** 0 s : opérateur droit, carte nette ; 0,3 s : coupe vers l'opérateur penché, début de la pixellisation ; 1,5 s : écran entièrement pixellisé ; 3 s : maintien.

**6. MONTAGE.** Les barres de signal qui passent de quatre à une ; le halo rouge pulsé autour de l'écran ; le badge « CONNEXION LENTE » ; badges de crédit en haut à droite ; logo en bas à gauche.

**7. Couverture.** oui.

**8. Points à trancher.** Coupe ou bras animé : voir Registre F1.

---

## Plan3 (1.3) · sequence2 · 3 s

**1. Identité.** Voix off : « Pas à cause de l'ennemi. » Image : `Storyboard/sequence2/plan3.webp`.

**2. Ce qui se passe.** Fond uni bleu nuit. L'antenne de brouillage entre en « pop » au centre, puis une grande croix rouge la barre.

**3. FOND.** Aplat bleu nuit #241E45, fait au montage. **Origine :** sans objet (MONTAGE).

**4. ASSETS**

| Champ | Antenne de brouillage |
| --- | --- |
| Technique | 1 tel quel |
| Type | icône |
| Description | pylône relais en treillis gris, panneaux émetteurs blancs en haut, socle |
| Position et taille | centre (50 %, 50 %), 62 % de haut, rotation 0° |
| Calque | 1 |
| Animation | entrée en pop à 0 s (0 % à 110 % à 100 %, 0,35 s), immobile ensuite |
| États | un seul |
| Parties séparées | non |
| Fiche de code | non |
| Zones cachées | pylône derrière la croix, reconstruit |
| Détourage | #00FF00 |
| Groupe de génération | seul |
| Origine | généré ici (`Plan3/01_antenne_brouillage.json`) |
| Remarque | l'image montre l'état final avec la croix : la croix est du montage |

**5. Chronologie.** 0 s : pop de l'antenne ; 1,2 s : la croix rouge apparaît ; 3 s : fin.

**6. MONTAGE.** Croix rouge #D81E1E épaisse (forme simple) ; logo en bas à gauche.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan4 (1.4) · sequence3 · 4 s

**1. Identité.** Voix off : « À cause de l'homme qui possède le réseau. » Image : `Storyboard/sequence3/plan4.webp`.

**2. Ce qui se passe.** Le montage zoome d'abord sur la télécommande, puis recule pour révéler le propriétaire assis derrière son bureau, un satellite au-dessus de lui.

**3. FOND.** Pièce du bureau d'angle : baie vitrée, skyline, plantes, meuble, fauteuil. Dominante vert menthe #86DDAB. À retirer : propriétaire, télécommande, satellite, bureau. À reconstruire : fauteuil, bas de la baie. Plus large que 16:9 de 15 %. **Origine :** généré ici (`Plan4/01_fond_bureau_angle_vide.json`).

**4. ASSETS**

| Champ | Propriétaire assis avec télécommande | Bureau d'angle (calque avant) | Satellite |
| --- | --- | --- | --- |
| Technique | 6 | 2 calque séparé | 1 |
| Type | personnage | décor (devant) | objet |
| Description | costume sombre, chemise blanche, cravate rouge, face, télécommande à bouton rouge devant la poitrine | bureau vert foncé en L, livres à gauche, portable à droite | petit satellite blanc, panneaux bleus |
| Position et taille | centre (50 %, 55 %), 38 % de haut | centre (55 %, 74 %), 62 % de large, 22 % de haut | centre (50 %, 21 %), 9 % de large |
| Calque | 2 | 3 (devant le propriétaire) | 2 |
| Animation | visible dès le début, immobile | immobile | immobile (flotte, montage : léger va-et-vient de 1 % en 2 s) |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | bas du buste et bras | dessous du plateau | sans objet |
| Détourage | #00FF00 | #FF00FF | réutilisé |
| Groupe de génération | seul | seul | sans objet |
| Origine | généré ici (`Plan4/03_proprietaire_assis_telecommande.json`) | généré ici (`Plan4/02_bureau_angle_calque_avant.json`) | réutilise `Plan10/03_satellite`, retouche : taille réduite |
| Remarque | la télécommande fait partie de la pose | | |

**5. Chronologie.** 0 s : gros plan sur la télécommande ; 1,5 s : début du recul ; 3 s : plan large avec propriétaire, bureau et satellite ; 4 s : fin.

**6. MONTAGE.** Gros plan puis recul ; logo en bas à gauche.

**7. Couverture.** oui. **8. Points à trancher.** Le satellite vient du Plan10, dans ce même lot.

---

## Plan5 (1.5) · sequence4 · 3 s

**1. Identité.** Voix off : « Cette semaine, il l'a reconnu. » Image : `Storyboard/sequence4/plan5.webp`.

**2. Ce qui se passe.** Sur fond jaune doré, un téléphone au centre affiche une publication. Un pouce rond arrive d'en bas à droite et appuie sur le bouton. Un tampon rouge frappe l'écran.

**3. FOND.** Aplat jaune doré #F9C96B (MONTAGE). **Origine :** sans objet.

**4. ASSETS**

| Champ | Téléphone | Pouce rond |
| --- | --- | --- |
| Technique | 1 | 1 |
| Type | objet | icône |
| Description | boîtier sombre, écran blanc, pastille ronde grise, trois barres grises, bouton arrondi vide | pouce rond sans doigts, couleur chair |
| Position et taille | centre (50 %, 50 %), 66 % de haut | arrivée à (58 %, 80 %), 30 % de haut, rotation −20° |
| Calque | 1 | 2 |
| Animation | visible dès le début, immobile | 0,6 s : monte d'en bas à droite (départ (75 %, 115 %)) ; 1,4 s : appuie sur le bouton (rebond de 3 %) |
| États | un | un |
| Parties séparées | non | non |
| Fiche de code | non | non |
| Zones cachées | partie sous le pouce | sans objet |
| Détourage | #00FF00 | réutilisé |
| Groupe de génération | seul | sans objet |
| Origine | généré ici (`Plan5/01_telephone.json`) | réutilise `Plan63/01_pouce`, retouche : rotation et taille |
| Remarque | | l'image montre un pouce dessiné comme une main ; correction dans le prompt du pouce (Registre G) |

**5. Chronologie.** 0 s : téléphone seul ; 0,6 s : le pouce entre ; 1,4 s : appui ; 1,8 s : tampon ; 3 s : fin.

**6. MONTAGE.** Tampon rouge incliné « RECONNU », traits d'impact, logo.

**7. Couverture.** oui. **8. Points à trancher.** Pouce du Plan63 (lot 7).

---

## Plan6 (1.6) · sequence5 · 5 s

**1. Identité.** Voix off : « Et sur Internet, les gens ont résumé l'affaire en une phrase. » Image : `Storyboard/sequence5/plan6.webp`.

**2. Ce qui se passe.** Carton de chute : fond violet à traînées, le texte s'écrit mot à mot.

**3. FOND.** Carton violet #5A1470 à traînées rose, jaune, cyan. **Origine :** généré ici (`Plan6/01_fond_carton_violet_trainees.json`), source de F03 (réutilisé aux plans 21, 51, 62).

**4. ASSETS.** Aucun (sans objet).

**5. Chronologie.** 0 s : fond ; 0,3 s : le texte s'écrit mot à mot jusqu'à 4 s.

**6. MONTAGE.** Texte du carton « CONDITIONS D'UTILISATION : SE RENDRE SANS CONDITION À LA RUSSIE. » en capitales blanches grasses, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan7 (2.1) · sequence6 · 3 s

**1. Identité.** Voix off : « Revenons en arrière. » Image : `Storyboard/sequence6/plan7.webp`.

**2. Ce qui se passe.** Carton de changement de partie, texte posé sur un fond vert forêt.

**3. FOND.** Vert forêt #1E3A14 à motifs tonaux. **Origine :** généré ici (`Plan7/01_fond_carton_vert_foret.json`), réutilisé au Plan29.

**4. ASSETS.** Aucun.

**5. Chronologie.** 0 s : fond ; 0,2 s : texte ; 3 s : fin.

**6. MONTAGE.** Texte du carton en capitales blanches grasses, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan8 (2.2) · sequence7 · 7 s

**1. Identité.** Voix off : « Depuis le début de l'invasion à grande échelle, l'Ukraine s'appuie sur Starlink, le réseau de satellites de SpaceX. » Image : `Storyboard/sequence7/plan8.webp`.

**2. Ce qui se passe.** Zoom avant lent sur la carte de l'Ukraine, surmontée d'une constellation de dix satellites reliés au pays par des liaisons pointillées.

**3. FOND.** Crème #FBF8EA à pictogrammes discrets. À retirer : carte, satellites, pointillés. Plus large que 16:9 de 10 %. **Origine :** généré ici (`Plan8/01_fond_creme_pictogrammes.json`), réutilisé aux plans 25 et 54.

**4. ASSETS**

| Champ | Carte de l'Ukraine | Constellation (dix satellites) | Liaisons pointillées |
| --- | --- | --- | --- |
| Technique | 1 | 1 (dix copies) | 4 code |
| Type | objet | objet | effet |
| Description | aplat bleu #1E6BB8, avec la Crimée | satellite blanc, panneaux bleus, copié dix fois | pointillés gris-bleu #9AA7B8 |
| Position et taille | centre (50 %, 72 %), 38 % de large, 33 % de haut | deux rangées de 5 en arc, x de 24 % à 77 %, y de 12 % à 32 %, chacun 6 % de large, rotation de −12° à +12° selon le rang | du sommet de la carte vers chaque satellite |
| Calque | 1 | 2 | 3 |
| Animation | visible dès 0 s, immobile | entrée en cascade de 0,3 s à 1,5 s (fondu et montée de 3 %) | tracé de 2,5 s à 3,7 s, pointillés qui avancent |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | `Plan8/03_pointilles_constellation_code.md` |
| Zones cachées | aucune | aucune | sans objet |
| Détourage | #00FF00 | réutilisé | sans objet |
| Groupe de génération | seul | sans objet | sans objet |
| Origine | généré ici (`Plan8/02_carte_ukraine.json`) | réutilise `Plan10/03_satellite` | fiche de code |
| Remarque | | | |

**5. Chronologie.** 0 s : fond et carte ; 0,3 s à 1,5 s : les satellites arrivent ; 2,5 s à 3,7 s : liaisons ; zoom lent jusqu'à 7 s.

**6. MONTAGE.** Zoom avant lent ; logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan9 (2.3) · sequence8 · 6 s

**1. Identité.** Voix off : « Il sert aux communications, aux frappes de drones, à la défense aérienne. » Image : `Storyboard/sequence8/plan9.webp`.

**2. Ce qui se passe.** Trois cartes blanches arrondies entrent l'une après l'autre sur fond bleu clair : combiné radio, drone, radar sous bouclier.

**3. FOND.** Bleu clair #66C8F7 à capsules. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : aucune.

**4. ASSETS**

| Champ | Combiné radio | Drone (trois-quarts) | Radar sous bouclier | Cartes blanches |
| --- | --- | --- | --- | --- |
| Technique | 1 | 6 | 1 | MONTAGE |
| Type | icône | icône | icône | forme simple |
| Description | talkie-walkie vert olive, deux voyants | quadricoptère gris, hélices déployées | parabole radar verte sous dôme clair | rectangles blancs arrondis, mêmes dimensions |
| Position et taille | centre (17 %, 52 %), 48 % de haut | centre (50 %, 52 %), 32 % de large | centre (83 %, 52 %), 40 % de haut | centres (17 %, 50 %), (50 %, 50 %), (83 %, 50 %), 31 % de large, 50 % de haut |
| Calque | 3 | 3 | 3 | 2 |
| Animation | entre avec sa carte (entrée 0,3 s) | entrée 1,3 s | entrée 2,3 s | pop l'une après l'autre : 0,3 s, 1,3 s, 2,3 s |
| États | un | un | un | sans objet |
| Parties séparées | non | non | non | sans objet |
| Fiche de code | non | non | non | non |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | #FF00FF | #FF00FF | #FF00FF | sans objet |
| Groupe de génération | un groupe de trois, vide net | idem | idem | sans objet |
| Origine | généré ici (`Plan9/01_groupe_combine_drone_radar.json`) | idem | idem | MONTAGE |
| Remarque | | | dôme rendu opaque (pas de transparence) | |

**5. Chronologie.** 0 s : fond ; 0,3 s : carte 1 ; 1,3 s : carte 2 ; 2,3 s : carte 3 ; 6 s : fin.

**6. MONTAGE.** Cartes blanches et leur entrée ; étiquettes éventuelles ; logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan10 (2.4) · sequence9 · 4 s

**1. Identité.** Voix off : « Pour les soldats, c'est un nerf de la guerre. » Image : `Storyboard/sequence9/plan10.webp`.

**2. Ce qui se passe.** Le soldat se tient debout dans la tranchée. Un câble épais, comme un nerf, relie son casque au satellite en haut ; il pulse lentement. Le montage recule depuis le casque.

**3. FOND.** Tranchée vide, talus ocre #C98A4B, ciel clair. À retirer : soldat, câble, satellite. Plus large que 16:9 de 10 %. **Origine :** généré ici (`Plan10/01_fond_tranchee_vide.json`).

**4. ASSETS**

| Champ | Soldat | Satellite | Câble « nerf » |
| --- | --- | --- | --- |
| Technique | 1 | 1 | 4 code |
| Type | personnage | objet | effet |
| Description | uniforme et casque vert olive, debout, face | corps blanc, panneaux bleus | câble blanc-bleu épais en S |
| Position et taille | centre (50 %, 67 %), 44 % de haut | centre (50 %, 10 %), 17 % de large | de (50 %, 52 %) à (50 %, 16 %) |
| Calque | 2 | 2 | 3 |
| Animation | visible dès 0 s, immobile | visible dès 0 s, immobile | 0,4 s : tracé en 0,8 s ; pulsation en boucle de 1,6 s |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | `Plan10/04_cable_nerf_code.md` |
| Zones cachées | aucune | aucune | sans objet |
| Détourage | #FF00FF | #00FF00 | sans objet |
| Groupe de génération | seul | seul | sans objet |
| Origine | généré ici (`Plan10/02_soldat.json`) | généré ici (`Plan10/03_satellite.json`), source des satellites des plans 4, 8, 54, 55, 56, 59 | fiche de code |
| Remarque | | | |

**5. Chronologie.** 0 s : tranchée, soldat, satellite ; 0,4 s : le câble se trace ; 1,2 s à 4 s : pulsation ; recul depuis le casque.

**6. MONTAGE.** Recul depuis le casque ; logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan11 (2.5) · sequence10 · 8 s

**1. Identité.** Voix off : « Il existe deux versions : Starlink, civile, et Starshield, la version militaire, que Musk affirme sous contrôle du gouvernement américain. » Image : `Storyboard/sequence10/plan11.webp`.

**2. Ce qui se passe.** Écran partagé. À gauche, la version civile : une maison avec une parabole blanche. À droite, la version militaire : une parabole camouflée, une flèche blanche, puis le bâtiment à cinq côtés (le gouvernement américain). Les étiquettes de chaque version sont du montage.

**3. FOND (aplats, MONTAGE).** Deux aplats séparés par un liséré blanc vertical : bleu ciel #A9D6EE à gauche, vert olive #6C7A4A à droite. Le liséré est à 41 % de la largeur sur l'image (et non à 50 % comme annoncé au registre) : on suit l'image. Aucune génération. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Maison et parabole blanche | Parabole camouflée | Bâtiment à cinq côtés | Flèche blanche |
| --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel | MONTAGE |
| Type | objet | objet | objet | forme simple |
| Description | maison à toit rouge, murs crème, parabole blanche sur le toit | parabole à motif camouflage sur trépied, inclinée vers le haut à droite | pentagone gris clair à anneaux, cour verte, bord blanc | flèche épaisse crème, pointe à droite |
| Position et taille | centre (19 %, 48 %), 56 % de haut | centre (55 %, 50 %), 50 % de haut | centre (85 %, 46 %), 42 % de haut | centre (67 %, 49 %), 8 % de large |
| Calque | 2 | 2 | 2 | 3 |
| Animation | pop de 0,3 s, à 0,3 s | pop de 0,3 s, à 2,5 s | pop de 0,3 s, à 3,8 s | tracée de gauche à droite en 0,4 s, à 3,3 s |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | non | non |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | #FF00FF | #FF00FF | #FF00FF | sans objet |
| Groupe de génération | un groupe de trois, vide net | idem | idem | sans objet |
| Origine | généré ici (`Plan11/01_groupe_maison_parabole_camouflee_pentagone.json`) | idem | idem, source du bâtiment des plans 12, 22, 27 et 60 | MONTAGE |
| Remarque | atténuée au Plan12 | source de la parabole des plans 12, 22 et 27 (agrandie) | bien visible, de taille moyenne (correction du Plan22) | |

**5. Chronologie (estimée, à caler sur la voix).** 0 s : écran partagé vide ; 0,3 s : la maison ; 2,5 s : la parabole camouflée ; 3,3 s : la flèche ; 3,8 s : le bâtiment ; 8 s : fin.

**6. MONTAGE.** Les deux aplats et le liséré, la flèche, les étiquettes de texte des deux versions, le logo.

**7. Couverture.** Chaque chose visible est classée FOND, ASSET ou MONTAGE : oui.

**8. Points à trancher.** Le liséré est à 41 %, pas à 50 % : le montage reprend la position de l'image, sauf avis contraire.

---

## Plan12 (2.6) · sequence10 · 4 s

**1. Identité.** Voix off : « Garde ce détail en tête. Il va devenir très important. » Image : `Storyboard/sequence10/plan12.webp`.

**2. Ce qui se passe.** Même écran partagé que le Plan11, sans coupe. La moitié gauche (version civile) s'atténue, pâlit et s'efface ; l'attention va à la moitié droite. Zoom avant sur l'étiquette de droite, cercle rouge autour d'elle, puis masque d'encre violet nuit qui emmène vers le plan suivant.

**3. FOND.** Réutilise les deux aplats du Plan11 (montage), mêmes positions. **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Maison et parabole blanche | Parabole camouflée | Bâtiment à cinq côtés |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel |
| Position et taille | identiques au Plan11 | identiques au Plan11 | identiques au Plan11 |
| Calque | 2 | 2 | 2 |
| Animation | visible dès 0 s ; opacité 100 % puis 35 % entre 0,3 s et 1,3 s, puis fondu complet | immobile | immobile |
| États | net puis atténué | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | sans objet | sans objet |
| Groupe de génération | sans objet | sans objet | sans objet |
| Origine | réutilise `Plan11/01_groupe_maison_parabole_camouflee_pentagone`, retouche : atténuation | réutilise `Plan11/01_…`, aucune retouche | réutilise `Plan11/01_…`, aucune retouche |
| Remarque | la moitié gauche du fond s'atténue aussi | | |

**5. Chronologie.** 0 s : écran du Plan11 ; 0,3 s à 1,3 s : la moitié gauche s'atténue ; 1,3 s : zoom avant sur l'étiquette de droite, cercle rouge #D81E1E tracé autour ; 3,2 s : masque d'encre violet nuit #2A1A55 ; 4 s : fin.

**6. MONTAGE.** Atténuation et fondu de la moitié gauche, zoom, cercle rouge, masque d'encre, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan13 (3.1) · sequence11 · 5 s

**1. Identité.** Voix off : « Mi-octobre. Du jour au lendemain, des unités ukrainiennes perdent leur connexion. » Image : `Storyboard/sequence11/plan13.webp`.

**2. Ce qui se passe.** La nuit de la panne, dans un poste de commandement : trois opérateurs de dos devant un mur de douze écrans. Les écrans passent du vert au gris, un halo rouge pulse autour du mur. Le montage recule lentement.

**3. FOND (statique).** Poste de commandement vide : mur de douze écrans éteints (quatre colonnes, trois rangées), long bureau avec deux caissons à tiroirs, sol, murs latéraux. Dominante violet #2A1A55. À retirer : opérateurs, fauteuils, portables, halo. À reconstruire : bas du mur d'écrans et plateau du bureau. Fond plus large que 16:9 de 10 % (recul). **Origine :** généré ici (`Plan13/01_fond_poste_commandement_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Contenu des écrans | Halo rouge | Trois opérateurs |
| --- | --- | --- | --- |
| Technique | MONTAGE | MONTAGE | 6 nouvelle configuration |
| Type | effet | effet | personnage (groupe de trois) |
| Description | douze aplats : vert, puis gris #5A5A66 | lueur rouge #D81E1E autour du mur | assis de dos sur fauteuil violet, ordinateur portable ouvert devant chacun ; celui du centre a un chignon |
| Position et taille | mur : x de 15 % à 85 %, y de 7 % à 56 % | autour du mur, 6 % de large | gauche (25 %, 70 %), centre (50 %, 70 %), droite (77 %, 70 %), chacun 48 % de haut |
| Calque | 2 (sur les écrans du fond) | 3 | 4 (devant le bureau) |
| Animation | vert dès 0 s, gris à 1 s | pulsation de 1,2 s, dès 1,5 s | visibles dès 0 s, immobiles |
| États | vert puis gris | un | assis |
| Parties séparées | non | non | non (trois figures séparées par un vide net dans la génération) |
| Fiche de code | non | non | non |
| Zones cachées | sans objet | sans objet | bas du dos, cuisses, pied des fauteuils |
| Détourage | sans objet | sans objet | #00FF00 (vêtements bleu nuit, fauteuils violets) |
| Groupe de génération | sans objet | sans objet | un groupe de trois |
| Origine | MONTAGE | MONTAGE | généré ici (`Plan13/02_trois_operateurs_dos.json`) |
| Remarque | | | |

**5. Chronologie.** 0 s : écrans verts, opérateurs assis ; 1 s : les écrans passent au gris ; 1,5 s : le halo rouge apparaît et pulse ; 0 s à 5 s : recul lent ; 5 s : fin.

**6. MONTAGE.** Contenu et changement de couleur des écrans, halo, recul, étiquettes de date, de lieu et de source, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan14 (3.2) · sequence12 · 5 s

**1. Identité.** Voix off : « Selon des sources du ministère ukrainien de la Défense citées par le Kyiv Post, » Image : `Storyboard/sequence12/plan14.webp`.

**2. Ce qui se passe.** Vue du dessus d'un bureau turquoise couvert de dossiers. Au centre, un dossier beige et un journal plié. En bas, deux mains rondes tiennent un document et glissent. Le montage dézoome.

**3. FOND (statique).** Bureau turquoise #2EA89E vu du dessus, dossiers bleus, orange et beige et feuilles volantes sur les bords. À retirer : journal, dossier beige du centre, mains et document. À reconstruire : le bureau du centre et du bas. Fond plus large que 16:9 de 20 % (dézoom). **Origine :** généré ici (`Plan14/01_fond_bureau_turquoise_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Dossier beige | Journal plié | Mains et document |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | objet | objet | objet |
| Description | dossier fermé à étiquette vide, feuilles qui dépassent | journal vu du dessus, bandeau et photo gris | deux mains rondes sortant de manches bleues, sur une feuille blanche |
| Position et taille | centre (40 %, 44 %), 41 % de haut, rotation 0° | centre (66 %, 45 %), 27 % de large, rotation +8° (sens horaire) | centre (52 %, 86 %), 33 % de large, coupé par le bas de l'image |
| Calque | 2 | 2 | 3 |
| Animation | visible dès 0 s, immobile | visible dès 0 s, immobile | entre par le bas à 0,5 s, glisse de 6 % vers la droite en 2 s |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | feuille entière et manches, coupées par le bas |
| Détourage | #00FF00 | #00FF00 | #00FF00 |
| Groupe de génération | un groupe de deux, vide net | idem | seul |
| Origine | généré ici (`Plan14/02_groupe_journal_dossier.json`) | idem ; source du journal du Plan23 | généré ici (`Plan14/03_mains_document.json`) |
| Remarque | | le Plan23 l'agrandit et l'incline à −15° | |

**5. Chronologie.** 0 s : bureau, dossier et journal, cadrage serré ; 0,5 s : les mains entrent et glissent ; 0 s à 5 s : dézoom ; 5 s : fin.

**6. MONTAGE.** Titres écrits (« MINISTÈRE DE LA DÉFENSE », « KYIV POST »), glissement des mains, dézoom, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan15 (3.3) · sequence13 · 4 s

**1. Identité.** Voix off : « … SpaceX aurait instauré pendant la nuit une limite de vitesse, sans prévenir. » Image : `Storyboard/sequence13/plan15.webp`.

**2. Ce qui se passe.** À la console de nuit, le propriétaire du réseau, souriant, tend le bras vers un gros cadran et le tourne : l'aiguille descend, la limite est abaissée. À droite, un panneau rond de limitation apparaît, vide.

**3. FOND (statique).** Console de nuit vide : plateau avec écrans verts, leviers, boutons et voyants ; fenêtre à trois vitres sur un ciel étoilé ; sol. Dominante bleu violet #2B1F4F. À retirer : propriétaire, cadran, flèches, panneau. À reconstruire : partie gauche du plateau, boutons et vitre de gauche cachés par le propriétaire. Fond plus large que 16:9 de 10 % (zoom lent). **Origine :** généré ici (`Plan15/01_fond_console_nuit_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Cadran : socle et boîtier | Cadran : bague et aiguille | Panneau rond | Propriétaire |
| --- | --- | --- | --- | --- |
| Technique | 3 décomposé | 3 décomposé | 1 tel quel | 6 nouvelle configuration |
| Type | objet | objet (pièce mobile) | objet | personnage |
| Description | disque sombre gradué, enveloppe, flèche courbe à deux pointes au-dessus | anneau gris clair et aiguille noire à midi, centre vide | disque blanc vide, large bord rouge | de profil tourné vers la droite, bras droit tendu, main ouverte, souriant, entier |
| Position et taille | centre (42 %, 60 %), 27 % de haut | même centre (42 %, 60 %), 27 % de haut | centre (62,5 %, 62,5 %), 22 % de haut | centre (28 %, 59 %), 73 % de haut |
| Calque | 2 | 3 | 2 | 4 (la main passe devant le cadran) |
| Animation | visible dès 0 s, immobile | rotation de 0° à −60° autour de son centre, 1 s, ease-in-out, de 0,4 s à 1,4 s | pop de 0,3 s à 2 s | visible dès 0 s, immobile |
| États | un | aiguille à midi puis à −60° | un | un |
| Parties séparées | oui | oui | non | non |
| Fiche de code | non | non | non | non |
| Zones cachées | face sous l'aiguille | aucune | aucune | main (cachée par le cadran), jambe arrière |
| Détourage | #00FF00 | #00FF00 | #00FF00 | #00FF00 |
| Groupe de génération | un groupe de trois, vide net | idem | idem | seul |
| Origine | généré ici (`Plan15/03_groupe_cadran_panneau.json`) | idem | idem | généré ici (`Plan15/02_proprietaire_profil_cadran.json`) |
| Remarque | point d'attache : console | point d'attache : centre du cadran | | pose de profil de l'asset 02 |

**5. Chronologie.** 0 s : console, propriétaire, cadran ; 0,4 s à 1,4 s : l'aiguille tourne ; 2 s : le panneau rond apparaît (pop) ; 0 s à 4 s : zoom lent ; 4 s : fin.

**6. MONTAGE.** Zoom lent, pop du panneau, éventuel chiffre à l'intérieur (hors image), logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan16 (3.4) · sequence14 · 3 s

**1. Identité.** Voix off : « Environ 160 kilomètres par heure. » Image : `Storyboard/sequence14/plan16.webp`.

**2. Ce qui se passe.** Sur un fond bleu clair, une règle horizontale graduée de 0 à 450 se trace ; un marqueur rouge glisse et s'arrête à 160. L'image est le fond seul : la règle et le marqueur sont du montage.

**3. FOND (statique).** Bleu clair #66C8F7 à capsules arrondies en diagonale (nuances #98D8F8 et #48C8F8). Fond plus large que 16:9 de 15 %. **Origine :** généré ici (`Plan16/01_fond_bleu_capsules.json`). Ce fond sert aussi aux plans 9, 17, 28, 36, 37, 50 et 55.

**4. ASSETS.** Aucun. Règle, graduations et marqueur : MONTAGE.

**5. Chronologie.** 0 s : fond ; 0,3 s : la règle se trace ; 1 s : le marqueur part de 0 ; 2,3 s : il s'arrête à 160 ; 3 s : fin.

**6. MONTAGE.** Règle graduée de 0 à 450, marqueur rouge, chiffres, logo.

**7. Couverture.** oui. **8. Points à trancher.** Ce fond débloque le Plan9 (lot 1), qui le réutilise.

---

## Plan17 (3.5) · sequence14 · 5 s

**1. Identité.** Voix off : « Des soldats signalent des coupures entre 72 et 161 kilomètres par heure. » Image : `Storyboard/sequence14/plan17.webp`.

**2. Ce qui se passe.** Même règle que le plan précédent, sans coupe de décor : une zone rouge translucide se trace entre 72 et 161, avec ses deux repères.

**3. FOND.** Réutilise `Plan16/01_fond_bleu_capsules`, retouche : miroir horizontal. **Origine :** réutilisé.

**4. ASSETS.** Aucun. Règle, zone rouge #D81E1E, repères : MONTAGE.

**5. Chronologie.** 0 s : règle ; 0,5 s : zone rouge entre 72 et 161 ; 1,5 s : les deux repères ; 2 s : textes ; 5 s : fin.

**6. MONTAGE.** Règle de 0 à 450, zone rouge, repères, « 72–161 KM/H », « COUPURES SIGNALÉES PAR DES SOLDATS », logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan18 (3.6) · sequence15 · 7 s

**1. Identité.** Voix off : « Or l'Ukraine voudrait pouvoir monter à 450, pour que ses drones intercepteurs poursuivent des engins à réaction plus rapides. » Image : `Storyboard/sequence15/plan18.webp`.

**2. Ce qui se passe.** Plan en deux temps. Pendant 2 s, la règle de vitesse avec le marqueur vert à 450 (montage, reprise de la règle du plan précédent). Puis un ciel de nuit : un petit drone poursuit un engin à réaction plus grand, qui s'éloigne ; l'écart est net. Travelling latéral.

**3. FOND (aplat, MONTAGE).** Ciel de nuit uni #1B1738 (l'image mesure environ #141334 : écart faible). **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Drone (vue de côté) | Engin à réaction | Traînées |
| --- | --- | --- | --- |
| Technique | 6 nouvelle configuration | 6 nouvelle configuration | MONTAGE |
| Type | objet | objet | effet |
| Description | quadricoptère gris foncé de profil, tourné vers la droite | avion de chasse gris clair de profil, flamme bleue à l'arrière | traînées horizontales fines derrière chacun |
| Position et taille | centre (22 %, 49 %), 14 % de large | centre (84 %, 45 %), 28 % de large | derrière chaque engin |
| Calque | 3 | 3 | 2 |
| Animation | glisse vers la droite de 4 % en 5 s | glisse vers la droite de 8 % en 5 s (l'écart augmente) | suivent chaque engin |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | arrière du drone | arrière de l'avion | sans objet |
| Détourage | #FF00FF | #FF00FF | sans objet |
| Groupe de génération | un groupe de deux, vide net | idem | sans objet |
| Origine | généré ici (`Plan18/01_groupe_drone_cote_jet.json`) | idem | MONTAGE |
| Remarque | troisième vue du drone (les autres : Plan9, Plan25) | | |

**5. Chronologie.** 0 s à 2 s : règle avec marqueur vert à 450 (montage) ; 2 s : le ciel de nuit, le drone et l'engin ; 2 s à 7 s : travelling latéral, l'engin s'éloigne ; 7 s : fin.

**6. MONTAGE.** Règle et marqueur vert à 450 (2 premières secondes), aplat du ciel, traînées, travelling, logo.

**7. Couverture.** oui. **8. Points à trancher.** Le registre propose l'aplat au montage pour la règle : appliqué.

---

## Plan19 (3.7) · sequence16 · 6 s

**1. Identité.** Voix off : « Résultat : des missions de drones perturbées, des drones perdus, la logistique et la reconnaissance ralenties. » Image : `Storyboard/sequence16/plan19.webp`.

**2. Ce qui se passe.** Quatre tuiles rouges arrondies, de même taille, entrent une par une. Chacune porte une icône : un drone, le même drone barré d'une croix rouge, un camion, des jumelles.

**3. FOND (aplat, MONTAGE).** Rouge sombre #5F0000 (l'image mesure environ #440202 : à vérifier au montage). **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Tuiles rouges | Drone | Drone barré | Camion | Jumelles |
| --- | --- | --- | --- | --- | --- |
| Technique | MONTAGE | 1 tel quel | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | forme simple | icône | icône | icône | icône |
| Description | rectangles rouges arrondis, bord rouge clair | quadricoptère trois-quarts avant | même drone, croix rouge en plus | camion militaire vert olive à bâche, de côté | jumelles noires et olive, lentilles bleues |
| Position et taille | centres x = 13,9 %, 38 %, 62 %, 86,2 %, y = 47,7 %, 22 % de large, 39 % de haut | centre (13,9 %, 47,7 %), 19 % de large | centre (38 %, 47,7 %), 19 % de large | centre (62 %, 48 %), 19 % de large | centre (86,2 %, 48 %), 17 % de large |
| Calque | 2 | 3 | 3 (croix : 4) | 3 | 3 |
| Animation | pop l'une après l'autre : 0,5 s, 1,7 s, 2,9 s, 4,1 s | avec la tuile 1 | avec la tuile 2 | avec la tuile 3 | avec la tuile 4 |
| États | un | un | un | un | un |
| Parties séparées | non | non | non | non | non |
| Fiche de code | non | non | non | non | non |
| Zones cachées | sans objet | aucune | aucune | aucune | aucune |
| Détourage | sans objet | sans objet (réutilisé) | sans objet | #FF00FF | #FF00FF |
| Groupe de génération | sans objet | sans objet | sans objet | un groupe de deux, vide net | idem |
| Origine | MONTAGE | réutilise `Plan9/01_groupe_combine_drone_radar` (lot 1), retouche : taille | idem, plus croix rouge en montage | généré ici (`Plan19/01_groupe_camion_jumelles.json`) | idem |
| Remarque | | | croix #D81E1E, tracée au montage | | |

**5. Chronologie (estimée, à caler sur la voix).** 0 s : fond ; 0,5 s : tuile 1 ; 1,7 s : tuile 2 puis croix ; 2,9 s : tuile 3 ; 4,1 s : tuile 4 ; 6 s : fin.

**6. MONTAGE.** Tuiles et leur entrée, croix rouge, textes éventuels, logo.

**7. Couverture.** oui. **8. Points à trancher.** Couleur du fond : #5F0000 (scénario) ou la valeur mesurée (voir plus haut).

---

## Plan20 (3.8) · sequence16 · 3 s

**1. Identité.** Voix off : « Et ça dure plus d'une semaine. » Image : `Storyboard/sequence16/plan20.webp`.

**2. Ce qui se passe.** Même fond rouge sombre que le Plan19. Un grand calendrier orange, huit cases vides sur deux rangées de quatre. Les cases se barrent d'une croix rouge, une par une, de plus en plus vite. À la fin, un voile sombre monte vers le carton du plan suivant.

**3. FOND.** Réutilise l'aplat rouge sombre #5F0000 du Plan19 (montage). **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Calendrier | Croix rouges |
| --- | --- | --- |
| Technique | 1 tel quel | 4 code |
| Type | objet | effet |
| Description | en-tête orange #F5A623, deux anneaux bleu sombre, corps blanc, huit cases vides à bord bleu-gris | huit croix rouges, une par case |
| Position et taille | centre (50 %, 46,5 %), 50 % de large, 73 % de haut | centres des huit cases : x = 33,4 / 44,4 / 55,5 / 66,5 %, y = 48 % et 68 % |
| Calque | 2 | 3 |
| Animation | visible dès 0 s, immobile | tracées de 0,4 s à 2,6 s, de plus en plus vite |
| États | un | cases vides puis barrées |
| Parties séparées | non | sans objet |
| Fiche de code | non | `Plan20/02_croix_calendrier_code.md` |
| Zones cachées | aucune | sans objet |
| Détourage | #00FF00 | sans objet |
| Groupe de génération | seul | sans objet |
| Origine | généré ici (`Plan20/01_calendrier.json`) | fiche de code |
| Remarque | regénéré et validé | |

**5. Chronologie.** 0 s : calendrier ; 0,4 s : première croix ; 2,5 s : huitième croix ; 2,6 s à 3 s : voile sombre qui monte ; 3 s : fin.

**6. MONTAGE.** « PLUS D'UNE SEMAINE », voile sombre, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan21 (4.1) · sequence17 · 3 s

**1. Identité.** Voix off : « Qui a donné l'ordre ? » Image : `Storyboard/sequence17/plan21.webp`.

**2. Ce qui se passe.** Carton de changement de partie : fond violet à traînées de couleur, texte au montage.

**3. FOND.** Violet #5A1470 à traînées rose #E86FA8, jaune #F2B01E et cyan #7FD6F0. **Origine :** réutilise `Plan6/01_fond_carton_violet_trainees` (lot 1), retouche : miroir ou rotation pour varier.

**4. ASSETS.** Aucun.

**5. Chronologie.** 0 s : carton ; 0,3 s : le texte entre ; 3 s : fin.

**6. MONTAGE.** Texte « Qui a donné l'ordre ? » en capitales blanches grasses, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan22 (4.2) · sequence18 · 6 s

**1. Identité.** Voix off : « D'abord, Musk laisse entendre qu'il n'y est pour rien : Starshield dépendrait du Pentagone. » Image : `Storyboard/sequence18/plan22.webp`.

**2. Ce qui se passe.** Première version. Le propriétaire du réseau, mains levées paumes ouvertes, dit « pas moi ». À sa droite, la parabole camouflée ; une flèche rouge part de la parabole vers le bâtiment à cinq côtés, en haut à droite. Zoom avant lent.

**3. FOND (aplat, MONTAGE).** Vert sauge #9BA68A (l'image mesure environ #A1AC8F). Ellipses d'ombre sous les pieds du propriétaire et sous la parabole : montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Bâtiment à cinq côtés | Parabole camouflée | Flèche rouge | Propriétaire |
| --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 4 code | 6 nouvelle configuration |
| Type | objet | objet | effet | personnage |
| Description | pentagone gris clair à anneaux, cour verte | parabole camouflée sur trépied, inclinée vers le haut à droite | flèche rouge courbe | debout, de face, mains levées paumes ouvertes, cravate rouge |
| Position et taille | centre (88 %, 20 %), 32 % de haut (agrandi : l'image le montre à 24 %) | centre (65 %, 59 %), 50 % de haut | de (70 %, 38 %) à (82 %, 22 %) | centre (40,5 %, 53 %), 70 % de haut |
| Calque | 2 | 2 | 3 | 3 |
| Animation | pop de 0,3 s à 1,6 s | visible dès 0 s | tracé en 0,6 s à 2,2 s | visible dès 0 s, immobile |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | `Plan22/02_trace_fleche_courbe_code.md` (variante A) | non |
| Zones cachées | aucune | aucune | sans objet | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | sans objet | #00FF00 |
| Groupe de génération | sans objet | sans objet | sans objet | seul |
| Origine | réutilise `Plan11/01_groupe_maison_parabole_camouflee_pentagone`, retouche : taille | réutilise `Plan11/01_…`, retouche : agrandie | fiche de code | généré ici (`Plan22/01_proprietaire_mains_levees.json`) |
| Remarque | correction : bien visible, de taille moyenne | | | pose « pas moi » de l'asset 02 |

**5. Chronologie.** 0 s : fond, propriétaire, parabole ; 1,6 s : le bâtiment apparaît ; 2,2 s : la flèche se trace ; 0 s à 6 s : zoom avant lent ; 6 s : fin.

**6. MONTAGE.** Fond en aplat, ombres au sol, zoom, étiquette « selon lui », logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan23 (4.3) · sequence19 · 7 s

**1. Identité.** Voix off : « Puis le Wall Street Journal publie, en citant des responsables américains, que c'est bien lui qui a ordonné le ralentissement. » Image : `Storyboard/sequence19/plan23.webp`.

**2. Ce qui se passe.** Deuxième version. À gauche, le journal ; à côté, deux silhouettes en costume sans visage ; à droite, le propriétaire tient la télécommande géante. Une flèche rouge relie le journal au propriétaire. Gros plan sur le titre puis recul.

**3. FOND (aplat, MONTAGE).** Bordeaux #5E0510 (l'image mesure environ #500511). Ellipses d'ombre sous les pieds : montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Journal plié | Deux silhouettes en costume | Propriétaire avec télécommande | Flèche rouge |
| --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 6 nouvelle configuration | 6 nouvelle configuration | 4 code |
| Type | objet | personnage (groupe de deux) | personnage | effet |
| Description | journal vu du dessus, bandeau et photo gris | deux hommes en costume, de face, sans visage, cravate rouge | debout, de face, télécommande géante à bouton rouge tenue à deux mains | flèche rouge courbe |
| Position et taille | centre (17,5 %, 55,5 %), 29 % de large, rotation −15° | centre (56 %, 50 %), 63 % de haut ; centres x = 50 % et 62,5 % | centre (84 %, 50 %), 71 % de haut | de (20 %, 33 %) à (74 %, 30 %), au-dessus des silhouettes |
| Calque | 2 | 2 | 3 | 4 |
| Animation | entre par la gauche à 0,3 s | pop à 0,8 s | pop à 1,2 s | tracé en 0,9 s à 1,6 s |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | non | `Plan22/02_trace_fleche_courbe_code.md` (variante B) |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | sans objet (réutilisé) | #00FF00 | #00FF00 | sans objet |
| Groupe de génération | sans objet | un groupe de deux | seul | sans objet |
| Origine | réutilise `Plan14/02_groupe_journal_dossier`, retouche : taille et rotation | généré ici (`Plan23/01_silhouettes_costume_face.json`) | généré ici (`Plan23/02_proprietaire_telecommande_debout.json`) | fiche de code |
| Remarque | | source des silhouettes en costume du Plan45 (par configuration) | la télécommande fait partie de la pose | correction : arrive sur le propriétaire, pas sur les silhouettes |

**5. Chronologie.** 0 s : fond, gros plan sur le journal ; 0,3 s : le journal ; 0,8 s : les silhouettes ; 1,2 s : le propriétaire ; 1,6 s : la flèche ; 2 s à 7 s : recul ; 7 s : fin.

**6. MONTAGE.** Fond, ombres, titres (« WALL STREET JOURNAL », « RALENTIR »), gros plan puis recul, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan24 (4.4) · sequence20 · 6 s

**1. Identité.** Voix off : « Quelques jours plus tard, sur X, il l'admet : oui, SpaceX a bridé le service. » Image : `Storyboard/sequence20/plan24.webp`.

**2. Ce qui se passe.** Troisième version. Un grand téléphone affiche une publication (pastille, barres grises, bouton vide). Derrière lui, le propriétaire, plus petit, hausse les épaules. Un tampon rouge incliné arrive par-dessus.

**3. FOND (aplat, MONTAGE).** Orange #F28C3A. Ellipse d'ombre sous le téléphone : montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Propriétaire | Téléphone |
| --- | --- | --- |
| Technique | 6 nouvelle configuration | 2 calque devant le propriétaire |
| Type | personnage | objet |
| Description | un seul, de face, épaules haussées, paumes ouvertes de chaque côté, bouche en moue gênée | smartphone de face, publication (pastille, barres, bouton vide) |
| Position et taille | centre (50 %, 45 %), 50 % de haut, la tête dépasse au-dessus du téléphone | centre (50 %, 62 %), 68 % de haut (baissé et réduit par rapport à l'image) |
| Calque | 2 | 3 |
| Animation | apparaît à 0,6 s, haussement d'épaules (montée de 2 % en 0,4 s, retour en 0,4 s) à 1,2 s | visible dès 0 s |
| États | un | un |
| Parties séparées | non | non |
| Fiche de code | non | non |
| Zones cachées | bas du corps, derrière le téléphone | aucune |
| Détourage | #00FF00 | sans objet (réutilisé) |
| Groupe de génération | seul | sans objet |
| Origine | généré ici (`Plan24/01_proprietaire_epaules.json`) | réutilise `Plan5/01_telephone` (lot 1), retouche : taille et position |
| Remarque | correction : un seul propriétaire (l'image en montre deux de part et d'autre) | |

**5. Chronologie.** 0 s : téléphone ; 0,6 s : le propriétaire apparaît derrière ; 1,2 s : haussement d'épaules ; 2,5 s : tampon (montage) ; 6 s : fin.

**6. MONTAGE.** Fond, ombre, tampon rouge incliné « BRIDAGE CONFIRMÉ », logo.

**7. Couverture.** oui. **8. Points à trancher.** Un propriétaire seul derrière un téléphone aussi haut aurait la tête cachée. J'ai baissé le téléphone (centre 62 %) pour que la tête dépasse, et je le dessine de face (le registre disait « de dos » dans la section G, ce qui masquerait l'expression). À confirmer.

---

## Plan25 (4.5) · sequence21 · 7 s

**1. Identité.** Voix off : « Son argument : l'armée ukrainienne aurait violé les conditions d'utilisation en employant un service civil pour des frappes offensives. » Image : `Storyboard/sequence21/plan25.webp`.

**2. Ce qui se passe.** Vue du dessus, fond crème. Au centre, le contrat. À gauche, une carte blanche arrondie avec une parabole blanche ; à droite, une autre avec un drone. Une flèche bleue va de la carte de gauche au contrat, une autre du contrat à la carte de droite (usage civil vers usage offensif). Zoom sur la seconde carte.

**3. FOND.** Crème #FBF8EA à pictogrammes discrets. **Origine :** réutilise `Plan8/01_fond_creme_pictogrammes` (lot 1), retouche : voile clair sur les pictogrammes.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Cartes blanches | Parabole blanche | Contrat | Drone (vue de dessus) | Flèches bleues |
| --- | --- | --- | --- | --- | --- |
| Technique | MONTAGE | 1 tel quel | 1 tel quel | 6 nouvelle configuration | MONTAGE |
| Type | forme simple | icône | objet | icône | forme simple |
| Description | deux rectangles blancs arrondis, mêmes dimensions | parabole blanche sur trépied gris | feuille blanche à bandeau bleu, cachet rouge, signature | quadricoptère gris foncé à liserés olive, hélices claires | deux flèches épaisses bleu #6E9BD1 |
| Position et taille | centres (15,8 %, 48,5 %) et (83,8 %, 48,5 %), 25 % de large, 42 % de haut | centre (18 %, 50 %), 32 % de haut | centre (50,7 %, 48,5 %), 55 % de haut | centre (83,8 %, 48 %), 22,5 % de large | (33,5 %, 49 %) et (66 %, 49 %), 8 % de large |
| Calque | 2 | 3 | 3 | 3 | 3 |
| Animation | pop : carte de gauche à 0,3 s, carte de droite à 3,5 s | avec sa carte | pop à 1,2 s | avec sa carte | tracées : première à 0,9 s, seconde à 3 s |
| États | un | un | un | un | un |
| Parties séparées | non | non | non | non | non |
| Fiche de code | non | non | non | non | non |
| Zones cachées | sans objet | aucune | aucune | aucune | sans objet |
| Détourage | sans objet | #FF00FF | #FF00FF | #FF00FF | sans objet |
| Groupe de génération | sans objet | un groupe de trois, vide net | idem | idem | sans objet |
| Origine | MONTAGE | généré ici (`Plan25/01_groupe_contrat_drone_dessus.json`) | idem, source du contrat des plans 41, 53 et 56 | idem, source du drone du Plan1 | MONTAGE |
| Remarque | | ajoutée à la génération : absente du registre, voir 8 ; le Plan55 la réutilise | | | |

**5. Chronologie.** 0 s : fond ; 0,3 s : carte de gauche ; 0,9 s : première flèche ; 1,2 s : contrat ; 3 s : seconde flèche ; 3,5 s : carte de droite ; 4 s à 7 s : zoom sur la carte de droite ; 7 s : fin.

**6. MONTAGE.** Cartes et flèches, titres des cartes, badge rouge « VIOLATION, SELON LUI », zoom, logo.

**7. Couverture.** oui.

**8. Points à trancher.** La parabole blanche de la carte de gauche est visible dans l'image mais n'était pas annoncée au registre (qui ne la plaçait qu'au Plan55). Je l'ai ajoutée à ce groupe, qui est sa première apparition : le Plan55 la réutilisera et ne la regénérera pas. Le registre est mis à jour dans ce sens. Le drone sert au Plan1 (lot 1 en attente de ce lot).

---

## Plan26 (4.6) · sequence22 · 4 s

**1. Identité.** Voix off : « Selon lui, une faille a été fermée. » Image : `Storyboard/sequence22/plan26.webp`.

**2. Ce qui se passe.** Une fenêtre logicielle « CORRECTIF » sur fond bleu nuit. Une barre rouge (la faille) est barrée, puis remplacée par une barre verte avec une coche. Les autres barres restent blanches. L'image montre l'état final.

**3. FOND (aplat, MONTAGE).** Bleu nuit #1B2A55. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Fenêtre (cadre) | Barres et coche |
| --- | --- | --- |
| Technique | 3 simple (cadre seul) | 4 code |
| Type | objet | effet |
| Description | rectangle arrondi bleu nuit, bande d'en-tête, trois pastilles rouge, jaune, verte | cinq barres arrondies, dont la première rouge puis verte, et une coche verte |
| Position et taille | centre (50 %, 47,5 %), 55 % de large, 61 % de haut | voir la fiche |
| Calque | 2 | 3 |
| Animation | pop de 0,3 s à 0,2 s | barre barrée à 0,8 s, remplacée à 1,6 s, coche à 2,2 s |
| États | un | rouge barrée puis verte avec coche |
| Parties séparées | non | oui (cinq barres et une coche) |
| Fiche de code | non | `Plan26/02_barres_correctif_code.md` |
| Zones cachées | aucune | sans objet |
| Détourage | #FF00FF | sans objet |
| Groupe de génération | seul | sans objet |
| Origine | généré ici (`Plan26/01_fenetre_correctif_vide.json`) | fiche de code |
| Remarque | | correction : la barre rouge barrée précède l'état final |

**5. Chronologie.** 0 s : fenêtre, barres, première barre rouge ; 0,8 s à 1,2 s : barre barrée ; 1,6 s : barre verte ; 2,2 s : coche ; 4 s : fin.

**6. MONTAGE.** Fond, enchaînement des changements de barres, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan27 (4.7) · sequence23 · 5 s

**1. Identité.** Voix off : « Il ajoute que les changements sur Starshield relevaient du gouvernement américain. » Image : `Storyboard/sequence23/plan27.webp`.

**2. Ce qui se passe.** Écho du Plan22, même décor et même cadrage. Le propriétaire est de profil, mains levées. La flèche rouge va de la parabole au bâtiment à cinq côtés. Boucle de la première version.

**3. FOND (aplat, MONTAGE).** Vert sauge #9BA68A, identique au Plan22. **Origine :** réutilise l'aplat du Plan22 (montage).

**4. ASSETS (dynamiques)**

| Champ | Bâtiment à cinq côtés | Parabole camouflée | Flèche rouge | Propriétaire de profil |
| --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 4 code | 6 nouvelle configuration |
| Position et taille | identiques au Plan22 : (88 %, 20 %), 32 % de haut | identiques au Plan22 : (65 %, 59 %), 50 % de haut | de (70 %, 38 %) à (82 %, 22 %) | centre (37 %, 53 %), 70 % de haut |
| Calque | 2 | 2 | 3 | 3 |
| Animation | visible dès 0 s | visible dès 0 s | tracé en 0,6 s à 1,5 s | visible dès 0 s, immobile |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | `Plan22/02_trace_fleche_courbe_code.md` (variante A) | non |
| Zones cachées | aucune | aucune | sans objet | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | sans objet | #00FF00 |
| Groupe de génération | sans objet | sans objet | sans objet | seul |
| Origine | réutilise `Plan11/01_groupe_maison_parabole_camouflee_pentagone`, retouche : taille | réutilise `Plan11/01_…`, retouche : agrandie | fiche de code | généré ici (`Plan27/01_proprietaire_profil_mains_jointes.json`) |
| Remarque | correction : bien visible | | | le prompt demande les mains levées paumes ouvertes (l'image les montrait jointes) ; le nom de fichier reste celui du registre |

**5. Chronologie.** 0 s : fond, propriétaire de profil, parabole, bâtiment ; 1,5 s : la flèche se trace ; 5 s : fin.

**6. MONTAGE.** Fond, ombres au sol, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan28 (4.8) · sequence24 · 4 s

**1. Identité.** Voix off : « Voilà sa version. Maintenant, regarde comment Internet l'a reçue. » Image : `Storyboard/sequence24/plan28.webp`.

**2. Ce qui se passe.** Fin de la partie. Une foule anonyme, de dos, lève la tête vers le haut de l'image, laissé libre pour trois étiquettes qui s'empilent. Zoom lent sur la foule.

**3. FOND.** Bleu clair #66C8F7 à capsules. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : aucune (les capsules sont plus visibles qu'à l'image).

**4. ASSETS (dynamiques)**

| Champ | Foule de dos |
| --- | --- |
| Technique | 6 nouvelle configuration |
| Type | personnage (groupe) |
| Description | bande de silhouettes anonymes de dos, trois rangées, têtes levées, deux bleus plats |
| Position et taille | bande pleine largeur, centre (50 %, 78 %), 44 % de haut, bord du bas au bord de l'image |
| Calque | 2 |
| Animation | monte du bas de l'image en 0,6 s, puis zoom lent |
| États | un |
| Parties séparées | non |
| Fiche de code | non |
| Zones cachées | aucune (le bas est droit) |
| Détourage | #00FF00 |
| Groupe de génération | seul |
| Origine | généré ici (`Plan28/01_foule_dos_tetes_levees.json`) |
| Remarque | une des onze configurations de foule du registre |

**5. Chronologie.** 0 s : fond ; 0,2 s à 0,8 s : la foule monte ; 1 s : première étiquette ; 4 s : fin.

**6. MONTAGE.** Étiquettes « PREMIÈRE / DEUXIÈME / TROISIÈME VERSION », zoom lent, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan29 (5.1) · sequence25 · 5 s

**1. Identité.** Voix off : « Et le service est-il revenu à la normale ? Là encore, les versions divergent. » Image : `Storyboard/sequence25/plan29.webp`.

**2. Ce qui se passe.** Carton vert forêt coupé en deux par un liséré blanc vertical au centre ; il éclate en deux moitiés.

**3. FOND.** Vert forêt #1E3A14 à motifs tonaux. **Origine :** réutilise `Plan7/01_fond_carton_vert_foret` (lot 1), retouche : liséré blanc au centre (x = 50 %), moitié droite en miroir.

**4. ASSETS.** Aucun.

**5. Chronologie.** 0 s : carton ; 0,3 s : le texte ; 3,5 s : éclatement en deux moitiés ; 5 s : fin.

**6. MONTAGE.** Liséré, texte en capitales blanches grasses, éclatement, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan30 (5.2) · sequence26 · 4 s

**1. Identité.** Voix off : « Donald Trump avait assuré que tout fonctionnait à pleine vitesse, » Image : `Storyboard/sequence26/plan30.webp`.

**2. Ce qui se passe.** Début de la séquence des deux versions, en écran partagé. À gauche, un personnage (représentant Trump) parle derrière un pupitre à micros, dans la salle de presse gris-vert. La moitié droite attend : aplat bleu nuit vide.

**3. FOND (écran partagé).** Moitié gauche : salle de presse vide gris-vert #7F9490, recadrée en demi-écran. **Origine :** réutilise `Plan32/01_fond_salle_presse_vide` (lot 4), retouche : recadrage demi-écran. Moitié droite : aplat bleu nuit #232B4A (MONTAGE), qui devient le fond F11 au Plan31. Liséré blanc à 50 %.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Personnage A | Pupitre avec micros | Jauge pleine |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 2 calque devant le personnage | MONTAGE |
| Type | personnage | objet | effet |
| Description | costume sombre, cravate rouge, cheveux bruns, bouche ouverte, de face, jusqu'à la taille | pupitre gris-bleu à trois micros | barre d'une jauge pleine derrière le personnage |
| Position et taille | centre (25,5 %, 38 %), 44 % de haut | centre (25,5 %, 72,5 %), 39 % de haut | derrière le personnage |
| Calque | 2 | 3 | 1 |
| Animation | visible dès 0 s | visible dès 0 s | se remplit à 0,5 s |
| États | un | un | vide puis pleine |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | bas du buste (cachés par le pupitre) | aucune | sans objet |
| Détourage | #00FF00 | sans objet (réutilisé) | sans objet |
| Groupe de génération | seul | sans objet | sans objet |
| Origine | généré ici (`Plan30/01_personnage_a_buste.json`), source des plans 31, 47 et 48 | réutilise `Plan32/02_pupitre_micros` (lot 4) | MONTAGE |
| Remarque | | | |

**5. Chronologie.** 0 s : écran partagé, personnage à gauche ; 0,5 s : la jauge se remplit ; 4 s : fin.

**6. MONTAGE.** Écran partagé et liséré, aplat de droite, jauge, étiquette de nom, animation de la moitié droite, logo.

**7. Couverture.** oui.

**8. Points à trancher.** sans objet : le fond de salle de presse et le pupitre sont livrés avec le lot 4 (Plan32).

---

## Plan31 (5.3) · sequence26 · 5 s

**1. Identité.** Voix off : « … alors qu'un responsable ukrainien affirmait au Kyiv Independent que les restrictions restaient en place. » Image : `Storyboard/sequence26/plan31.webp`.

**2. Ce qui se passe.** L'écran partagé du Plan30 se complète. À gauche, le personnage A reste au pupitre, rien ne change. À droite, le responsable ukrainien se tient de face devant un grand écran aux barres de signal rouges. Une pastille rouge arrondie se pose. Caméra fixe, coupe franche depuis le Plan30.

**3. FOND (écran partagé, deux fonds).** Liséré blanc vertical à 50 % (mesuré à 49,7 %). Moitié gauche : salle de presse vide gris-vert #7F9490, comme au Plan30. **Origine :** réutilise `Plan32/01_fond_salle_presse_vide` (lot 4), retouche : recadrage demi-écran (partie centrale de la largeur). Moitié droite : poste de contrôle vide, dominante bleu nuit #232B4A, grand écran éteint dans un cadre bleu clair (x 53,6 % à 97 %, y 11 % à 48 % de l'image du plan), console à quatre petits écrans en dessous (haut à y 62 %), sol. **Origine :** généré ici (`Plan31/01_fond_poste_controle.json`), utilisé en demi-écran (partie centrale de la largeur : l'écran, la console et le sol y sont gardés).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Barres de signal rouges | Personnage A | Pupitre avec micros | Responsable ukrainien |
| --- | --- | --- | --- | --- |
| Technique | MONTAGE | 1 tel quel | 2 calque devant le personnage | 1 tel quel |
| Type | effet | personnage | objet | personnage |
| Description | huit barres verticales rouges #E8474C de hauteur croissante sur l'écran vide | costume sombre, cravate rouge, bouche ouverte, de face, jusqu'à la taille | pupitre gris-bleu à trois micros | uniforme vert olive, de face, mains dans le dos, visage sans traits |
| Position et taille | de x 56,7 % à 94 %, ligne de base y 44 %, hauteurs de 8 % à 27 % de la hauteur de l'image | centre (25,5 %, 38 %), 44 % de haut | centre (25,5 %, 72,5 %), 38 % de haut, 31 % de large | centre (75,5 %, 58 %), 70 % de haut |
| Calque | 2 (sur l'écran du fond) | 2 | 3 | 3 |
| Animation | visibles dès 0 s | visible dès 0 s, immobile | visible dès 0 s, immobile | visible dès 0 s, immobile |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | non | non |
| Zones cachées | sans objet | bas du buste (cachés par le pupitre) | aucune | aucune |
| Détourage | sans objet | sans objet (réutilisé) | sans objet (réutilisé) | #FF00FF |
| Groupe de génération | sans objet | sans objet | sans objet | seul |
| Origine | MONTAGE | réutilise `Plan30/01_personnage_a_buste`, retouche : aucune | réutilise `Plan32/02_pupitre_micros` (lot 4), retouche : taille | généré ici (`Plan31/02_responsable_ukrainien.json`) |
| Remarque | positions estimées à l'œil | identique au Plan30 | identique au Plan30 | le visage reste sans yeux, sans nez ni bouche |

**5. Chronologie.** 0 s : écran partagé complet, barres rouges visibles ; 1 s : la pastille rouge se pose ; 1,8 s : l'étiquette de source apparaît ; 5 s : fin.

**6. MONTAGE.** Barres rouges, pastille « RESTRICTIONS EN PLACE », étiquette « RESPONSABLE UKRAINIEN », étiquette de source « Kyiv Independent » (noir et blanc), liséré, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan32 (5.4) · sequence26 · 6 s

**1. Identité.** Voix off : « Ensuite, le président Zelensky a annoncé que les vitesses étaient revenues à leur niveau d'avant. » Image : `Storyboard/sequence26/plan32.webp`.

**2. Ce qui se passe.** Retour plein écran dans la salle de presse : un personnage en tenue sobre (cravate dorée, sans la cravate rouge du Plan30) derrière le pupitre et les micros. Derrière lui, une barre de vitesse remonte jusqu'à un repère « AVANT ». Zoom avant sur le personnage, puis recul qui révèle les micros.

**3. FOND (statique).** Salle de presse vide : murs gris-vert #7F9490 à pilastres verticaux, deux fenêtres sombres à reflet diagonal (à gauche : x 0 % à 14 %, y 5 % à 34 % ; à droite : x 86 % à 100 %), grand halo rond clair sur le mur du fond (centre (51 %, 54 %), 52 % de la largeur), sol avec plinthe claire. À retirer : personnage, pupitre, micros. À reconstruire : bas du halo et sol cachés par le pupitre. Fond plus large que 16:9 de 30 % (gros plan puis recul). **Origine :** généré ici (`Plan32/01_fond_salle_presse_vide.json`), réutilisé aux Plans 30, 31, 46, 47, 48 et 49.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Barre de vitesse | Personnage B | Pupitre avec micros |
| --- | --- | --- | --- |
| Technique | MONTAGE | 6 nouvelle configuration | 6 nouvelle configuration |
| Type | effet | personnage | objet |
| Description | barre qui remonte derrière le personnage jusqu'au repère « AVANT » | costume bleu nuit, chemise blanche, cravate dorée, bouche ouverte, de face, jusqu'à la taille | trapèze gris-bleu à plateau incliné, trois micros noirs sur tiges courbes |
| Position et taille | derrière le personnage, absente de l'image : à régler au montage | centre (50 %, 40 %), 44 % de haut | centre (50 %, 70 %), 38 % de haut, 29 % de large |
| Calque | 2 | 2 | 3 |
| Animation | monte de 0,5 s à 2 s | visible dès 0 s, immobile | visible dès 0 s, immobile |
| États | vide puis pleine | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | sans objet | bas du buste (cachés par le pupitre) | aucune |
| Détourage | sans objet | #00FF00 | #FF00FF |
| Groupe de génération | sans objet | seul | seul |
| Origine | MONTAGE | généré ici (`Plan32/03_personnage_b_buste.json`) | généré ici (`Plan32/02_pupitre_micros.json`), source des plans 30, 31, 46, 47, 48 et 49 |
| Remarque | | cravate dorée : c'est la différence avec le personnage A | |

**5. Chronologie.** 0 s : salle, personnage, pupitre ; 0,5 s à 2 s : la barre de vitesse remonte ; 2 s : pastille verte ; 0 s à 3 s : zoom avant sur le personnage ; 3 s à 6 s : recul sur les micros ; 6 s : fin.

**6. MONTAGE.** Barre de vitesse et repère « AVANT », étiquette « PRÉSIDENT » (petit) et « ZELENSKY » (gras), pastille verte « VITESSES RÉTABLIES, SELON ZELENSKY », zoom puis recul, logo.

**7. Couverture.** oui. **8. Points à trancher.** La barre de vitesse n'est pas dans l'image du storyboard : sa position est à régler au montage.

---

## Plan33 (5.5) · sequence27 · 8 s

**1. Identité.** Voix off : « Le tout se joue en pleine reprise diplomatique : la Russie a accepté de relancer des négociations à trois avec Washington et Kyiv le mois prochain. » Image : `Storyboard/sequence27/plan33.webp`.

**2. Ce qui se passe.** Table de négociation ronde vue du dessus. Trois jetons ronds (rouge, bleu, jaune) glissent chacun depuis un bord jusqu'à leur place, puis trois flèches blanches à deux pointes les relient en triangle. Dézoom lent. Fondu enchaîné vers le Plan34.

**3. FOND (statique).** Table ronde vue du dessus : plateau crème, bord gris clair, centre (50 %, 49 %), 49 % de la hauteur de l'image ; trois chaises bleu-vert sombre (haut (50 %, 20 %), bas gauche (36 %, 63 %), bas droite (64 %, 63 %)) ; fond bleu clair #8DE3FA uni. À retirer : jetons, flèches. Fond plus large que 16:9 de 15 % (dézoom lent). **Origine :** généré ici (`Plan33/01_fond_table_ronde_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Jeton rouge | Jeton bleu | Jeton jaune | Flèches blanches |
| --- | --- | --- | --- | --- |
| Technique | 3 décomposé (groupe de trois, sous-assets séparés) | idem | idem | 4 code |
| Type | objet | objet | objet | effet |
| Description | disque rouge #D9272E à anneau intérieur plus clair | disque bleu #1E6BB8, même forme | disque jaune doré #E8A92C, même forme | trois arcs blancs à deux pointes |
| Position et taille | centre (50 %, 6,6 %), 10 % de haut | centre (27,6 %, 74,3 %), 10 % de haut | centre (72,4 %, 74,3 %), 10 % de haut | voir la fiche |
| Calque | 2 | 2 | 2 | 3 |
| Animation | glisse du bord haut à 0,5 s (1 s) | glisse du bord gauche à 1 s (1 s) | glisse du bord droit à 1,5 s (1 s) | tracés à 3 s, 3,4 s et 3,8 s |
| États | un | un | un | un |
| Parties séparées | oui (trois jetons séparés par un vide net) | idem | idem | non |
| Fiche de code | non | non | non | `Plan33/03_fleches_blanches_code.md` |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | #00FF00 | #00FF00 | #00FF00 | sans objet |
| Groupe de génération | un groupe de trois | idem | idem | sans objet |
| Origine | généré ici (`Plan33/02_groupe_jetons.json`) | idem | idem | fiche de code (variante C) |
| Remarque | le Plan34 réutilise le groupe | | | positions mesurées sur l'image |

**5. Chronologie.** 0 s : table vide ; 0,5 s à 2,5 s : les jetons glissent ; 3 s à 4,4 s : les trois arcs se tracent ; 3 s : étiquettes ; 0 s à 8 s : dézoom lent ; 8 s : fondu enchaîné.

**6. MONTAGE.** Glissement des jetons, étiquettes « RUSSIE », « WASHINGTON », « KYIV », étiquette blanche à calendrier orange « LE MOIS PROCHAIN », « NÉGOCIATIONS À TROIS », dézoom, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan34 (5.6) · sequence27 · 3 s

**1. Identité.** Voix off : « Dans ce brouillard, une chose est sûre : » Image : `Storyboard/sequence27/plan34.webp`.

**2. Ce qui se passe.** Les trois jetons s'enfoncent dans un brouillard gris fait de lobes arrondis. Seule reste visible au centre la carte plate de l'Ukraine. Zoom avant lent. Fondu enchaîné depuis le Plan33.

**3. FOND (statique).** Brouillard gris #B8BEC4 entièrement rempli de lobes arrondis qui se chevauchent, nuances #D5DAE0 et #9AA1AB, sans zone vide. Fond plus large que 16:9 de 20 % (zoom lent). **Origine :** généré ici (`Plan34/01_fond_brouillard.json`), réutilisé au Plan61.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Carte de l'Ukraine | Jetons (trois) | Brouillard avant (trois amas) |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 3 décomposé (groupe de trois amas) |
| Type | objet | objet | effet |
| Description | carte plate bleue de l'Ukraine | rouge, bleu et jaune | amas de cinq à sept lobes gris clair, plats en bas |
| Position et taille | centre (50,4 %, 49 %), 51 % de haut, 48 % de large | rouge (50 %, 6 %), bleu (18,4 %, 77 %), jaune (83,8 %, 77 %), 10 % de haut | haut (50 %, 21 %), bas gauche (18,4 %, 90 %), bas droite (83,8 %, 90 %), 18 % de large, 22 % de haut |
| Calque | 2 | 2 | 3 |
| Animation | zoom lent (avec le fond) | partent des positions du Plan33 et s'enfoncent de 50 % de leur hauteur, de 0,2 s à 2 s | visibles dès 0 s |
| États | un | un | un |
| Parties séparées | non | oui | oui (trois amas séparés par un vide net) |
| Fiche de code | non | non | non |
| Zones cachées | aucune | moitié basse, cachée par le brouillard | aucune |
| Détourage | sans objet (réutilisée) | sans objet (réutilisés) | #FF00FF |
| Groupe de génération | sans objet | sans objet | un groupe de trois |
| Origine | réutilise `Plan8/02_carte_ukraine` (lot 1), retouche : taille | réutilise `Plan33/02_groupe_jetons`, retouche : positions | généré ici (`Plan34/02_brouillard_calque_avant.json`) |
| Remarque | | seul le sommet de chaque jeton dépasse | positions estimées à l'œil |

**5. Chronologie.** 0 s à 0,6 s : fondu enchaîné depuis le Plan33 ; 0,2 s à 2 s : les jetons s'enfoncent ; 0 s à 3 s : zoom lent sur la carte ; 3 s : fin.

**6. MONTAGE.** Fondu enchaîné, enfoncement des jetons, zoom, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan35 (5.7) · sequence28 · 6 s

**1. Identité.** Voix off : « … l'Ukraine vient de mesurer à quel point son réseau dépend d'une décision qu'elle ne contrôle pas. » Image : `Storyboard/sequence28/plan35.webp`.

**2. Ce qui se passe.** Carton de conclusion de la partie : fond bordeaux, la petite carte de l'Ukraine en bas à gauche, un fin câble qui part d'elle et sort du cadre. Le reste est vide (le texte vient au montage).

**3. FOND (aplat, MONTAGE).** Bordeaux #4A0A28. **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Carte de l'Ukraine | Câble fin |
| --- | --- | --- |
| Technique | 1 tel quel | MONTAGE |
| Type | objet | effet |
| Description | petite carte plate bleue | trait fin clair qui part de la carte et sort du cadre à gauche |
| Position et taille | centre (12,5 %, 86,5 %), 15,5 % de haut, 13,6 % de large | de (10 %, 91 %) à (0 %, 96 %) |
| Calque | 2 | 2 |
| Animation | visible dès 0 s | se tire à partir de 0,5 s |
| Origine | réutilise `Plan8/02_carte_ukraine` (lot 1), retouche : taille réduite | MONTAGE |

**5. Chronologie.** 0 s : fond, carte ; 0,3 s : le texte ; 0,5 s : le câble ; 6 s : fin.

**6. MONTAGE.** Aplat, câble, texte « UNE DÉCISION QU'ELLE NE CONTRÔLE PAS » mot à mot, masque d'encre bleu clair #66C8F7 en sortie, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan36 (6.1) · sequence29 · 6 s

**1. Identité.** Voix off : « Sur un grand forum d'actualité en ligne, quatre discussions sur cette affaire ont dépassé 25 000 votes. » Image : `Storyboard/sequence29/plan36.webp`.

**2. Ce qui se passe.** Vue du dessus : quatre disques de foule bleue, alignés, chacun surmonté d'un pouce et d'une bulle vide. Les quatre groupes s'allument un par un avec un rebond, un halo jaune doré apparaît autour de chacun. Plan fixe, coupe franche.

**3. FOND (statique).** Bleu clair #66C8F7 à capsules arrondies. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : aucune.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Disques de foule (quatre copies) | Pouces | Bulles vides | Halos jaunes |
| --- | --- | --- | --- | --- |
| Technique | 6 nouvelle configuration | 1 tel quel | 6 nouvelle configuration | MONTAGE |
| Type | personnage (groupe) | icône | icône | effet |
| Description | disque d'une cinquantaine de silhouettes bleues vues du dessus | pouce levé rond, saumon | bulle ronde blanche à petite queue | halo #F9C96B autour de chaque disque |
| Position et taille | centres x 13,7 %, 38,2 %, 62,5 %, 87 %, y 56 % ; 35 % de haut (20 % de large) | à (disque − 5,2 %, 26 %), 15 % de haut | à (disque + 4,3 %, 26 %), 8,5 % de large, 12 % de haut | autour de chaque disque, 125 % de sa taille |
| Calque | 2 | 3 | 3 | 1 |
| Animation | disque 1 à 0,5 s, 2 à 1,5 s, 3 à 2,5 s, 4 à 3,5 s ; rebond de 0,3 s | avec son disque | avec son disque | avec son disque |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | non | non |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | #00FF00 | sans objet (réutilisé) | #00FF00 | sans objet |
| Groupe de génération | seul | sans objet | seule (avec le Plan37 qui la réutilise) | sans objet |
| Origine | généré ici (`Plan36/01_groupe_foule_rond.json`), quatre copies | réutilise `Plan63/01_pouce` (lot à venir), retouche : taille, répété quatre fois | généré ici (`Plan36/02_bulle.json`), réutilisée aux Plans 37, 40 et 62 | MONTAGE |
| Remarque | l'image montre quatre disques légèrement différents ; une seule génération, copies en rotation | le Plan63 n'est pas encore livré | | |

**5. Chronologie.** 0 s : fond ; 0,5 s, 1,5 s, 2,5 s, 3,5 s : un groupe s'allume (disque, pouce, bulle, halo) ; 6 s : fin.

**6. MONTAGE.** Halos jaunes, allumage un par un avec rebond, logo.

**7. Couverture.** oui. **8. Points à trancher.** Les pouces viennent du Plan63 (lot 7) : le Plan36 ne s'assemble qu'après ce lot.

---

## Plan37 (6.2) · sequence29 · 5 s

**1. Identité.** Voix off : « La plus populaire : plus de 51 000 votes et plus de 8 000 commentaires. » Image : `Storyboard/sequence29/plan37.webp`.

**2. Ce qui se passe.** Un des quatre groupes grossit et occupe l'écran : une foule épaisse en large ellipse. Au-dessus d'elle, une trentaine de pouces et de bulles de tailles variées montent, puis se stabilisent. Zoom avant ciblé sur le groupe.

**3. FOND (statique).** Bleu clair #66C8F7 à capsules, même fond que le Plan36. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : agrandi de 15 %.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Foule dense | Pouces | Bulles vides | Halo jaune |
| --- | --- | --- | --- | --- |
| Technique | 6 nouvelle configuration | 1 tel quel | 1 tel quel | MONTAGE |
| Type | personnage (groupe) | icône | icône | effet |
| Description | ellipse de plusieurs centaines de silhouettes bleues vues du dessus | environ 18 pouces, tailles de 4 % à 15 % de haut, certains pâles, rotations de −15° à +15° | environ 15 bulles, 4 % à 12 % de large | halo #F9C96B autour de la foule |
| Position et taille | centre (50 %, 66 %), 94 % de large, 52 % de haut | zone de x 2 % à 98 %, y 2 % à 52 % | même zone | autour de la foule |
| Calque | 2 | 3 | 3 | 1 |
| Animation | grossit de 35 % à 100 % en 1 s, de 0 s à 1 s | montent de 0,8 s à 3 s, puis stables | idem | avec la foule |
| États | un | un | un | un |
| Parties séparées | non | non | non | non |
| Fiche de code | non | non | non | non |
| Zones cachées | aucune | aucune | aucune | sans objet |
| Détourage | #00FF00 | sans objet (réutilisés) | sans objet (réutilisées) | sans objet |
| Groupe de génération | seul | sans objet | sans objet | sans objet |
| Origine | généré ici (`Plan37/01_foule_dense.json`) | réutilise `Plan63/01_pouce` (lot à venir), retouche : tailles et rotations | réutilise `Plan36/02_bulle`, retouche : tailles | MONTAGE |
| Remarque | | placement répétable (graine fixe) | | |

**5. Chronologie.** 0 s à 1 s : la foule grossit ; 0,8 s à 3 s : pouces et bulles montent ; 1 s à 5 s : zoom avant ciblé ; 5 s : fin.

**6. MONTAGE.** Halo jaune, agrandissement, montée des pouces et des bulles, zoom, aucun compteur, logo.

**7. Couverture.** oui. **8. Points à trancher.** Même dépendance que le Plan36 : les pouces viennent du Plan63.

---

## Plan38 (6.3) · sequence30 · 3 s

**1. Identité.** Voix off : « Trois idées reviennent. » Image : `Storyboard/sequence30/plan38.webp`.

**2. Ce qui se passe.** Fond violet, trois grandes cases blanches arrondies, vides, alignées au centre. Elles entrent en pop l'une après l'autre ; les numéros 1, 2, 3 viennent au montage.

**3. FOND (aplat, MONTAGE).** Violet #4F1C80. **Origine :** montage.

**4. ASSETS (dynamiques)**

| Champ | Trois cases blanches |
| --- | --- |
| Technique | MONTAGE |
| Type | forme simple |
| Description | trois rectangles blancs à angles arrondis (rayon 6 % de la hauteur), mêmes dimensions |
| Position et taille | centres (19,3 %, 48,4 %), (50 %, 48,4 %), (80,7 %, 48,4 %) ; 28 % de large, 46,5 % de haut |
| Calque | 2 |
| Animation | pop à 0,3 s, 1,1 s et 1,9 s |
| Origine | MONTAGE |
| Remarque | l'asset 06 (foule) annoncé par la séquence n'apparaît pas dans l'image : rien à générer |

**5. Chronologie.** 0 s : fond ; 0,3 s, 1,1 s, 1,9 s : les cases ; 3 s : fin.

**6. MONTAGE.** Aplat, cases, numéros « 1 », « 2 », « 3 », logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_rien_a_generer.txt`.

---

## Plan39 (6.4) · sequence31 · 5 s

**1. Identité.** Voix off : « Un : le pouvoir. Le commentaire le plus voté, plus de 20 000 votes, » Image : `Storyboard/sequence31/plan39.webp`.

**2. Ce qui se passe.** Première idée, le pouvoir. À gauche, une grande silhouette couronnée, au visage voilé, tient un levier géant à boule rouge. À droite, face à elle, une foule minuscule en rangée. Plan fixe.

**3. FOND (aplat, MONTAGE).** Turquoise #3FD6B5. Ellipses d'ombre sous la silhouette et sous la foule : montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Silhouette couronnée au levier | Foule minuscule |
| --- | --- | --- |
| Technique | 6 nouvelle configuration | 6 nouvelle configuration |
| Type | personnage | personnage (groupe) |
| Description | robe violet très sombre, voile sombre avec bande de peau et deux yeux souriants, couronne dorée à gemmes rouge et verte, levier gris foncé à boule rouge sur base en dôme | rangée serrée d'environ quarante silhouettes bleues, de face, tailles et nuances variées |
| Position et taille | centre (23 %, 48,5 %), 87 % de haut | centre (77,6 %, 79,5 %), 44 % de large, 19 % de haut |
| Calque | 2 | 2 |
| Animation | visible dès 0 s, immobile | visible dès 0 s, immobile |
| États | un | un |
| Parties séparées | oui (deux éléments séparés par un vide net) | oui |
| Fiche de code | non | non |
| Zones cachées | aucune | aucune |
| Détourage | #FF00FF | #FF00FF |
| Groupe de génération | un groupe de deux | idem |
| Origine | généré ici (`Plan39/01_groupe_couronnee_foule_minuscule.json`), source de la silhouette au Plan40 | idem, source de la foule au Plan40 |
| Remarque | l'image montre un levier à boule rouge ; le prompt ajoute la base en dôme | la foule est entière dans l'image, avec 0,4 % de marge à droite |

**5. Chronologie.** 0 s : fond, silhouette, foule ; 0,4 s : légende et icône de couronne ; 5 s : fin.

**6. MONTAGE.** Aplat, ombres au sol, légende « 1 · LE POUVOIR » avec icône de couronne, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan40 (6.5) · sequence31 · 5 s

**1. Identité.** Voix off : « … dit simplement qu'une entreprise ou un individu ne devrait jamais avoir autant de pouvoir. » Image : `Storyboard/sequence31/plan40.webp`.

**2. Ce qui se passe.** Même décor. Une balance géante dorée : la silhouette couronnée sur le plateau gauche, qui descend ; la foule entière sur le plateau droit, soulevée. Une bulle blanche avec un point d'exclamation gonfle au-dessus de la foule. Zoom avant lent sur la balance.

**3. FOND (aplat, MONTAGE).** Turquoise #3FD6B5, identique au Plan39. Ellipses d'ombre sous la base et sous les plateaux : montage. **Origine :** réutilise l'aplat du Plan39 (montage).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Pied et base | Fléau avec rotule | Plateau gauche | Plateau droit | Silhouette couronnée | Foule | Bulle |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Technique | 3 décomposé | 3 décomposé | 3 décomposé | 3 décomposé | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | objet | objet | objet | objet | personnage | personnage (groupe) | icône |
| Description | colonne dorée, base large arrondie, sommet en fourche | fléau doré, rotule centrale, boule dorée à chaque bout | coupe dorée, deux chaînes grises en V jusqu'à un anneau | identique | silhouette du Plan39, réduite | foule du Plan39, réduite | bulle ronde blanche vide, queue en bas à gauche |
| Position et taille | centre (48,8 %, 60 %), 75 % de haut, base 22,5 % de large | rotule (48,9 %, 17,6 %), 41 % de large | anneau (30,2 %, 23,2 %), centre de la coupe (23,6 %, 73 %), 24,5 % de large, 55 % de haut | anneau (69,9 %, 7,8 %), centre de la coupe (71 %, 55 %), même taille | centre (19,8 %, 46,3 %), 49,5 % de haut | centre (71,4 %, 43,6 %), 26,5 % de large, 16,5 % de haut | centre (88 %, 15,4 %), 15,8 % de large |
| Calque | 2 | 3 | 4 | 4 | 5 | 5 | 6 |
| Animation | pop à 0,3 s | de +10° à −12° autour de la rotule, 1 s à 2,5 s, ease-out | suit l'extrémité gauche, reste horizontal | suit l'extrémité droite, reste horizontal | posée sur le plateau gauche à 0,8 s, suit | posée sur le plateau droit à 0,8 s, suit | pop à 2,6 s |
| États | un | un | un | un | un | un | un |
| Parties séparées | oui (quatre sous-assets séparés par un vide net) | oui | oui | oui | non | non | non |
| Fiche de code | non | non | non | non | non | non | non |
| Zones cachées | aucune | partie centrale cachée par la rotule | dessous de la coupe | dessous de la coupe | aucune | aucune | aucune |
| Détourage | #FF00FF | #FF00FF | #FF00FF | #FF00FF | sans objet (réutilisée) | sans objet (réutilisée) | sans objet (réutilisée) |
| Groupe de génération | un groupe de quatre | idem | idem | idem | sans objet | sans objet | sans objet |
| Origine | généré ici (`Plan40/01_balance_decomposee.json`) | idem | idem | idem | réutilise `Plan39/01_…`, retouche : taille | réutilise `Plan39/01_…`, retouche : taille | réutilise `Plan36/02_bulle`, retouche : taille |
| Remarque | | fléau à l'horizontale à la génération | plateaux au repos, suspendus droits | | | | le « ! » est du montage |

**5. Chronologie.** 0 s : fond ; 0,3 s : pied et fléau (à +10°, plateau gauche haut) ; 0,8 s : silhouette et foule sur leurs plateaux ; 1 s à 2,5 s : le fléau bascule jusqu'à −12° (plateau gauche bas, plateau droit haut) ; 2,6 s : la bulle gonfle ; 0 s à 5 s : zoom avant lent ; 5 s : fin.

**6. MONTAGE.** Aplat, ombres, zoom lent, « ! » dans la bulle, traits d'impact, « TROP DE POUVOIR », masque d'encre violet #8E5BD0 en sortie, logo.

**7. Couverture.** oui.

**8. Points à trancher.** Le registre écrit « rotation de −12° à +10° ». L'image montre l'état final à −12° (plateau gauche bas, bout droit relevé de 12,4°). Je lis donc : départ à +10°, arrivée à −12° (signe : sens horaire positif). À confirmer si vous voulez l'inverse.

---

## Plan41 (6.6) · sequence32 · 4 s

**1. Identité.** Voix off : « Deux : l'ironie. Quand l'argument des conditions d'utilisation circule, » Image : `Storyboard/sequence32/plan41.webp`.

**2. Ce qui se passe.** Deuxième idée, l'ironie. Six silhouettes bleues alignées, poses variées ; l'une, au centre, tient le contrat devant elle, les autres le lisent ou lèvent les yeux au ciel. Le masque comique est en haut à gauche. Le contrat passe de silhouette en silhouette.

**3. FOND (aplat, MONTAGE).** Violet #8E5BD0. Ellipse d'ombre sous les pieds : montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Six silhouettes | Contrat | Masque comique |
| --- | --- | --- | --- |
| Technique | 6 nouvelle configuration | 1 tel quel | 1 tel quel |
| Type | personnage (groupe de six) | objet | icône |
| Description | silhouettes bleues sans visage : main à la tête, main au menton, avant-bras relevés, penchée de profil, tête levée, bras écartés | feuille blanche à bandeau bleu, cachet rouge, signature | masque de théâtre comique jaune doré, souriant |
| Position et taille | centre (54 %, 61 %), 86 % de large, 61 % de haut ; centres x : 17,2 %, 33,7 %, 46,7 %, 59 %, 71,4 %, 87,2 % | centre (46,9 %, 51,7 %), 15 % de haut | centre (11,2 %, 17 %), 24 % de haut |
| Calque | 2 | 3 | 3 |
| Animation | visibles dès 0 s, immobiles | tenu par la 3e silhouette dès 0 s ; saute à la 4e à 1,2 s (0,4 s), à la 5e à 2,4 s (0,4 s) | pop à 0,3 s |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | #00FF00 | sans objet (réutilisé) | #00FF00 |
| Groupe de génération | un groupe de six | sans objet | seul |
| Origine | généré ici (`Plan41/01_silhouettes_lisent_contrat.json`) | réutilise `Plan25/01_groupe_contrat_drone_dessus`, retouche : taille réduite, déplacement au montage | généré ici (`Plan41/02_masque_comique.json`) |
| Remarque | le contrat est absent de la génération | | correction : masque entier, non coupé, dessiné comme un masque de théâtre et non un émoji |

**5. Chronologie.** 0 s : fond, silhouettes, contrat ; 0,3 s : masque ; 1,2 s : le contrat passe à la 4e silhouette ; 2,4 s : à la 5e ; 4 s : fin.

**6. MONTAGE.** Aplat, ombre, légende « 2 · L'IRONIE », déplacement du contrat, petits traits d'agitation au-dessus de trois têtes, logo.

**7. Couverture.** oui. **8. Points à trancher.** Les trajets du contrat sont proposés : l'image n'en montre que le point de départ.

---

## Plan42 (6.7) · sequence32 · 6 s

**1. Identité.** Voix off : « … un internaute résume : les conditions d'utilisation, c'est se rendre à la Russie. Plus de 1 700 votes. » Image : `Storyboard/sequence32/plan42.webp`.

**2. Ce qui se passe.** Le contrat devient un drapeau blanc hissé sur un mât, devant une foule qui rit : se rendre sans combattre. Zoom avant lent.

**3. FOND (aplat, MONTAGE).** Violet #8E5BD0, identique au Plan41. Ellipses d'ombre : montage. **Origine :** réutilise l'aplat du Plan41 (montage).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Contrat (transition) | Mât et drapeau | Six silhouettes qui rient |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 6 nouvelle configuration |
| Type | objet | objet | personnage (groupe de six) |
| Description | contrat qui grandit au centre puis se plie | mât gris-bleu à boule, base ronde, drapeau en forme de contrat plié, hissé | silhouettes bleues, têtes rejetées en arrière, en deux groupes de trois |
| Position et taille | de (50 %, 45 %), 55 % de haut, vers la forme du drapeau | centre (45,8 %, 48 %), 88 % de haut ; drapeau centre (56 %, 20 %), 19 % de large, 23 % de haut | centre (51 %, 68 %), 77 % de large, 53 % de haut ; groupes x 13 % à 45 % et 52,5 % à 89,6 % |
| Calque | 3 | 2 | 3 |
| Animation | grandit de 0,3 s à 1,3 s, se plie à 1,3 s (0,6 s) et se fond dans le drapeau | apparaît à 1,9 s avec son drapeau | arrivent à 2,2 s |
| États | un | un | un |
| Parties séparées | non | non | oui (deux groupes de trois) |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | #00FF00 | #00FF00 |
| Groupe de génération | sans objet | seul | un groupe de six |
| Origine | réutilise `Plan25/01_groupe_contrat_drone_dessus` | généré ici (`Plan42/02_mat_drapeau_contrat.json`) | généré ici (`Plan42/01_silhouettes_rient.json`) |
| Remarque | | le pied du mât reste dégagé | |

**5. Chronologie.** 0 s : fond ; 0,3 s à 1,9 s : le contrat grandit puis se plie ; 1,9 s : le mât et le drapeau ; 2,2 s : la foule ; 0 s à 6 s : zoom avant lent ; 6 s : fin.

**6. MONTAGE.** Aplat, ombres, croissance et pliage du contrat, « CONDITIONS D'UTILISATION » sur le contrat, étiquette « RUSSIE » au pied du mât, zoom, logo.

**7. Couverture.** oui. **8. Points à trancher.** Le pliage du contrat en drapeau est un fondu : le drapeau du mât est déjà plié à la génération.

---

## Plan43 (6.8) · sequence33 · 5 s

**1. Identité.** Voix off : « Trois : le soupçon. Beaucoup accusent Musk et Washington de faire le jeu de Moscou. » Image : `Storyboard/sequence33/plan43.webp`.

**2. Ce qui se passe.** Troisième idée, le soupçon. Trois cadres blancs à bord bleu en triangle, reliés par des flèches pointillées à deux pointes marquées d'un « ? ». Au premier plan, six silhouettes de dos les regardent à travers des loupes.

**3. FOND (aplat, MONTAGE).** Rouge sombre #3D0A0E. Les trois cadres blancs à bord bleu sont du montage. **Origine :** montage.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Trois cadres | Flèches pointillées | Six silhouettes avec loupes |
| --- | --- | --- | --- |
| Technique | MONTAGE | 4 code | 6 nouvelle configuration |
| Type | forme simple | effet | personnage (groupe de six, loupes greffées) |
| Description | rectangles blancs #FBF8F4 à bord bleu #4A90E2 | trois flèches blanches pointillées à deux pointes | silhouettes de dos, un bras levé, loupe à monture bleu clair |
| Position et taille | haut (50 %, 15,5 %) 17,3 % de large, 23 % de haut ; gauche (23,9 %, 43 %) et droit (76,1 %, 43 %), 18,1 % de large, 23,5 % de haut | voir la fiche | centre (50 %, 79 %), pleine largeur, 42 % de haut ; loupes de 4,9 % de large |
| Calque | 2 | 3 | 4 |
| Animation | pop à 0,3 s, 0,6 s, 0,9 s | tracées à 1,5 s, 2 s, 2,5 s | montent du bas de l'image à 0,2 s (0,5 s) |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | `Plan43/02_fleches_pointillees_code.md` | non |
| Zones cachées | sans objet | sans objet | aucune |
| Détourage | sans objet | sans objet | #00FF00 |
| Groupe de génération | sans objet | sans objet | un groupe de six |
| Origine | MONTAGE | fiche de code (variante D) | généré ici (`Plan43/01_silhouettes_dos_loupes.json`) |
| Remarque | | les « ? » sont du texte de montage | le bord du bas est droit |

**5. Chronologie.** 0 s : fond ; 0,2 s : silhouettes ; 0,3 s à 0,9 s : les cadres ; 1,5 s à 3 s : les flèches et leurs « ? » ; 5 s : fin.

**6. MONTAGE.** Aplat, cadres, « ? », légende « 3 · LE SOUPÇON », étiquettes « MUSK », « WASHINGTON », « MOSCOU », logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan44 (6.9) · sequence34 · 7 s

**1. Identité.** Voix off : « Ce sont des opinions, pas des faits établis, et aucune des sources de cette vidéo ne le démontre. » Image : `Storyboard/sequence34/plan44.webp`.

**2. Ce qui se passe.** Carton de rappel : fond violet nuit uni, texte seul.

**3. FOND (aplat voulu, MONTAGE).** Violet nuit #2B1030. **Origine :** montage.

**4. ASSETS.** Aucun.

**5. Chronologie.** 0 s : carton ; 0,3 s : le texte ; 7 s : fin.

**6. MONTAGE.** Aplat, texte du carton (deux lignes, la seconde plus petite), logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_rien_a_generer.txt`.

---

## Plan45 (7.1) · sequence35 · 3 s

**1. Identité.** Voix off : « Les gouvernements aussi ont réagi. » Image : `Storyboard/sequence35/plan45.webp`.

**2. Ce qui se passe.** Un mur à panneaux, arches et rideaux, teinté de bleu. Trois silhouettes en costume, de dos, alignées, se tournent d'un même geste ; des points d'exclamation apparaissent.

**3. FOND (statique).** Mur bleu #2A74BF : rideaux drapés de chaque côté avec embrasses, guirlande de festons en haut, panneaux moulurés et arches, deux petits panneaux latéraux, plinthe et sol. À retirer : les trois silhouettes. À reconstruire : bas du mur et sol. Fond plus large que 16:9 de 10 %. **Origine :** généré ici (`Plan45/01_fond_mur_panneaux.json`).

**4. ASSETS (dynamiques)**

| Champ | Trois silhouettes en costume, de dos |
| --- | --- |
| Technique | 6 nouvelle configuration |
| Type | personnage (groupe de trois) |
| Description | bleu très foncé #0B2F6B, bras le long du corps, deux hommes et une personne aux cheveux longs à droite |
| Position et taille | centre (50 %, 67,5 %), 33 % de large, 53 % de haut ; centres x : 37,8 %, 50,1 %, 62,5 % |
| Calque | 2 |
| Animation | visibles dès 0 s ; miroir d'un même geste à 1,2 s (rotation 0,3 s) ; trois « ! » en pop à 1,4 s |
| États | un |
| Parties séparées | non |
| Fiche de code | non |
| Zones cachées | aucune |
| Détourage | #00FF00 |
| Groupe de génération | un groupe de trois |
| Origine | généré ici (`Plan45/02_silhouettes_costume_dos.json`) |
| Remarque | ces silhouettes remplacent celles du Plan23 (configuration de dos, non de face) |

**5. Chronologie.** 0 s : mur, silhouettes ; 1,2 s : elles se tournent ; 1,4 s : trois « ! » ; 3 s : fin.

**6. MONTAGE.** Mouvement des silhouettes, points d'exclamation en pop, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan46 (7.2) · sequence36 · 4 s

**1. Identité.** Voix off : « L'Allemagne exige que les restrictions soient levées : » Image : `Storyboard/sequence36/plan46.webp`.

**2. Ce qui se passe.** Salle de presse gris-vert. Le pupitre et ses micros au centre, sans personnage ; un grand cadenas devant lui s'ouvre.

**3. FOND (statique).** Salle de presse vide gris-vert #7F9490. **Origine :** réutilise `Plan32/01_fond_salle_presse_vide` (lot 4), retouche : aucune.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Pupitre avec micros | Corps du cadenas | Anse du cadenas |
| --- | --- | --- | --- |
| Technique | 2 calque | 3 décomposé | 3 décomposé |
| Type | objet | objet | objet |
| Description | pupitre gris-bleu à trois micros, sans personnage | rectangle arrondi gris ardoise à trou de serrure | arceau en U renversé gris argenté |
| Position et taille | centre (50 %, 66 %), 27 % de large, 57 % de haut | centre (51 %, 77,6 %), 22,3 % de large, 29,6 % de haut | état final : ouverte, centre (40,3 %, 52 %), 16,6 % de large, 24 % de haut |
| Calque | 2 | 3 | 2 (derrière le corps) |
| Animation | visible dès 0 s | pop à 0,3 s | de 1 s à 2,2 s : sort du corps de 6 % de la hauteur, puis pivote à +40° autour de la charnière côté droit |
| États | un | un | fermée puis ouverte |
| Parties séparées | non | oui | oui |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | partie de l'anse qui entre dans le corps |
| Détourage | sans objet (réutilisé) | #FF00FF | #FF00FF |
| Groupe de génération | sans objet | un groupe de deux | idem |
| Origine | réutilise `Plan32/02_pupitre_micros`, retouche : taille | généré ici (`Plan46/01_cadenas_decompose.json`) | idem |
| Remarque | l'image le montre plus haut et plus étroit que l'asset du Plan32 | | |

**5. Chronologie.** 0 s : salle, pupitre ; 0,3 s : le cadenas fermé ; 1 s à 2,2 s : il s'ouvre ; 4 s : fin.

**6. MONTAGE.** Ouverture du cadenas, logo.

**7. Couverture.** oui. **8. Points à trancher.** Le pupitre de l'image est plus haut et plus étroit que l'asset du Plan32 (27 % de large pour 57 % de haut, contre 29 % pour 38 %) : je le pose à l'échelle uniforme, base au même endroit, sans reproduire l'étirement, sauf si vous le demandez. Le registre écrit une translation de l'anse « vers le bas » : je la lis vers le haut (l'anse sort du corps) avant le pivot.

---

## Plan47 (7.3) · sequence36 · 6 s

**1. Identité.** Voix off : « … son ministre des Affaires étrangères, Johann Wadephul, rappelle que Berlin finance une partie de l'équipement. » Image : `Storyboard/sequence36/plan47.webp`.

**2. Ce qui se passe.** Même salle, sans le cadenas. Le personnage A est au pupitre, à gauche ; à droite, une pile de caisses d'équipement où tombent des billets verts, sous un panneau vide. Zoom avant sur le personnage, puis recul sur la pile.

**3. FOND (statique).** Salle de presse gris-vert #7F9490. **Origine :** réutilise `Plan32/01_fond_salle_presse_vide` (lot 4), retouche : recadrage serré (fond agrandi de 30 %).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Personnage A | Pupitre avec micros | Caisses | Panneau vide | Billets |
| --- | --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 2 calque devant le personnage | 1 tel quel | MONTAGE | 4 code |
| Type | personnage | objet | objet | forme simple | effet |
| Description | costume sombre, cravate rouge, bouche ouverte, de face | pupitre gris-bleu à trois micros | pile de trois caisses vert olive, deux liasses de billets au sommet | rectangle gris clair à cadre gris foncé | billets verts qui tombent |
| Position et taille | centre (28,2 %, 39,3 %), 44 % de haut | centre (28,6 %, 70,5 %), 39 % de haut, 25 % de large | centre (69,7 %, 69 %), 22,6 % de large, 46 % de haut | centre (70,8 %, 18,2 %), 21,7 % de large, 15,4 % de haut | voir la fiche |
| Calque | 2 | 3 | 2 | 3 | 4 |
| Animation | visible dès 0 s, immobile | idem | pop à 0,5 s | pop à 0,6 s | chute dès 0,8 s |
| États | un | un | un | un | un |
| Parties séparées | non | non | non | non | non |
| Fiche de code | non | non | non | non | `Plan47/02_billets_code.md` |
| Zones cachées | bas du buste (cachés par le pupitre) | aucune | bas de la pile | sans objet | sans objet |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | #FF00FF | sans objet | sans objet |
| Groupe de génération | sans objet | sans objet | seul | sans objet | sans objet |
| Origine | réutilise `Plan30/01_personnage_a_buste`, retouche : position et taille | réutilise `Plan32/02_pupitre_micros`, retouche : taille | généré ici (`Plan47/01_caisses_equipement.json`) | MONTAGE | fiche de code |
| Remarque | | l'échelle suit la hauteur, la largeur varie d'un plan à l'autre | | « BERLIN » est du texte de montage | |

**5. Chronologie.** 0 s : salle, personnage, pupitre ; 0,5 s : caisses ; 0,6 s : panneau ; 0,8 s : les billets tombent ; 0 s à 3 s : zoom avant sur le personnage ; 3 s à 6 s : recul sur la pile ; 6 s : fin.

**6. MONTAGE.** Panneau et texte « BERLIN », inscription « ÉQUIPEMENT » sur les caisses, étiquette « JOHANN WADEPHUL », « BERLIN FINANCE UNE PARTIE DE L'ÉQUIPEMENT », zoom puis recul, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan48 (7.4) · sequence36 · 4 s

**1. Identité.** Voix off : « En substance : si nous payons, ça doit fonctionner. » Image : `Storyboard/sequence36/plan48.webp`.

**2. Ce qui se passe.** Même salle, sans les caisses ni les billets. Le personnage A parle au centre, une grande bulle blanche vide gonfle au-dessus du pupitre.

**3. FOND (statique).** Salle de presse gris-vert. **Origine :** réutilise `Plan32/01_fond_salle_presse_vide`, retouche : cadrage du Plan47.

**4. ASSETS (dynamiques)**

| Champ | Personnage A | Pupitre avec micros | Bulle blanche |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 2 calque devant le personnage | MONTAGE |
| Type | personnage | objet | forme simple |
| Description | costume sombre, cravate rouge, de face | pupitre à trois micros | rectangle arrondi blanc vide, queue en bas à gauche |
| Position et taille | centre (49,7 %, 45 %), 44 % de haut | centre (49,7 %, 76 %), 34 % de haut, 30 % de large | centre (50 %, 12 %), 45 % de large, 18 % de haut |
| Calque | 2 | 3 | 4 |
| Animation | visible dès 0 s | visible dès 0 s | gonfle en pop à 0,5 s |
| Origine | réutilise `Plan30/01_personnage_a_buste` | réutilise `Plan32/02_pupitre_micros` | MONTAGE |

**5. Chronologie.** 0 s : salle, personnage ; 0,5 s : la bulle gonfle ; 4 s : fin.

**6. MONTAGE.** Bulle, texte « Si nous payons, ça doit fonctionner. », bandeau blanc incliné « EN SUBSTANCE », logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet. Dossier du plan : `_reutilise.txt`.

---

## Plan49 (7.5) · sequence36 · 4 s

**1. Identité.** Voix off : « Il reconnaît pourtant ne pas connaître toute l'histoire. » Image : `Storyboard/sequence36/plan49.webp`.

**2. Ce qui se passe.** Gros plan sur le personnage A, une main sur la tête, grimace. Derrière lui, un grand puzzle auquel manquent des pièces ; au-dessus, un point d'interrogation rouge.

**3. FOND (statique).** Salle de presse gris-vert #7F9490, grand halo clair visible (x 5 % à 95 %). **Origine :** réutilise `Plan32/01_fond_salle_presse_vide`, retouche : recadrage serré.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Puzzle incomplet | Personnage A, main sur la tête | Point d'interrogation |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 6 nouvelle configuration | 1 tel quel |
| Type | objet | personnage | icône |
| Description | douze pièces colorées, quatre emplacements vides, deux pièces blanches | mi-buste, de face, main sur la tête, grimace inquiète | point d'interrogation rouge brillant |
| Position et taille | centre (50 %, 57,5 %), 68 % de large, 60 % de haut | centre (52 %, 66 %), 69 % de haut, 40 % de large | centre (49,6 %, 14,9 %), 27 % de haut |
| Calque | 2 | 3 | 4 |
| Animation | visible dès 0 s | visible dès 0 s, immobile | pop à 0,8 s |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | partie centrale, cachée par le personnage | aucune | aucune |
| Détourage | #FF00FF | #FF00FF | sans objet (réutilisé) |
| Groupe de génération | seul | seul | sans objet |
| Origine | généré ici (`Plan49/02_puzzle_incomplet.json`) | généré ici (`Plan49/01_personnage_a_main_tete.json`) | réutilise `Plan50/02_groupe_caisse_militaire_point_interrogation`, retouche : taille |
| Remarque | | | trois traits d'éclat de chaque côté : montage |

**5. Chronologie.** 0 s : fond, puzzle, personnage ; 0,8 s : le « ? » ; 4 s : masque d'encre bleu clair ; fin.

**6. MONTAGE.** Pop du « ? » et traits d'éclat, « IL NE CONNAÎT PAS TOUTE L'HISTOIRE », masque d'encre #66C8F7, logo.

**7. Couverture.** oui. **8. Points à trancher.** Le registre place le pupitre dans ce plan, mais l'image n'en montre pas (cadrage à la poitrine) : je ne l'utilise pas ici.

---

## Plan50 (7.6) · sequence37 · 5 s

**1. Identité.** Voix off : « Et là, le débat change de nature. Beaucoup d'internautes ne parlent plus de Musk, » Image : `Storyboard/sequence37/plan50.webp`.

**2. Ce qui se passe.** Le débat change de nature : sept silhouettes bleues, tournées vers la droite, regardent une caisse de matériel militaire surmontée d'un grand point d'interrogation rouge. Le propriétaire du réseau n'est plus là.

**3. FOND (statique).** Bleu clair #66C8F7 à capsules. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : aucune.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Sept silhouettes | Caisse militaire | Point d'interrogation |
| --- | --- | --- | --- |
| Technique | 6 nouvelle configuration | 1 tel quel | 1 tel quel |
| Type | personnage (groupe de sept) | objet | icône |
| Description | silhouettes bleues sans visage, en trois-quarts, tournées vers la droite | caisse vert olive fermée, coins métalliques, deux poignées | point d'interrogation rouge brillant |
| Position et taille | centre (23,6 %, 61,5 %), 42,6 % de large, 60 % de haut | centre (73,8 %, 71,4 %), 40 % de large, 39 % de haut | centre (73,2 %, 28,4 %), 46 % de haut |
| Calque | 2 | 2 | 3 |
| Animation | glissent depuis la gauche à 0,2 s (0,5 s) | pop à 0,8 s | pop à 1,4 s |
| États | un | un | un |
| Parties séparées | non | oui (caisse et « ? » séparés par un vide net) | oui |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | #00FF00 | #FF00FF | #FF00FF |
| Groupe de génération | un groupe de sept | un groupe de deux | idem |
| Origine | généré ici (`Plan50/01_silhouettes_groupe_droite.json`) | généré ici (`Plan50/02_groupe_caisse_militaire_point_interrogation.json`) | idem, source du « ? » aux Plans 49, 59 et 61 |
| Remarque | | ombre ovale bleue au sol : montage | six traits d'éclat autour du « ? » : montage |

**5. Chronologie.** 0 s : fond ; 0,2 s : la foule ; 0,8 s : la caisse ; 1,4 s : le « ? » ; 5 s : fin.

**6. MONTAGE.** Ombres, traits d'éclat, logo ; la petite silhouette du propriétaire rétrécit avant ce plan.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan51 (7.7) · sequence38 · 6 s

**1. Identité.** Voix off : « … mais d'une question plus large : que vaut un équipement militaire qu'on peut ralentir à distance ? » Image : `Storyboard/sequence38/plan51.webp`.

**2. Ce qui se passe.** Carton de fin de partie : le fond violet à traînées du carton d'ouverture revient, avec le texte de la question. Les traînées dérivent lentement. Rien d'autre.

**3. FOND (statique).** Carton violet #5A1470 à traînées diagonales rose #E86FA8, jaune #F2B01E, cyan #7FD6F0. À retirer : rien. **Origine :** réutilise `Plan6/01_fond_carton_violet_trainees` (lot 1), retouche : miroir ou rotation pour varier.

**4. ASSETS (dynamiques).** Aucun. Dérive des traînées : MONTAGE (mouvement du fond).

**5. Chronologie.** 0 s : fond ; 0,3 s : le texte apparaît ; 6 s : fin.

**6. MONTAGE.** Texte du carton en capitales blanches grasses, dérive lente des traînées, logo en bas à gauche.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan52 (8.1) · sequence39 · 3 s

**1. Identité.** Voix off : « Alors, que faire ? » Image : `Storyboard/sequence39/plan52.webp`.

**2. Ce qui se passe.** Carton d'ouverture de la partie « La réponse » : fond bleu roi à formes liquides, le texte apparaît.

**3. FOND (statique).** Bandes ondulantes en nuances de bleu autour de #3355B8, plein cadre, rien d'autre. À retirer : rien. **Origine :** généré ici (`Plan52/01_fond_bleu_roi_liquide.json`), 16:9, aucune retouche.

**4. ASSETS (dynamiques).** Aucun.

**5. Chronologie.** 0 s : fond ; 0,3 s : le texte ; 3 s : fin.

**6. MONTAGE.** Texte du carton (« Alors, que faire ? ») en capitales blanches grasses, léger mouvement ondulant du fond (déplacement horizontal lent), logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan53 (8.2) · sequence40 · 7 s

**1. Identité.** Voix off : « Le 22 octobre, deux entreprises finlandaises, Nokia et ICEYE, signent avec le ministère ukrainien de la Défense une lettre d'intention » Image : `Storyboard/sequence40/plan53.webp`.

**2. Ce qui se passe.** Vue du dessus d'une table : la lettre d'intention apparaît au centre, puis trois paires de mains arrivent des bords avec chacune une feuille vide et signent : une en haut, une en bas à gauche, une en bas à droite. Les signatures se tracent. Le plan se termine sur un dézoom lent.

**3. FOND (statique).** Table vue du dessus, aplat bleu glacier #A9EEE6, vide. À retirer : lettre, trois feuilles, six mains, stylos, signatures, ombres. À reconstruire : table lisse. Fond plus large que 16:9 de 15 % (dézoom lent). **Origine :** généré ici (`Plan53/01_fond_table_bleu_glacier_vide.json`).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Lettre d'intention | Poste de signature (trois copies) |
| --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel (un groupe, trois copies retournées au montage) |
| Type | objet | partie de personnage (deux mains, manches, feuille) |
| Description | document blanc à bandeau bleu, lignes grises, cachet rouge et signature | deux mains rondes, l'une tient un stylo bleu à capuchon doré, l'autre est posée à plat ; manches bleues à manchettes blanches ; feuille blanche vide |
| Position et taille | centre (50,3 %, 59 %), 43,6 % de haut, rotation 0° | feuille de la copie du haut : centre (50,5 %, 20,5 %), 21 % de haut, rotation 0° ; copie en bas à gauche : feuille centre (21,6 %, 65,3 %), rotation +60° ; copie en bas à droite : feuille centre (79 %, 66 %), miroir horizontal puis rotation −60° |
| Calque | 2 | 3 |
| Animation | pop à 0,3 s (0,3 s) | chaque copie glisse depuis son bord : haut à 1,0 s, bas gauche à 1,6 s, bas droite à 2,2 s (0,5 s chacune) |
| États | un | un (le tracé de la signature est du montage) |
| Parties séparées | non | non |
| Fiche de code | non | non |
| Zones cachées | aucune | aucune |
| Détourage | sans objet (réutilisé) | #00FF00 |
| Groupe de génération | avec le contrat et le drone (Plan25) | seul |
| Origine | réutilise `Plan25/01_groupe_contrat_drone_dessus`, retouche : aucune | généré ici (`Plan53/02_mains_stylo_feuille.json`) |
| Remarque | même dessin que le contrat du Plan25 | le poste du haut sert de modèle ; ombres sur la table : montage |

**5. Chronologie.** 0 s : fond ; 0,3 s : la lettre ; 1,0 s : mains du haut ; 1,6 s : mains en bas à gauche ; 2,2 s : mains en bas à droite ; 2,8 s à 5,5 s : les trois signatures se tracent (décalées de 0,6 s) ; 4 s à 7 s : dézoom lent ; 7 s : fin.

**6. MONTAGE.** Tracé des trois signatures, textes sur les trois feuilles (noms des signataires), titre de la lettre, ombres des feuilles et des mains sur la table, dézoom lent, logo.

**7. Couverture.** oui.

**8. Points à trancher.** Les trois postes de l'image ne sont pas des copies rigides l'un de l'autre (la feuille du bas gauche est inclinée de 23°, les mains tournées d'environ 60°) : j'ai pris la copie du haut comme modèle et les rotations ci-dessus sont à ajuster à l'œil au montage.

---

## Plan54 (8.3) · sequence41 · 5 s

**1. Identité.** Voix off : « … pour développer un système de communication par satellite propre à l'Ukraine. » Image : `Storyboard/sequence41/plan54.webp`.

**2. Ce qui se passe.** Reprise du plan de la carte : l'Ukraine au centre, un satellite au-dessus. Cette fois le lien est un fil plein, direct, qui se trace du satellite vers le pays, sans constellation.

**3. FOND (statique).** Crème #FBF8EA à pictogrammes discrets. **Origine :** réutilise `Plan8/01_fond_creme_pictogrammes` (lot 1), retouche : aucune.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Carte de l'Ukraine | Satellite | Fil plein |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 4 code (paramètre « trait plein ») |
| Type | objet | objet | effet |
| Description | carte plate bleue #1E6BB8 | satellite blanc à deux panneaux bleus | trait plein gris-bleu #5B6B80, 3 px |
| Position et taille | centre (50,5 %, 73 %), 41 % de haut | centre (50 %, 15 %), 17,5 % de haut | de (50 %, 24 %) à (50 %, 57 %) |
| Calque | 1 | 2 | 3 |
| Animation | apparaît à 0,3 s (0,4 s) | descend depuis le haut à 0,7 s (0,5 s) | se trace de haut en bas à 1,4 s (0,8 s) |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | `Plan8/03_pointilles_constellation_code.md` (trait plein) |
| Zones cachées | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | sans objet |
| Groupe de génération | seul | seul | sans objet |
| Origine | réutilise `Plan8/02_carte_ukraine`, retouche : aucune | réutilise `Plan10/03_satellite`, retouche : aucune | fiche réutilisée du Plan8 |
| Remarque | | un seul satellite, pas de constellation | |

**5. Chronologie.** 0 s : fond ; 0,3 s : la carte ; 0,7 s : le satellite ; 1,4 s : le fil se trace jusqu'à 2,2 s ; 5 s : fin.

**6. MONTAGE.** Logo ; léger zoom lent sur l'ensemble.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan55 (8.4) · sequence42 · 8 s

**1. Identité.** Voix off : « L'idée : que le pays possède ses satellites, ses stations au sol et ses terminaux, pour ne plus dépendre des aléas d'un gouvernement étranger. » Image : `Storyboard/sequence42/plan55.webp`.

**2. Ce qui se passe.** Trois cartes blanches entrent côte à côte, chacune avec une icône : satellite, antenne au sol, terminal. Un câble relie les deux premières cartes et file vers la droite. Les ciseaux arrivent et coupent le câble ; zoom sur la coupe.

**3. FOND (statique).** Bleu clair #66C8F7 à capsules arrondies. **Origine :** réutilise `Plan16/01_fond_bleu_capsules` (lot 2), retouche : aucune (légèrement agrandi pour le zoom).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Satellite | Antenne au sol | Terminal | Câble | Ciseaux |
| --- | --- | --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel | 4 code | 1 tel quel |
| Type | icône | icône | icône | effet | objet |
| Description | satellite blanc à panneaux bleus | parabole blanche sur trépied | terminal d'utilisateur blanc sur petit pied | câble gris-bleu foncé épais, coupé | ciseaux ouverts, poignées rouges, lames grises |
| Position et taille | centre (20 %, 42 %), 31 % de haut | centre (49 %, 45 %), 33 % de haut | centre (80 %, 44 %), 38 % de haut | bande y 65 % à 79 %, x 19 % à 100 % | centre (83 %, 77 %), 24 % de haut |
| Calque | 3 | 3 | 3 | 2 | 4 |
| Animation | pop avec la carte 1 à 0,4 s | pop avec la carte 2 à 1,5 s | pop avec la carte 3 à 2,6 s | se trace à 3,6 s, coupé à 5,6 s | entrent par la droite à 4,6 s, coupent à 5,6 s |
| États | un | un | un | tracé, tendu, coupé | ouverts, puis fermés à la coupe (montage : rotation des lames) |
| Parties séparées | non | non | non | non | non |
| Fiche de code | non | non | non | `Plan55/02_cable_coupe_code.md` | non |
| Zones cachées | aucune | aucune | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | #00FF00 | sans objet | #00FF00 |
| Groupe de génération | seul | avec le contrat et le drone (Plan25) | avec les ciseaux | sans objet | avec le terminal |
| Origine | réutilise `Plan10/03_satellite`, taille réduite | réutilise `Plan25/01_groupe_contrat_drone_dessus`, retouche : aucune | généré ici (`Plan55/01_groupe_antenne_terminal_ciseaux.json`) | fiche de code ici | idem |
| Remarque | | | l'image montre un combiné radio : détail corrigé dans le prompt | l'étincelle de coupe est dans la fiche | les traits d'éclat blancs sont dans la fiche du câble |

Cartes blanches arrondies : MONTAGE (x de 5,5 % à 34,5 %, de 36,5 % à 63,5 % et de 65,5 % à 94,5 % ; y de 20 % à 65 % ; rayon 6 % de la hauteur).

**5. Chronologie.** 0 s : fond ; 0,3 s : carte 1 et satellite ; 1,4 s : carte 2 et antenne ; 2,5 s : carte 3 et terminal ; 3,6 s : le câble se trace ; 4,6 s : les ciseaux entrent ; 5,6 s : coupe et étincelle ; 6 s à 8 s : zoom sur la coupe ; 8 s : fin.

**6. MONTAGE.** Les trois cartes blanches et leur entrée une à une, le zoom sur le câble, logo.

**7. Couverture.** oui.

**8. Points à trancher.** L'antenne au sol vient du Plan25 (déjà générée) : le groupe de ce plan ne contient donc que le terminal et les ciseaux, comme décidé au registre. Le nom du fichier garde « antenne » pour ne pas changer les noms.

---

## Plan56 (8.5) · sequence43 · 4 s

**1. Identité.** Voix off : « Pour l'instant, ce n'est qu'une lettre d'intention, et ce sera long. » Image : `Storyboard/sequence43/plan56.webp`.

**2. Ce qui se passe.** La lettre d'intention est posée en bas à gauche, avec un petit sablier. Un très long chemin en tirets blancs en serpentin monte jusqu'à un satellite minuscule en haut à droite. Le montage recule lentement pour révéler toute la longueur du chemin.

**3. FOND (statique).** Aplat ocre #DDB07A, sans autre élément. À retirer : rien. **Origine :** MONTAGE (aplat).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Chemin pointillé | Lettre | Sablier | Satellite |
| --- | --- | --- | --- | --- |
| Technique | 4 code | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | effet | objet | objet | icône |
| Description | tirets blancs en serpentin à quatre virages | document blanc à bandeau bleu et cachet rouge | sablier à cadre brun et sable doré | satellite blanc à panneaux bleus, minuscule |
| Position et taille | de (21 %, 86 %) à (79 %, 14 %) | centre (13,5 %, 80 %), 20 % de haut | centre (26,1 %, 80 %), 18,6 % de haut | centre (81,7 %, 8,5 %), 10 % de haut |
| Calque | 1 | 2 | 2 | 2 |
| Animation | se trace à 0,6 s (2,4 s) puis tirets qui avancent | pop à 0,2 s (0,3 s) | pop à 0,4 s (0,3 s) | apparaît à 0,4 s (0,3 s) |
| États | tracé | un | un (sable immobile) | un |
| Parties séparées | non | non | non | non |
| Fiche de code | `Plan56/02_chemin_pointille_code.md` | non | non | non |
| Zones cachées | aucune | aucune | aucune | aucune |
| Détourage | sans objet | sans objet (réutilisé) | #00FF00 | sans objet (réutilisé) |
| Groupe de génération | sans objet | avec le drone (Plan25) | seul | seul |
| Origine | fiche de code ici | réutilise `Plan25/01_groupe_contrat_drone_dessus`, retouche : taille moyenne, en bas à gauche | généré ici (`Plan56/01_sablier.json`) | réutilise `Plan10/03_satellite`, taille très réduite |
| Remarque | | la lettre est absente de l'image (un « 13 » en chiffres la remplace) : elle est placée à la position du « 13 » | aucun chiffre, aucun texte (corrigé dans le prompt) | |

**5. Chronologie.** 0 s : fond ; 0,2 s : la lettre ; 0,4 s : le sablier et le satellite ; 0,6 s : le chemin se trace jusqu'à 3 s ; 4 s : fin.

**6. MONTAGE.** Fond ocre en aplat, zoom arrière lent (de la lettre vers le cadrage large), ombres ovales sous la lettre et le sablier, logo.

**7. Couverture.** oui.

**8. Points à trancher.** Le sable du sablier est immobile ; s'il doit couler, il faudra une feuille de sprites de 4 images.

---

## Plan57 (8.6) · sequence44 · 6 s

**1. Identité.** Voix off : « Mais sous l'annonce, le commentaire le plus populaire tient en trois mots : merci la Finlande. » Image : `Storyboard/sequence44/plan57.webp`.

**2. Ce qui se passe.** Sous une carte d'annonce vide, une foule de dos lève les bras et des cœurs rouges montent vers la carte.

**3. FOND (statique).** Aplat bleu #A9D6EE, sans autre élément. À retirer : rien. **Origine :** MONTAGE (aplat).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Foule de dos, bras levés | Cœurs montants |
| --- | --- | --- |
| Technique | 6 nouvelle configuration | 1 tel quel (cœur) + 4 code (montée) |
| Type | personnage (groupe) | effet |
| Description | bande de silhouettes bleues de dos, nombreux bras levés, mains ouvertes | cœurs rouges brillants de tailles variées |
| Position et taille | centre (50 %, 81,5 %), 100 % de large, 37 % de haut | grand cœur du groupe : centre (50,7 %, 44 %), 14,4 % de haut ; tous les cœurs : bande y 36 % à 66 % |
| Calque | 2 | 3 |
| Animation | monte depuis le bas à 0,3 s (0,5 s) | montée en continu à partir de 1,0 s |
| États | un | un |
| Parties séparées | non | non |
| Fiche de code | non | `Plan57/02_coeurs_montants_code.md` |
| Zones cachées | aucune | aucune |
| Détourage | #00FF00 | #00FF00 |
| Groupe de génération | un groupe de deux (foule et cœur) | idem |
| Origine | généré ici (`Plan57/01_groupe_foule_bras_coeur.json`) | idem, source du cœur ; montée : fiche de code ici |
| Remarque | | les traînées claires derrière les cœurs : montage |

Carte blanche vide en haut : MONTAGE (rectangle arrondi, centre (50 %, 19 %), x de 15 % à 85 %, y de 4,6 % à 34 %).

**5. Chronologie.** 0 s : fond et carte ; 0,3 s : la foule monte ; 1,0 s : les cœurs commencent à monter jusqu'à 6 s ; 6 s : fin.

**6. MONTAGE.** Le mot « ANNONCE » sur la carte, traînées claires des cœurs, zoom lent, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan58 (9.1) · sequence45 · 4 s

**1. Identité.** Voix off : « Au fond, cette histoire pose une question simple. » Image : `Storyboard/sequence45/plan58.webp`.

**2. Ce qui se passe.** Retour au poste de pilotage du début, même cadrage large que le Plan1, mais plus sombre : l'opérateur, de dos, assis droit, regarde la carte avec le drone. Rien ne bouge ; un léger zoom lent.

**3. FOND (statique).** Poste de pilotage vide vert olive #6C7A4A avec voile sombre. **Origine :** réutilise `Plan1/01_fond_poste_pilotage_vide`, retouche : voile sombre noir à environ 55 % d'opacité teinté vert très foncé #0F1A0A, appliqué à tout le plan.

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Carte de l'écran central | Drone sur la carte | Opérateur assis |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | objet | objet | personnage |
| Description | carte vue du ciel nette | drone de dessus, gris foncé | de dos, camouflage, assis droit |
| Position et taille | centre (50 %, 27 %), 33 % de large, 24 % de haut | centre (50 %, 25 %), 8 % de haut | centre (50 %, 64 %), 40 % de haut |
| Calque | 2 | 3 | 4 |
| Animation | visible dès le début, immobile | immobile | immobile |
| États | net | net | assis droit |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) | sans objet (réutilisé) |
| Groupe de génération | seul | avec le contrat (Plan25) | seul |
| Origine | réutilise `Plan1/03_carte_ecran_central`, retouche : voile commun | réutilise `Plan25/01_groupe_contrat_drone_dessus`, retouche : taille très réduite, posé sur la carte | réutilise `Plan1/02_operateur_assis`, retouche : voile commun |
| Remarque | | l'image fait foi : le drone est visible | |

**5. Chronologie.** 0 s : tout est en place, sombre ; 0 s à 4 s : léger zoom lent ; 4 s : fin.

**6. MONTAGE.** Voile sombre sur tout le plan, zoom lent, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan59 (9.2) · sequence46 · 5 s

**1. Identité.** Voix off : « Quand un pays dépend d'un réseau privé pour se défendre, qui décide vraiment : » Image : `Storyboard/sequence46/plan59.webp`.

**2. Ce qui se passe.** Sur fond de nuit, un grand disque blanc, le « pays », est relié par un câble à une constellation de huit satellites en grille. Un grand point d'interrogation rouge apparaît au-dessus. Les satellites pulsent.

**3. FOND (statique).** Aplat bleu nuit #1B1738. **Origine :** MONTAGE (aplat).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Constellation (huit satellites) | Point d'interrogation |
| --- | --- | --- |
| Technique | 1 tel quel (huit copies) | 1 tel quel |
| Type | icône | icône |
| Description | satellites blancs à panneaux bleus, grille 2 × 4, panneaux voisins qui se touchent | point d'interrogation rouge brillant, en une pièce avec son point |
| Position et taille | centres x = 54,6 %, 64,4 %, 74,1 %, 83,9 % ; y = 55,2 % et 71,7 % ; 12,8 % de haut chacun | centre (50,1 %, 25 %), 36 % de haut |
| Calque | 2 | 3 |
| Animation | apparaissent un par un à 1,0 s (0,15 s d'écart), puis pulsent (±6 % de taille) de 2,5 s à 5 s | pop à 1,8 s (0,3 s) |
| États | un | un |
| Parties séparées | non | non |
| Fiche de code | non | non |
| Zones cachées | aucune | aucune |
| Détourage | sans objet (réutilisé) | sans objet (réutilisé) |
| Groupe de génération | seul | avec la caisse militaire (Plan50) |
| Origine | réutilise `Plan10/03_satellite`, huit copies | réutilise `Plan50/02_groupe_caisse_militaire_point_interrogation`, retouche : taille et position |
| Remarque | | la caisse militaire du groupe n'est pas utilisée ici |

Disque blanc uni (ellipse #F4F6FF avec tranche #B8C0E8, centre (18,2 %, 63 %), 19,3 % de large, 25,6 % de haut) et câble blanc-lavande #B8C0E8 qui le relie à la constellation : MONTAGE.

**5. Chronologie.** 0 s : fond ; 0,3 s : le disque ; 0,7 s : le câble ; 1,0 s : les satellites un par un ; 1,8 s : le point d'interrogation ; 2,5 s à 5 s : les satellites pulsent ; 5 s : fin.

**6. MONTAGE.** Disque, câble, pulsation, texte « PAYS » sur le disque, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan60 (9.3) · sequence47 · 5 s

**1. Identité.** Voix off : « … l'État, l'entreprise, ou celui qui tient la télécommande ? » Image : `Storyboard/sequence47/plan60.webp`.

**2. Ce qui se passe.** Trois panneaux verticaux entrent l'un après l'autre : l'État (le bâtiment à cinq côtés sur violet), l'entreprise (une tour de bureaux sur bleu), puis celui qui tient la télécommande (une main qui tient la télécommande géante sur rouge sombre). Zoom sur le troisième.

**3. FOND (statique).** Trois panneaux verticaux de même largeur séparés par un liséré blanc : violet #5A1470, bleu #1E6BB8, rouge sombre #5F0000. **Origine :** MONTAGE (aplats).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Bâtiment à cinq côtés | Tour de bureaux | Main et télécommande |
| --- | --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel | 1 tel quel |
| Type | objet | objet | partie de personnage et objet |
| Description | bâtiment à cinq côtés gris, cour verte, vu du dessus | tour vitrée bleue, fenêtres jaunes éparses | main dans une manche bleu nuit tenant le boîtier gris, bouton rouge, fil blanc qui monte |
| Position et taille | centre (17 %, 47 %), 29,8 % de large, 50,7 % de haut | centre (50,6 %, 50 %), 70 % de haut | boîtier centre (84,5 %, 47 %), 56 % de haut ; la manche descend jusqu'au bas du panneau |
| Calque | 2 | 2 | 2 |
| Animation | entre avec le panneau 1 à 0,2 s (0,5 s) | entre avec le panneau 2 à 1,4 s (0,5 s) | entre avec le panneau 3 à 2,6 s (0,5 s) |
| États | un | un | un |
| Parties séparées | non | non | non |
| Fiche de code | non | non | non |
| Zones cachées | aucune | aucune | aucune |
| Détourage | sans objet (réutilisé) | #00FF00 | #00FF00 |
| Groupe de génération | avec la maison et la parabole (Plan11) | avec la main et la télécommande | idem |
| Origine | réutilise `Plan11/01_groupe_maison_parabole_camouflee_pentagone`, retouche : taille agrandie | généré ici (`Plan60/01_groupe_tour_telecommande_main.json`) | idem, source de la télécommande (asset 08) |
| Remarque | ombre portée : montage | tour bleue sur panneau bleu : un liseré clair peut être ajouté au montage | le fil blanc sort par le haut du panneau (masqué par le cadre) |

**5. Chronologie.** 0 s : fond ; 0,2 s : panneau 1 ; 1,4 s : panneau 2 ; 2,6 s : panneau 3 ; 3,3 s à 5 s : zoom sur le troisième ; 5 s : fin.

**6. MONTAGE.** Les trois panneaux de couleur (x de 0 % à 33,2 %, de 33,6 % à 66,4 % et de 66,8 % à 100 %), les lisérés blancs, les ombres portées des objets, le zoom sur le troisième, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan61 (9.4) · sequence48 · 5 s

**1. Identité.** Voix off : « Les faits restent en partie flous : qui a décidé quoi, et pourquoi ? » Image : `Storyboard/sequence48/plan61.webp`.

**2. Ce qui se passe.** Reprise du brouillard du Plan34. Au centre, un dossier « ORDRE » dont une feuille dépasse, aux lignes noircies. Trois points d'interrogation apparaissent un par un au-dessus. Zoom lent.

**3. FOND (statique).** Brouillard gris #B8BEC4 en lobes arrondis, plein cadre. **Origine :** réutilise `Plan34/01_fond_brouillard` (lot 4), retouche : aucune (zoom lent de 20 %).

**4. ASSETS (dynamiques), du fond vers le devant**

| Champ | Dossier « ORDRE » | Point d'interrogation (trois copies) |
| --- | --- | --- |
| Technique | 1 tel quel | 1 tel quel (trois copies) |
| Type | objet | icône |
| Description | chemise ocre fermée, feuille crème aux lignes noircies qui dépasse | point d'interrogation rouge brillant |
| Position et taille | centre (51 %, 62,5 %), 49 % de haut, 30 % de large | centres (36,2 %, 24,5 %), (50,3 %, 20 %) et (64 %, 25 %) ; 24 %, 28,5 % et 24 % de haut |
| Calque | 2 | 3 |
| Animation | pop à 0,3 s (0,4 s) | pop à 1,2 s, 1,8 s et 2,4 s (0,3 s chacun) |
| États | un | un |
| Parties séparées | non | non |
| Fiche de code | non | non |
| Zones cachées | aucune | aucune |
| Détourage | #00FF00 | sans objet (réutilisé) |
| Groupe de génération | seul | avec la caisse militaire (Plan50) |
| Origine | généré ici (`Plan61/01_dossier_ordre.json`) | réutilise `Plan50/02_groupe_caisse_militaire_point_interrogation`, retouche : taille, trois copies |
| Remarque | | traits d'éclat : montage |

**5. Chronologie.** 0 s : brouillard ; 0,3 s : le dossier ; 1,2 s, 1,8 s, 2,4 s : les trois « ? » ; 0 s à 5 s : zoom lent ; 5 s : fin.

**6. MONTAGE.** Étiquettes « QUI ? », « QUOI ? », « POURQUOI ? », zoom lent, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan62 (9.5) · sequence49 · 4 s

**1. Identité.** Voix off : « Et toi, tu en penses quoi ? Dis-le en commentaire. » Image : `Storyboard/sequence49/plan62.webp`.

**2. Ce qui se passe.** Carton d'appel aux commentaires : fond violet, texte au centre, une petite bulle de commentaires apparaît en bas au centre et un curseur clignote.

**3. FOND (statique).** Carton violet #5A1470 à traînées. **Origine :** réutilise `Plan6/01_fond_carton_violet_trainees` (lot 1), retouche : aucune.

**4. ASSETS (dynamiques).**

| Champ | Bulle de commentaires |
| --- | --- |
| Technique | 1 tel quel |
| Type | icône |
| Description | bulle ronde blanche à bord lavande, petite queue en bas à gauche |
| Position et taille | centre (50,3 %, 85,5 %), 15,7 % de haut |
| Calque | 2 |
| Animation | pop à 0,8 s (0,3 s) |
| États | un |
| Parties séparées | non |
| Fiche de code | non |
| Zones cachées | aucune |
| Détourage | sans objet (réutilisé) |
| Groupe de génération | seul |
| Origine | réutilise `Plan36/02_bulle`, retouche : taille réduite |
| Remarque | gouttes jaunes et roses autour : montage |

**5. Chronologie.** 0 s : fond ; 0,3 s : le texte ; 0,8 s : la bulle ; 4 s : fin.

**6. MONTAGE.** Texte du carton, pop de la bulle, gouttes, curseur qui clignote, logo.

**7. Couverture.** oui.

**8. Points à trancher.** L'image montre de grosses gouttes colorées aux angles au lieu de traînées ; je garde le fond F03 (registre, point 5). Si vous tenez aux gouttes, le fond devient une génération à part.

---

## Plan63 (9.6) · sequence50 · 6 s

**1. Identité.** Voix off : « Et si cette vidéo t'a appris quelque chose, un like aide plus que tu ne le crois. » Image : `Storyboard/sequence50/plan63.webp`.

**2. Ce qui se passe.** Un grand pouce levé arrondi, au centre d'un fond bleu uni. Il rebondit, un « +1 » monte.

**3. FOND (statique).** Aplat bleu #1277C4. **Origine :** MONTAGE (aplat).

**4. ASSETS (dynamiques).**

| Champ | Pouce |
| --- | --- |
| Technique | 1 tel quel |
| Type | icône |
| Description | pouce levé arrondi, sans doigts séparés, couleur chair #FBA68A, reflet sur l'ongle |
| Position et taille | centre (49,7 %, 48,4 %), 63 % de haut, 33 % de large |
| Calque | 2 |
| Animation | pop à 0,3 s (0,4 s), rebond (±6 % de taille) à 1,5 s et 3,5 s |
| États | un |
| Parties séparées | non |
| Fiche de code | non |
| Zones cachées | aucune |
| Détourage | #00FF00 |
| Groupe de génération | seul |
| Origine | généré ici (`Plan63/01_pouce.json`), source du pouce des Plans 5, 36 et 37 |
| Remarque | Plan5 : venu d'en bas à droite ; Plans 36 et 37 : petit, répété |

**5. Chronologie.** 0 s : fond ; 0,3 s : le pouce ; 1,5 s : rebond ; 2 s : le « +1 » monte ; 3,5 s : rebond ; 6 s : fin.

**6. MONTAGE.** Fond en aplat, « +1 » qui monte, rebond, ombre, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.

---

## Plan64 (9.7) · sequence51 · 6 s

**1. Identité.** Voix off : (aucune). Image : `Storyboard/sequence51/plan64.webp`.

**2. Ce qui se passe.** Écran de fin : dégradé bleu, centre vide, l'invitation et la miniature de la vidéo suivante s'affichent.

**3. FOND (statique).** Dégradé vertical #0A97CE (haut) vers #0CD4F3 (bas). **Origine :** MONTAGE (dégradé).

**4. ASSETS (dynamiques).** Aucun.

**5. Chronologie.** 0 s : fond ; 0,5 s : l'invitation ; 1,5 s : la miniature ; 6 s : fin.

**6. MONTAGE.** Dégradé, invitation en capitales blanches, miniature de la vidéo suivante, logo.

**7. Couverture.** oui. **8. Points à trancher.** sans objet.
