# Registre des éléments d'animation (étape 9)

Source : `Storyboard.zip` (dépôt `Storyboard`, commit 5e1a8b6), 64 images 1672×941 lues sur planches-contact numérotées, comparées au `PlanN.txt` de chaque plan, à `Sequences.md`, `Liste_assets.md` et `Images_deja_validees_NE_PAS_RETRIER.md`. **L'image fait foi** : un élément annoncé mais absent n'est pas compté, un élément visible mais non annoncé l'est.

Ce registre est la référence des lots. Chaque asset, sous-asset et fond est généré **une seule fois**, dans le plan source indiqué ; les autres plans le réutilisent. Une génération ne peut regrouper que des éléments **visibles dans la même image de plan** (la seule référence du JSON est cette image). Nom d'une génération : `PlanN/NN_nom` (fond = `01`).

Techniques : 1 tel quel · 2 séparé pour le calque · 3 décomposé · 4 animation par code · 5 feuille de sprites · 6 nouvelle configuration. MONTAGE = rien à générer.

---

## A. Résumé

| Mesure | Valeur |
| --- | --- |
| Plans lus | 64 (aucun bloquant : voir E) |
| Plans sans aucune génération (tout réutilisé ou fait au montage) | 14 : Plan12, 17, 21, 29, 35, 38, 44, 48, 51, 54, 58, 59, 62, 64 |
| Plans avec au moins une génération | 50 |
| Générations d'images (fonds + assets + groupes) | 75 |
| dont fonds vides | 17 |
| dont assets, groupes et sous-assets | 58 |
| Fonds en aplat fait au montage (groupes de plans) | 22 |
| Assets décomposés | 3 (balance, cadenas, cadran), soit 8 sous-assets |
| Calques séparés (technique 2) | 4 : bureau d'angle, pupitre, brouillard avant, téléphone devant le propriétaire (Plan24) |
| Feuilles de sprites | 0 (aucun dessin riche qui change de forme ; voir F4) |
| Éléments en code (fiches) | 10 |
| Nouvelles configurations (technique 6) | 23 : propriétaire 6, opérateur penché, personnage A main sur la tête, foule 10, drone 3 vues, engin à réaction, trois opérateurs de dos |

Je ne chiffre pas les « générations économisées » en pourcentage : je n'ai pas compté toutes les apparitions. Le gain est surtout dans les réutilisations listées en C (par exemple la salle de presse, le satellite, le pentagone et la foule servent dans 4 à 8 plans chacun).

---

## B. Fonds

### B1. Fonds à générer (17, vides, pleine page)

| ID | Fond | Teinte | Plan source (génération) | Plans qui l'utilisent | Retouche de montage | Largeur demandée |
| --- | --- | --- | --- | --- | --- | --- |
| F01 | Poste de pilotage vide (bureau, chaise, clavier, joystick, 3 écrans éteints) | vert olive #6C7A4A | Plan1/01_fond_poste_pilotage_vide | 1, 2, 58 | Plan58 : voile sombre | 16:9 + 15 % (gros plan sur l'écran puis recul) |
| F02 | Pièce du bureau d'angle (baie vitrée, skyline, plantes, sans bureau) | vert menthe #86DDAB | Plan4/01_fond_bureau_angle_vide | 4 | aucune | 16:9 + 15 % (gros plan télécommande puis recul) |
| F03 | Carton violet à traînées | violet #5A1470 (rose #E86FA8, jaune #F2B01E, cyan #7FD6F0) | Plan6/01_fond_carton_violet_trainees | 6, 21, 51, 62 | miroir ou rotation pour varier ; Plan62 : voir F6 | 16:9 |
| F04 | Carton vert forêt à motifs tonaux | vert forêt #1E3A14 | Plan7/01_fond_carton_vert_foret | 7, 29 | Plan29 : liséré blanc central et éclatement en deux (montage) | 16:9 |
| F05 | Fond crème à pictogrammes discrets | crème #FBF8EA | Plan8/01_fond_creme_pictogrammes | 8, 25, 54 | Plan25 : pictogrammes un peu plus clairs (voile) | 16:9 + 10 % (zoom lent) |
| F06 | Tranchée vide (talus, sacs de sable, ciel) | ocre #C98A4B, ciel bleu clair | Plan10/01_fond_tranchee_vide | 10 | aucune | 16:9 + 10 % (recul) |
| F07 | Poste de commandement de nuit vide (mur d'écrans éteints, deux bureaux, sol) | violet #2A1A55 | Plan13/01_fond_poste_commandement_vide | 13 | contenu des écrans (vert puis gris) et halo rouge : montage | 16:9 + 10 % (recul) |
| F08 | Bureau turquoise vu du dessus, dossiers colorés épars (sans journal, sans dossier du centre, sans mains) | turquoise #2EA89E | Plan14/01_fond_bureau_turquoise_vide | 14 | aucune | 16:9 + 20 % (dézoom) |
| F09 | Console de nuit vide (console, leviers, voyants, fenêtre étoilée, sans cadran ni panneau) | bleu violet #2B1F4F | Plan15/01_fond_console_nuit_vide | 15 | aucune | 16:9 + 10 % (zoom lent) |
| F10 | Bleu clair à capsules arrondies (formes douces) | bleu clair #66C8F7 | Plan16/01_fond_bleu_capsules | 9, 16, 17, 28, 36, 37, 50, 55 | Plan17 : miroir. Plans 9, 28, 36, 37, 50, 55 : capsules moins visibles sur l'image du storyboard, la génération en apporte | 16:9 + 15 % (Plan37 agrandit un groupe, Plan55 zoome sur le câble) |
| F11 | Poste de contrôle (moitié droite de Plan31) : console, écran vide, sol | bleu nuit #232B4A | Plan31/01_fond_poste_controle | 31 | barres de signal rouges : montage | 16:9 (utilisé en demi-écran) |
| F12 | Salle de presse vide (murs, deux fenêtres, halo rond, sol, sans pupitre) | gris-vert #7F9490 | Plan32/01_fond_salle_presse_vide | 30, 32, 46, 47, 48, 49 | Plans 30 : recadrage demi-écran. Plans 47 et 49 : recadrage plus serré | 16:9 + 30 % (gros plan sur le personnage puis recul sur la pile de caisses) |
| F13 | Table de négociation ronde vue du dessus, trois chaises, sans jetons | bleu clair #8DE3FA | Plan33/01_fond_table_ronde_vide | 33 | aucune | 16:9 + 15 % (dézoom lent) |
| F14 | Brouillard gris en lobes arrondis, plein cadre | gris #B8BEC4 | Plan34/01_fond_brouillard | 34, 61 | aucune | 16:9 + 20 % (zoom lent) |
| F15 | Mur à panneaux, arches et rideaux, sans personne | bleu #2A74BF | Plan45/01_fond_mur_panneaux | 45 | aucune | 16:9 + 10 % |
| F16 | Carton bleu roi à formes liquides ondulantes | bleu roi #3355B8 | Plan52/01_fond_bleu_roi_liquide | 52 | aucune | 16:9 |
| F17 | Table vue du dessus, sans lettre ni mains | bleu glacier #A9EEE6 | Plan53/01_fond_table_bleu_glacier_vide | 53 | aucune | 16:9 + 15 % (dézoom lent) |

### B2. Fonds en aplat : MONTAGE (rien à générer)

Dossiers de plan : `_rien_a_generer.txt` (ou `_reutilise.txt` si le plan reprend aussi des éléments).

| Plans | Aplat | Remarque |
| --- | --- | --- |
| 3 | bleu nuit #241E45 | |
| 5 | jaune doré #F9C96B | |
| 11, 12 | moitié gauche bleu ciel #A9D6EE, moitié droite vert olive #6C7A4A, liséré blanc | Plan12 : moitié gauche atténuée au montage |
| 18 | ciel de nuit #1B1738 | traînées horizontales derrière drone et engin : montage |
| 19, 20 | rouge sombre #5F0000 | tuiles rouges arrondies du Plan19 : montage |
| 22, 27 | vert sauge #9BA68A | ellipses d'ombre sous les pieds : montage |
| 23 | bordeaux #5E0510 | |
| 24 | orange #F28C3A | |
| 26 | bleu nuit #1B2A55 | |
| 30 | moitié droite bleu nuit #232B4A, vide | devient F11 au Plan31 |
| 35 | bordeaux #4A0A28 | câble fin de la carte : montage |
| 38 | violet #4F1C80 | trois cases blanches arrondies : montage |
| 39, 40 | turquoise #3FD6B5 | |
| 41, 42 | violet #8E5BD0 | |
| 43 | rouge sombre #3D0A0E | trois cadres blancs à bord bleu : montage |
| 44 | violet nuit #2B1030 | |
| 56 | ocre #DDB07A | |
| 57 | bleu #A9D6EE | carte blanche vide en haut : montage |
| 59 | bleu nuit #1B1738 | disque blanc uni : montage |
| 60 | trois panneaux verticaux : violet #5A1470, bleu #1E6BB8, rouge sombre #5F0000 | |
| 63 | bleu #1277C4 | |
| 64 | dégradé #0A97CE vers #0CD4F3 | peut se faire entièrement au montage |

---

## C. Assets

Légende des réutilisations : « réutilise PlanN/NN_nom ».

### 01. Opérateur de drone, de dos, en camouflage

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 1 | assis droit, mains au clavier, de dos, au centre-bas | immobile, au centre de l'attention | 1 (la chaise reste dans le fond F01, derrière lui) | Plan1/02_operateur_assis | aucune |
| 2 | penché en avant, une main sur la tête | change d'état par **coupe** (« Soudain ») | 6 | Plan2/01_operateur_penche_main_tete (même cadrage, taille et ancrage que Plan1/02) | aucune |
| 58 | assis droit, même pose que Plan1 | immobile | 1 | réutilise Plan1/02_operateur_assis | voile sombre commun au fond |

La substitution (coupe) est préférée à une décomposition : le passage du plan 1 au plan 2 est un « soudain », et la main sur la tête n'existe pas dans la pose assise (bras cachés derrière l'écran). Voir F1.

### Écran central du poste de pilotage (carte du drone)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 1 | carte vue du ciel, route, bâtiments, ligne de front en pointillés rouges, nette | décor animé de l'écran | 1 | Plan1/03_carte_ecran_central (sans le drone) | recalée sur l'écran de F01 |
| 2 | même carte, pixellisée en gros carrés | état final de la dégradation | 4 | fiche `Plan2/02_pixellisation_ecran_code.md` (pixellisation progressive appliquée à la carte et au drone) | aucune |
| 58 | carte nette | immobile | 1 | réutilise Plan1/03_carte_ecran_central | voile commun |

Les écrans latéraux (interfaces en barres, sans texte) sont **dans le fond F01**, immobiles.

### 02. Propriétaire du réseau (costume sombre)

Six configurations, chacune générée une fois depuis son plan. Les poses du Plan25 et du Plan26 annoncées par la liste sont **absentes de l'image** : elles ne sont pas comptées.

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 4 | assis derrière le bureau, face, télécommande tenue à deux mains devant la poitrine | immobile ; le bureau passe devant lui | 2 (bureau = calque avant) + 6 pour la pose | Plan4/03_proprietaire_assis_telecommande (la télécommande fait partie de la pose) | aucune |
| 15 | debout, de profil à gauche, bras tendu vers le cadran, souriant | tourne le cadran | 6 | Plan15/02_proprietaire_profil_cadran | aucune |
| 22 | debout, face, mains levées paumes ouvertes, cravate rouge | « pas moi » | 6 | Plan22/01_proprietaire_mains_levees | aucune |
| 23 | debout, face, télécommande tenue à deux mains, à droite de l'image | désigné comme responsable | 6 | Plan23/02_proprietaire_telecommande_debout | aucune |
| 24 | petit, derrière le téléphone, **un seul**, épaules haussées | admet, hausse les épaules | 6 + 2 (le téléphone passe devant) | Plan24/01_proprietaire_epaules | aucune |
| 27 | debout, de profil, mains jointes levées | écho du plan 22 | 6 | Plan27/01_proprietaire_profil_mains_jointes | aucune |

### 03. Soldat générique

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 10 | debout au centre de la tranchée, face, casque | immobile ; le câble part du casque | 1 | Plan10/02_soldat | aucune |

Le câble « nerf » blanc-bleu du casque au satellite (courbe en S, pulsation lente) est **en code** : `Plan10/04_cable_nerf_code.md`.

### 04. Personnage au pupitre (trois personnages, un par rôle)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 30, 31 | personnage A (costume sombre, cravate rouge), buste derrière le pupitre, face | prend la parole | 1 | Plan30/01_personnage_a_buste | Plan31 : identique. Le pupitre passe devant (calque) |
| 47, 48 | même personnage A, à gauche (Plan47) puis au centre (Plan48) | prend la parole | 1 | réutilise Plan30/01_personnage_a_buste | position et taille propres à chaque plan |
| 32 | personnage B (même costume, cravate dorée), buste derrière le pupitre | prend la parole | 1 | Plan32/03_personnage_b_buste | aucune |
| 49 | personnage A en gros plan à mi-buste, une main sur la tête, grimace | doute | 6 | Plan49/01_personnage_a_main_tete | aucune |

**Pupitre avec micros** : calque devant les personnages (technique 2), généré une fois, plan source Plan32 (`Plan32/02_pupitre_micros`). Réutilisé dans 30, 31, 46, 47, 48, 49 (Plan46 : pupitre seul, sans personnage ; Plan49 : cadrage serré).

### 05. Responsable ukrainien (sans visage détaillé)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 31 | debout de face, uniforme vert olive, mains dans le dos, visage sans traits | immobile, devant l'écran | 1 | Plan31/02_responsable_ukrainien | aucune |

### 06. Silhouettes de foule (11 configurations, générées chacune une fois)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 23 | deux silhouettes en costume, de face, sans visage, cravate rouge | immobiles | 6 | Plan23/01_silhouettes_costume_face | aucune |
| 28 | foule dense de dos, têtes levées vers le haut, bande en bas de l'image | immobile | 6 | Plan28/01_foule_dos_tetes_levees | aucune |
| 36 | disque de foule vu du dessus (quatre copies identiques), pouces et bulles au-dessus | s'allument un par un | 1 (quatre copies, halo = montage) | Plan36/01_groupe_foule_rond | quatre copies, positions propres |
| 37 | foule dense en ellipse large vue du dessus | un groupe grossit et occupe l'écran | 6 | Plan37/01_foule_dense | aucune |
| 39 | foule minuscule en rangée, à droite | immobile | 6 | Plan39/01_groupe_couronnee_foule_minuscule | aucune |
| 40 | la même foule, posée sur le plateau droit de la balance | soulevée avec le plateau | 1 | réutilise Plan39/01_groupe_couronnee_foule_minuscule | taille réduite, rotation avec le plateau |
| 41 | six silhouettes debout, poses variées (main à la tête, menton, bras croisés, mains levées), une tient le contrat devant elle | lisent, lèvent les yeux | 6 | Plan41/01_silhouettes_lisent_contrat (sans le contrat dans les mains) | le contrat est l'asset 13 |
| 42 | six silhouettes qui rient, têtes rejetées en arrière, devant le mât | rient | 6 | Plan42/01_silhouettes_rient | aucune |
| 43 | six silhouettes de dos, un bras levé tenant une loupe | observent | 6 (la loupe est greffée sur la silhouette) | Plan43/01_silhouettes_dos_loupes | aucune |
| 45 | trois silhouettes en costume, de dos, alignées | se tournent d'un même geste | 6 | Plan45/02_silhouettes_costume_dos | rotation au montage (miroir en cours de plan) |
| 50 | sept silhouettes en trois-quarts, tournées vers la droite | immobiles | 6 | Plan50/01_silhouettes_groupe_droite | aucune |
| 57 | foule de dos, bras levés, en bande en bas de l'image | lève les bras | 6 | Plan57/01_groupe_foule_bras_coeur | aucune |

### 07. Silhouette couronnée au levier géant

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 39 | à gauche, grande, couronne, tient un levier à boule rouge | immobile | 1 | Plan39/01_groupe_couronnee_foule_minuscule | aucune |
| 40 | même silhouette, plus petite, sur le plateau gauche | pèse sur le plateau | 1 | réutilise Plan39/01_groupe_couronnee_foule_minuscule | taille réduite, rotation avec le plateau |

### 08. Télécommande géante à un bouton

Hors des poses du propriétaire (04, 23), une seule configuration isolée existe. L'image fait foi : la télécommande **n'apparaît pas** dans Plan35 ni dans Plan55.

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 60 | tenue par une main ronde dans une manche, bouton rouge, fil blanc qui sort en haut | panneau 3 : « celui qui tient la télécommande » | 1 | Plan60/01_groupe_tour_telecommande_main | aucune |

### 09. Bâtiment à cinq côtés

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 11, 12 | grand, à droite, relié à la parabole par une flèche blanche | cible de la flèche | 1 | Plan11/01_groupe_maison_parabole_camouflee_pentagone | Plan12 : aucune |
| 22, 27 | petit, en haut à droite, avec son ombre | cible de la flèche rouge | 1 | réutilise Plan11/01_… | taille réduite |
| 60 | grand, plein panneau violet | panneau 1 : « l'État » | 1 | réutilise Plan11/01_… | taille agrandie |

### 10. Satellite et constellation

Un seul satellite, copié autant de fois que nécessaire. La constellation est **faite au montage** par copies.

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 4 | un petit satellite flotte au-dessus de la tête | immobile | 1 | réutilise Plan10/03_satellite | taille réduite |
| 8 | constellation de dix satellites en arc, reliés au pays par des pointillés | apparaît | 1 (dix copies) + 4 (pointillés) | réutilise Plan10/03_satellite ; pointillés : fiche `Plan8/03_pointilles_constellation_code.md` | dix copies en arc |
| 10 | un satellite, en haut au centre | relié au casque par le câble | 1 | Plan10/03_satellite | aucune |
| 54 | un satellite, relié à l'Ukraine par un fil plein | relié | 1 + 4 (fil, même fiche que Plan8, paramètre « plein ») | réutilise Plan10/03_satellite | aucune |
| 55 | satellite dans la première carte | icône | 1 | réutilise Plan10/03_satellite | taille réduite |
| 56 | satellite minuscule en haut à droite | but du chemin | 1 | réutilise Plan10/03_satellite | taille très réduite |
| 59 | constellation de huit satellites en grille 2×4, reliée au disque par un câble | pulsent | 1 (huit copies) | réutilise Plan10/03_satellite | huit copies en grille |

### 11. Carte plate de l'Ukraine

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 8 | grande, au centre, bleu #1E6BB8 | cible de la constellation | 1 | Plan8/02_carte_ukraine | aucune |
| 34 | grande, au centre du brouillard | seule chose qui reste | 1 | réutilise Plan8/02_carte_ukraine | brouillard devant ses bords |
| 35 | petite, en bas à gauche, câble fin qui sort du cadre | dépend d'un câble | 1 | réutilise Plan8/02_carte_ukraine | taille réduite ; le câble est du montage |
| 54 | grande, au centre | cible du fil plein | 1 | réutilise Plan8/02_carte_ukraine | aucune |

### 12. Drone (trois vues)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 1 | drone vu de dessus, petit, sur la carte de l'écran | centre de la carte | 1 | réutilise Plan25/01_groupe_contrat_drone_dessus | taille très réduite, posé sur la carte |
| 9 | vue trois-quarts avant, dans une carte blanche | icône | 6 | Plan9/01_groupe_combine_drone_radar | aucune |
| 18 | vue de côté, petit, à gauche, traînée derrière | poursuit l'engin | 6 | Plan18/01_groupe_drone_cote_jet | traînée = montage |
| 19 | vue trois-quarts, deux copies (la seconde barrée) | icônes | 1 | réutilise Plan9/01_groupe_combine_drone_radar | croix rouge : montage |
| 25 | vue de dessus, grand, dans une carte blanche | usage offensif | 6 | Plan25/01_groupe_contrat_drone_dessus | aucune |

### 13. Document (contrat, lettre d'intention)

Un seul document (cachet rouge, signature). La lettre du Plan53 et le contrat du Plan25 sont le même dessin.

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 25 | vu de dessus, au centre, entre deux flèches | contrat des conditions d'utilisation | 1 | Plan25/01_groupe_contrat_drone_dessus | aucune |
| 41 | petit, tenu devant une silhouette | passe de silhouette en silhouette | 1 | réutilise Plan25/01_… | taille réduite ; déplacement : montage |
| 53 | au centre de la table | lettre d'intention | 1 | réutilise Plan25/01_… | aucune |
| 56 | **absente de l'image** (le « 13 » en chiffres la remplace) ; le prompt corrigé la demande au pied du chemin | lettre posée au départ | 1 | réutilise Plan25/01_… | position en bas à gauche, taille moyenne |

Le drapeau-contrat du Plan42 est dans le mât (asset P6 « Mât avec drapeau blanc »).

### 14. Balance géante (décomposée)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 40 | de face, fléau incliné, plateau gauche bas, plateau droit haut, bulle « ! » à droite | le déséquilibre se met en place | 3 | Plan40/01_balance_decomposee (une image, quatre sous-assets séparés par un vide net, **fléau à l'horizontale**, plateaux au repos) | aucune |

Schéma de décomposition :

| Sous-asset | Point d'attache | Zone cachée à reconstruire | Mouvement | Calque |
| --- | --- | --- | --- | --- |
| Pied et base | sol | aucune | immobile | 1 (arrière) |
| Fléau avec rotule | sommet du pied | partie centrale cachée par la rotule | rotation de −12° à +10° autour de la rotule, 1,5 s, ease-out | 2 |
| Plateau gauche et chaînes | extrémité gauche du fléau | dessous du plateau | suit le fléau (translation), contre-rotation pour rester horizontal | 3 |
| Plateau droit et chaînes | extrémité droite du fléau | dessous du plateau | idem | 3 |

La silhouette couronnée (07) et la foule (06) sont posées sur leurs plateaux et suivent le mouvement. La bulle « ! » est l'asset « bulle » (P5), le point d'exclamation est du texte de montage.

### 15 à 24. Fonds (voir B1)

15 poste de pilotage = F01 · 16 poste de commandement = F07 · 17 bureau d'angle = F02 + calque ci-dessous · 18 salle de presse = F12 · 19 table ronde = F13 · 20 tranchée = F06 · 21 mur à panneaux = F15 · 22 bureau turquoise = F08 · 23 console de nuit = F09 · 24 brouillard = F14.

**Calques ajoutés** (technique 2, un par fond concerné) :

| Calque | Plan source | Plans | Rôle |
| --- | --- | --- | --- |
| Bureau d'angle (devant le propriétaire) | Plan4/02_bureau_angle_calque_avant | 4 | cache le bas du propriétaire |
| Brouillard avant (lobes du premier plan) | Plan34/02_brouillard_calque_avant | 34 | recouvre les jetons qui s'enfoncent |

### Trois opérateurs de dos (poste de commandement)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 13 | trois opérateurs assis de dos devant les bureaux, portables ouverts | immobiles | 6 | Plan13/02_trois_operateurs_dos | aucune |

### Jetons de la table (asset 19)

| Plan | Configuration vue | Rôle | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| 33 | trois jetons (rouge en haut, bleu à gauche, jaune à droite) | glissent depuis les bords | 1 (un groupe, trois jetons séparés) | Plan33/02_groupe_jetons | positions propres |
| 34 | trois jetons à moitié avalés par le brouillard | s'enfoncent | 1 + 2 | réutilise Plan33/02_groupe_jetons | aux bords, derrière le calque brouillard avant |

Les flèches blanches courbes entre les jetons (double sens) sont **en code** : variante de `Plan22/02_trace_fleche_courbe_code.md` (blanc, deux pointes).

### Planche 1 : télécom

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Parabole blanche sur maison | 11, 12 | maison à toit rouge et parabole blanche, à gauche | 1 | Plan11/01_groupe_maison_parabole_camouflee_pentagone | Plan12 : atténuée (montage) |
| Parabole camouflée | 11, 12, 22, 27 | parabole camouflée sur trépied, inclinée vers le haut à droite | 1 | idem Plan11/01_… | Plans 22 et 27 : agrandie |
| Antenne au sol | 55 | parabole blanche sur trépied dans une carte | 1 | Plan55/01_groupe_antenne_terminal_ciseaux | aucune |
| Terminal | 55 | **corrigé dans le prompt** (l'image montre un combiné radio) : petit terminal d'utilisateur posé | 1 | idem Plan55/01_… | aucune |
| Combiné radio | 9 | talkie-walkie vert olive dans une carte | 1 | Plan9/01_groupe_combine_drone_radar | aucune |
| Antenne de brouillage | 3 | pylône relais, grande, centre | 1 | Plan3/01_antenne_brouillage | croix rouge : montage |

### Planche 2 : militaire

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Radar sous bouclier | 9 | parabole radar sous dôme transparent | 1 | Plan9/01_groupe_combine_drone_radar | aucune |
| Camion | 19 | camion militaire vert, vue de côté | 1 | Plan19/01_groupe_camion_jumelles | aucune |
| Jumelles | 19 | jumelles à lentilles bleues | 1 | idem | aucune |
| Engin à réaction | 18 | avion de chasse de côté, flamme bleue, à droite | 6 | Plan18/01_groupe_drone_cote_jet | traînée : montage |
| Caisse de matériel militaire | 50 | caisse verte à coins métalliques, grande, sous un point d'interrogation | 1 | Plan50/02_groupe_caisse_militaire_point_interrogation | aucune |

### Planche 3 : bureau

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Journal plié | 14, 23 | journal vu de dessus, photo grise | 1 | Plan14/02_groupe_journal_dossier | Plan23 : agrandi, incliné (rotation −15°) |
| Dossier titré | 14 | dossier beige, étiquette vide, au centre | 1 | idem | aucune |
| Dossier « ORDRE » | 61 | dossier ocre fermé, feuille noircie qui dépasse | 1 | Plan61/01_dossier_ordre | aucune |
| Tour de bureaux | 60 | tour vitrée bleue, fenêtres jaunes éparses | 1 | Plan60/01_groupe_tour_telecommande_main | aucune |

### Planche 4 : interface

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Téléphone générique | 5, 24 | grand, de face, publication (pastille, barres, bouton vide) | 1 | Plan5/01_telephone | Plan24 : calque devant le propriétaire |
| Fenêtre « CORRECTIF » | 26 | fenêtre sombre à trois pastilles, **sans barres** | 3 simple (cadre seul) + 4 | Plan26/01_fenetre_correctif_vide ; barres et coche : fiche `Plan26/02_barres_correctif_code.md` | aucune |
| Calendrier orange | 20 | de face, huit cases vides en deux rangées | 1 | Plan20/01_calendrier | croix : fiche `Plan20/02_croix_calendrier_code.md` |
| Cadran « VITESSE » | 15 | cadran rond sur la console, flèches courbes autour | 3 | Plan15/03_groupe_cadran_panneau | voir ci-dessous |
| Panneau rond de limitation | 15 | disque blanc vide, bord rouge | 1 | idem | pop au montage |

Décomposition du cadran :

| Sous-asset | Point d'attache | Zone cachée | Mouvement | Calque |
| --- | --- | --- | --- | --- |
| Socle et boîtier | console | aucune | immobile | 1 |
| Bague et aiguille (disque mobile) | centre du cadran | dessous de l'aiguille | rotation de 0° à −60°, 1 s, ease-in-out | 2 |

### Planche 5 : symboles

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Pouce rond | 5, 36, 37, 63 | pouce levé, grand, au centre (Plan63) | 1 | Plan63/01_pouce | Plan5 : venu d'en bas à droite, rotation et taille ; Plans 36, 37 : petit, répété |
| Cœur | 57 | cœur rouge | 1 + 4 | Plan57/01_groupe_foule_bras_coeur ; montée : fiche `Plan57/02_coeurs_montants_code.md` | tailles variées |
| Loupe | 43 | greffée sur les silhouettes | — | voir asset 06 (Plan43) | — |
| Masque comique | 41 | masque jaune souriant, en haut à gauche, **entier** (prompt corrigé) | 1 | Plan41/02_masque_comique | aucune |
| Bulle de commentaires | 36, 37, 40, 62 | bulle ronde blanche, petite queue | 1 | Plan36/02_bulle | Plan40 : avec « ! » du montage ; Plan48 : grande bulle rectangulaire = montage |
| Point d'interrogation | 49, 50, 59, 61 | point rouge brillant, grand | 1 | Plan50/02_groupe_caisse_militaire_point_interrogation | Plans 49, 59, 61 : taille et nombre (trois au Plan61). Les « ? » blancs du Plan43 sont du texte de montage |

### Planche 6 : objets de scène

| Élément | Plan | Configuration vue | Technique | Génération | Retouche |
| --- | --- | --- | --- | --- | --- |
| Cadenas | 46 | grand, **ouvert**, devant le pupitre | 3 | Plan46/01_cadenas_decompose | voir ci-dessous |
| Ciseaux avec câble | 55 | ciseaux rouges et gris ouverts, étincelle | 1 + 4 | Plan55/01_groupe_antenne_terminal_ciseaux ; câble : fiche `Plan55/02_cable_coupe_code.md` | aucune |
| Sablier | 56 | petit sablier doré, à côté de la lettre | 1 | Plan56/01_sablier | aucune |
| Puzzle incomplet | 49 | grand puzzle coloré à pièces manquantes, derrière le personnage | 1 | Plan49/02_puzzle_incomplet | pièces cachées par le personnage à reconstruire |
| Caisses « ÉQUIPEMENT » avec billets | 47 | pile de trois caisses vertes, panneau vide au-dessus, billets qui tombent | 1 + 4 | Plan47/01_caisses_equipement ; billets : fiche `Plan47/02_billets_code.md` | panneau vide : montage |
| Mât avec drapeau blanc | 42 | mât avec drapeau en forme de contrat plié, hissé | 1 | Plan42/02_mat_drapeau_contrat | aucune |

Décomposition du cadenas :

| Sous-asset | Point d'attache | Zone cachée | Mouvement | Calque |
| --- | --- | --- | --- | --- |
| Corps | sol | aucune | immobile | 2 |
| Anse | charnière côté droit du corps | partie de l'anse qui entre dans le corps | translation de 6 % de la hauteur vers le bas, puis pivot à +40° (ouverture, 1,2 s) | 1 |

### Autres éléments vus dans les images, non listés

| Élément | Plan | Technique | Génération |
| --- | --- | --- | --- |
| Mains rondes tenant un document, qui glissent | 14 | 1 | Plan14/03_mains_document |
| Trois mains rondes qui signent, avec feuille devant chacune | 53 | 1 (un groupe, trois copies retournées au montage) | Plan53/02_mains_stylo_feuille ; tracé des signatures : montage |
| Flèche rouge courbe (parabole vers le bâtiment, journal vers le propriétaire) | 22, 23, 27 | 4 | fiche `Plan22/02_trace_fleche_courbe_code.md` |
| Flèches blanches droites (Plan11, 12), bleues (Plan25) | 11, 12, 25 | MONTAGE | — |
| Flèches pointillées à « ? » entre trois cadres | 43 | 4 | variante de `Plan22/02_trace_fleche_courbe_code.md` (pointillé) |
| Chemin pointillé en serpentin, de la lettre au satellite | 56 | 4 | fiche `Plan56/02_chemin_pointille_code.md` |
| Croix rouge (antenne, drone) | 3, 19 | MONTAGE | — |
| Halos rouge (Plan13) et jaune (Plan36, 37) | 13, 36, 37 | MONTAGE | — |
| Cartes blanches arrondies (icônes) | 9, 19, 25, 55 | MONTAGE | — |
| Câble fin de la carte (Plan35), disque blanc et câble (Plan59) | 35, 59 | MONTAGE | — |

---

## D. Assets à usage unique

| Plan | Élément | Technique |
| --- | --- | --- |
| 1 | Carte de l'écran central | 1 (puis 4 au Plan2) |
| 3 | Antenne de brouillage | 1 |
| 4 | Bureau d'angle (calque avant) | 2 |
| 5 | Téléphone | 1 (repris au Plan24) |
| 13 | Trois opérateurs de dos | 6 |
| 14 | Mains qui tiennent un document | 1 |
| 15 | Cadran, panneau rond | 3, 1 |
| 20 | Calendrier orange | 1 |
| 26 | Fenêtre « CORRECTIF » | 3 simple |
| 31 | Responsable ukrainien | 1 |
| 32 | Pupitre (réutilisé ailleurs), personnage B | 2, 1 |
| 40 | Balance géante | 3 |
| 41 | Masque comique | 1 |
| 42 | Mât avec drapeau-contrat | 1 |
| 46 | Cadenas | 3 |
| 47 | Caisses d'équipement | 1 |
| 49 | Puzzle incomplet | 1 |
| 53 | Mains qui signent | 1 |
| 56 | Sablier | 1 |
| 57 | Cœur | 1 |
| 61 | Dossier « ORDRE » | 1 |

---

## E. Plans à regénérer

**Aucun.** Les plans signalés aux contrôles précédents sont réglés : Plan17, Plan20 et Plan25 ont été regénérés et validés (commit 5e1a8b6). Aucune image n'est noire, blanche ni vide ; les 64 images font 1672×941. Les défauts restants sont des défauts de détail, corrigés dans les prompts (section G) sans regénérer.

Plan44 (aplat violet nuit) et Plan64 (dégradé) sont voulus.

---

## F. Points à trancher

1. **Opérateur : coupe plutôt que décomposition.** Le passage Plan1 vers Plan2 est une coupe sur « Soudain ». Si vous préférez que le bras monte vers la tête, il faudra décomposer l'opérateur (tronc, tête, bras avec main), ce qui ajoute au moins trois sous-assets et la reconstruction des bras cachés.
2. **Foule : onze configurations.** C'est le poste le plus coûteux. Chaque plan montre une foule différente (dos, dessus, trois-quarts, rieuse, avec loupes). Je les génère séparément. Les réunir en une feuille unique de silhouettes à recombiner est possible, mais l'image du plan ne montre pas cette feuille : il faudrait une génération depuis l'asset 06 de `assetsBrute1`, hors règle du JSON à référence unique.
3. **Pouce du Plan5.** L'image montre un pouce arrondi dessiné comme une main, pas le pouce levé du Plan63. Je prends le Plan63 comme source ; au Plan5 il vient d'en bas à droite par rotation et déplacement.
4. **Feuilles de sprites : aucune.** Aucun élément n'est un dessin riche qui change de forme. Les états successifs (cases du calendrier, barres du correctif) sont des tracés géométriques : code.
5. **Carton violet du Plan62.** L'image montre des gouttes colorées sur les bords au lieu de traînées. Je réutilise F03 et j'ajoute la bulle ; si vous tenez aux gouttes, le fond devient une génération à part.
6. **Capsules du bleu clair.** Les plans 9 et 28 ont un bleu clair presque uni ; F10 en apporte. Je le note sans le corriger.
7. **Plan25 : parabole blanche.** Le prompt demandait une parabole bleue ; l'image montre une parabole blanche. Je garde l'image (cohérente avec les paraboles de la planche 1).
8. **Plan30 : demi-écran.** F12 sert en recadrage de moitié ; la moitié droite est un aplat (montage) jusqu'au Plan31, où elle devient F11.
9. **Sablier du Plan56.** Il est bien visible ; l'image montre en plus un « 13 » en chiffres 3D et pas de lettre : voir G.

---

## G. Détails corrigés dans les prompts

Décisions déjà prises, pas des questions. Chaque correction décrit ce que le plan devait montrer, jamais le défaut lui-même.

| Plan | Défaut vu | Correction écrite dans le prompt | Générations concernées |
| --- | --- | --- | --- |
| 5 | pouce dessiné comme une main avec des doigts | « un seul pouce rond, sans doigts, entier » (le pouce vient du Plan63) | Plan63/01_pouce |
| 22 | bâtiment à cinq côtés trop petit, en haut à droite | « bâtiment à cinq côtés bien visible, de taille moyenne, comme dans l'asset 09 » | Plan11/01_… (pentagone), Plan22/01_proprietaire_mains_levees |
| 23 | la flèche rouge part du journal vers les deux silhouettes au lieu d'aller vers le propriétaire | « la flèche rouge part du journal et arrive sur le propriétaire à droite » | Plan22/02_trace_fleche_courbe_code.md (variante), Plan23/02_proprietaire_telecommande_debout |
| 24 | deux propriétaires de part et d'autre du téléphone | « un seul propriétaire, plus petit, de dos, derrière le téléphone, épaules haussées » | Plan24/01_proprietaire_epaules |
| 26 | la barre rouge barrée n'apparaît pas, seule la barre verte à coche | « état final : une barre verte avec une coche ; la barre rouge barrée précède » (barres en code) | Plan26/01_fenetre_correctif_vide, Plan26/02_barres_correctif_code.md |
| 27 | pose de profil, mains jointes au lieu de mains levées paumes ouvertes | « même scène que le Plan22, propriétaire de profil, mains levées ; bâtiment à cinq côtés bien visible » | Plan27/01_proprietaire_profil_mains_jointes |
| 41 | masque comique coupé en haut à gauche, aspect d'émoji | « masque comique entier, non coupé, avec de la marge, dessiné comme un masque de théâtre et non un émoji » | Plan41/02_masque_comique |
| 55 | troisième icône = combiné radio au lieu du terminal | « troisième icône : un terminal d'utilisateur, pas un combiné radio » | Plan55/01_groupe_antenne_terminal_ciseaux |
| 56 | un « 13 » en chiffres 3D dessiné, lettre absente | « la lettre seule au pied du chemin, aucun chiffre, aucune lettre, aucun texte » | Plan56/01_sablier (sablier seul ; la lettre est l'asset 13) |

---

## H. Annexe : index des générations par plan

Une ligne par plan qui génère quelque chose. Les noms sont ceux des dossiers de l'archive de prompts.

| Plan | Générations (images) | Fiches de code |
| --- | --- | --- |
| 1 | 01_fond_poste_pilotage_vide, 02_operateur_assis, 03_carte_ecran_central | — |
| 2 | 01_operateur_penche_main_tete | 02_pixellisation_ecran_code.md |
| 3 | 01_antenne_brouillage | — |
| 4 | 01_fond_bureau_angle_vide, 02_bureau_angle_calque_avant, 03_proprietaire_assis_telecommande | — |
| 5 | 01_telephone | — |
| 6 | 01_fond_carton_violet_trainees | — |
| 7 | 01_fond_carton_vert_foret | — |
| 8 | 01_fond_creme_pictogrammes, 02_carte_ukraine | 03_pointilles_constellation_code.md |
| 9 | 01_groupe_combine_drone_radar | — |
| 10 | 01_fond_tranchee_vide, 02_soldat, 03_satellite | 04_cable_nerf_code.md |
| 11 | 01_groupe_maison_parabole_camouflee_pentagone | — |
| 13 | 01_fond_poste_commandement_vide, 02_trois_operateurs_dos | — |
| 14 | 01_fond_bureau_turquoise_vide, 02_groupe_journal_dossier, 03_mains_document | — |
| 15 | 01_fond_console_nuit_vide, 02_proprietaire_profil_cadran, 03_groupe_cadran_panneau | — |
| 16 | 01_fond_bleu_capsules | — |
| 18 | 01_groupe_drone_cote_jet | — |
| 19 | 01_groupe_camion_jumelles | — |
| 20 | 01_calendrier | 02_croix_calendrier_code.md |
| 22 | 01_proprietaire_mains_levees | 02_trace_fleche_courbe_code.md |
| 23 | 01_silhouettes_costume_face, 02_proprietaire_telecommande_debout | — |
| 24 | 01_proprietaire_epaules | — |
| 25 | 01_groupe_contrat_drone_dessus | — |
| 26 | 01_fenetre_correctif_vide | 02_barres_correctif_code.md |
| 27 | 01_proprietaire_profil_mains_jointes | — |
| 28 | 01_foule_dos_tetes_levees | — |
| 30 | 01_personnage_a_buste | — |
| 31 | 01_fond_poste_controle, 02_responsable_ukrainien | — |
| 32 | 01_fond_salle_presse_vide, 02_pupitre_micros, 03_personnage_b_buste | — |
| 33 | 01_fond_table_ronde_vide, 02_groupe_jetons | — |
| 34 | 01_fond_brouillard, 02_brouillard_calque_avant | — |
| 36 | 01_groupe_foule_rond, 02_bulle | — |
| 37 | 01_foule_dense | — |
| 39 | 01_groupe_couronnee_foule_minuscule | — |
| 40 | 01_balance_decomposee | — |
| 41 | 01_silhouettes_lisent_contrat, 02_masque_comique | — |
| 42 | 01_silhouettes_rient, 02_mat_drapeau_contrat | — |
| 43 | 01_silhouettes_dos_loupes | — |
| 45 | 01_fond_mur_panneaux, 02_silhouettes_costume_dos | — |
| 46 | 01_cadenas_decompose | — |
| 47 | 01_caisses_equipement | 02_billets_code.md |
| 49 | 01_personnage_a_main_tete, 02_puzzle_incomplet | — |
| 50 | 01_silhouettes_groupe_droite, 02_groupe_caisse_militaire_point_interrogation | — |
| 52 | 01_fond_bleu_roi_liquide | — |
| 53 | 01_fond_table_bleu_glacier_vide, 02_mains_stylo_feuille | — |
| 55 | 01_groupe_antenne_terminal_ciseaux | 02_cable_coupe_code.md |
| 56 | 01_sablier | 02_chemin_pointille_code.md |
| 57 | 01_groupe_foule_bras_coeur | 02_coeurs_montants_code.md |
| 60 | 01_groupe_tour_telecommande_main | — |
| 61 | 01_dossier_ordre | — |
| 63 | 01_pouce | — |

Plans sans génération (`_reutilise.txt` ou `_rien_a_generer.txt`) : 12, 17, 21, 29, 35, 38, 44, 48, 51, 54, 58, 59, 62, 64.
