# AnimationData - projet 6-musk_starlink (chaine IngeniaX)

Archive generee par envoyer_animation.py le 2026-11-04 17:03. Elle contient TOUT ce qu'il faut pour animer chaque plan en web (HTML, CSS, JavaScript). Si un fichier manque, c'est un defaut de l'archive : le signaler en une phrase et corriger envoyer_animation.py, ne jamais demander le fichier a l'utilisateur.

## Ordre de lecture
1. README.md (ce fichier), puis manifest.json (retrouver n'importe quel fichier).
2. directives/Director.md (procedure de travail), directives/Plan_animation.md (le scenario complet : charte et palette, arbitrages, les 9 parties plan par plan, annexes), directives/Sequences.md (durees).
3. directives/Liste_assets_animation.md (fiche de chaque plan : positions, calques, animations, chronologie, points a trancher), directives/Registre_elements_animation.md (reutilisations, retouches, techniques 1 a 6), directives/Liste_assets.md (assets de base et consignes de montage).
4. scenario/ : Sequences.md, et pour chaque sequenceN/ le speech.txt (voix off) et les PlanN.txt (identite du plan, ce qu'il represente, composition, FAIT AU MONTAGE).
5. assets/PlanN/ : les SVG a animer, puis storyboard/ pour verifier visuellement chaque plan.

## Conventions
- Image du plan : 1672 x 941. Positions en % de la largeur (x) et de la hauteur (y) ; taille en % de la hauteur ; rotation en degres, sens horaire ; calques du fond vers le devant ; noms de fichiers NN_nom.
- Les SVG gardent leur fond de detourage vert (#00FF00) ou magenta (#FF00FF) : ce fond (premier <path> plein cadre) est retire dans le code d'animation, jamais dans le SVG d'origine.
- Le montage (logo, polices des cartons, etiquettes, badges) est hors perimetre : ses consignes restent dans les fiches mais ne sont pas animees.

## Contenu
- assets/PlanN/ : 101 fichiers (SVG, fiches NN_nom_code.md pour les elements dessines en JavaScript, _reutilise.txt, _rien_a_generer.txt). Le dossier AssetAnimation du PC n'existe pas dans l'archive.
- assets_images/PlanN/ : 75 .webp d'origine (modele pour juger la vectorisation).
- prompts_assets/PlanN/ : 75 JSON de generation (nom, prompt, references) : ce que l'asset est cense montrer.
- storyboard/sequenceN/planN.webp : 64 images de plan (modele visuel).
- scenario/ : 166 fichiers texte, dont scenario/speech_originaux_fr/ (sauvegarde des speech.txt francais d'origine ; les speech.txt de sequenceN/ sont la version balisee pour l'audio).
- assets_base/ : index.csv, prompts/<asset>/prompt.txt et images/*.png (images brutes, planches de poses comprises) : 61 fichiers.
- directives/ : 6 documents.

## Audio
- audio/sequenceN/PlanN.<ext> : 63 fichiers (Plan1 a Plan63 ; le plan 64 n'a pas de voix off), extension reelle. A integrer directement en base64 dans la page HTML du plan.

## Plans qui reutilisent ou n'ont rien a generer
- _reutilise.txt (renvoie a PlanN/NN_nom avec la retouche a appliquer ; le plan DEPEND de son plan source, qu'il faut avoir animé avant) : plans 12, 17, 21, 29, 35, 48, 51, 54, 58, 59, 62.
- _rien_a_generer.txt (rien a generer, voir la fiche du plan) : plans 38, 44, 64.

## manifest.json
Ouvrir un fichier avec son chemin_relatif : plans[PlanN] (chemin relatif a assets/), storyboard[PlanN] (relatif a storyboard/), audio[PlanN] (relatif a audio/), fichiers_supplementaires (groupe + chemin relatif a ce groupe). chemin_zip donne le chemin complet depuis la racine du zip. Tous les chemins utilisent /.

## Decisions sur les points a trancher
Aucune decision fournie par l'utilisateur : lecture par defaut indiquee dans chaque fiche (section 8 de Liste_assets_animation.md, section F du registre).
