# Fiche de code : câble coupé par les ciseaux (Plan55)

**Ce que l'élément fait.** Un câble épais gris-bleu foncé sort du bas de la première carte (satellite) et du bas de la deuxième (antenne au sol), descend en courbe, se rejoint en une ligne horizontale et file vers la droite jusqu'au bord de l'image. Il se trace puis se tend (léger frémissement). Les ciseaux arrivent, le câble est coupé : les deux bouts se décalent, celui de gauche retombe un peu, celui de droite part vers l'extérieur du cadre. Une étincelle brève (quatre traits blancs) jaillit à la coupe.

**Entrée.** Positions en % de l'image du plan : sortie sous la carte 1 à (19,5 %, 66 %) ; sortie sous la carte 2 à (49 %, 65 %) ; ligne horizontale à y = 76,5 % ; sortie à droite du cadre à (100 %, 76,5 %). Point de coupe : x = 82 %, y = 76,5 %.

**Paramètres modifiables**
| Paramètre | Valeur |
| --- | --- |
| Couleur du câble | #3A4558 (reflet #5A6678 sur le dessus, 20 % de l'épaisseur) |
| Épaisseur | 2,7 % de la hauteur de l'image |
| Courbes de départ | rayon de 9 % de la hauteur, de la verticale à l'horizontale |
| Tracé | 1,2 s, depuis les deux cartes vers la droite, ease-out |
| Tension | frémissement vertical de ±0,3 % de la hauteur, 2 oscillations, 0,5 s |
| Coupe | à 5,6 s ; bout gauche : écart de 3 % de la largeur et chute de 1,5 % de la hauteur en 0,4 s ; bout droit : écart de 4 % et sortie hors cadre en 0,6 s |
| Extrémités | coupe nette en biais, intérieur cuivre #C97B3A visible sur 25 % de l'épaisseur |
| Étincelle | 4 traits blancs #FFFFFF de 3 % de la largeur, 0,25 s, centrés sur (82 %, 76,5 %) |
| Début du plan | 3,6 s (après l'entrée de la troisième carte) |

**Position et taille.** Voir « Entrée » : le câble occupe la bande y de 65 % à 79 % et x de 19 % à 100 % de l'image.

**Entrée et sortie dans le plan.** Entrée à 3,6 s, tension de 4,8 à 5,6 s, coupe à 5,6 s, bouts visibles jusqu'à 8 s. Le zoom sur le câble (montage) accompagne la coupe.

**Sortie attendue.** Animation de 8 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo.
