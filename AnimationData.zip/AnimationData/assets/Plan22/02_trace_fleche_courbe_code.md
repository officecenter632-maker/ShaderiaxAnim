# Fiche de code : flèche courbe tracée (Plan22, variantes Plan23, Plan27, puis Plan33 et Plan43)

**Ce que l'élément fait.** Une flèche à bout arrondi se trace le long d'une courbe, d'un point de départ à un point d'arrivée, puis une pointe triangulaire apparaît à l'arrivée. Une seule fiche, plusieurs variantes selon le plan.

**Entrée.** Départ, arrivée et point de contrôle de la courbe, en % de l'image du plan. L'arrivée est toujours le centre (ou le bord proche) de la cible.

**Paramètres communs**
| Paramètre | Valeur par défaut |
| --- | --- |
| Épaisseur du trait | 1 % de la hauteur de l'image (environ 9 px), extrémité arrondie |
| Pointe | triangle, 3 % de la largeur de l'image, orienté selon la tangente d'arrivée |
| Courbe | spline quadratique, bombée vers le haut |
| Courbe de tracé | ease-out |
| Style | aplat, aucune ombre, aucun halo |

**Variantes**
| Variante | Plans | Départ | Arrivée | Point de contrôle | Couleur | Tracé | Début |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A. Parabole vers bâtiment | 22 et 27 | (70 %, 38 %), sommet de la parabole camouflée | (82 %, 22 %), bord gauche du bâtiment à cinq côtés | (72 %, 24 %) | #E3262B | 0,6 s | Plan22 : 2,2 s ; Plan27 : 1,5 s |
| B. Journal vers propriétaire | 23 | (20 %, 33 %), bord haut-droit du journal | (74 %, 30 %), à gauche du propriétaire | (47 %, 12 %), la flèche passe au-dessus des deux silhouettes | #E3262B | 0,9 s | 1,6 s |
| C. Jetons, deux pointes | 33 | voir le lot du Plan33 | | | #FFFFFF | 0,6 s | |
| D. Pointillé vers étiquettes | 43 | voir le lot du Plan43 | | | pointillé | 0,6 s | |

**Précision (correction du Plan23).** Dans la variante B, la flèche ne s'arrête pas sur les deux silhouettes : elle les survole et arrive sur le propriétaire à droite.

**Sortie attendue.** Animation sur fond transparent, à la durée du plan, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Les variantes C et D sont complétées dans les lots des plans concernés.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo ; mêmes couleurs que le plan.
