# Fiche de code : chemin pointillé en serpentin (Plan56)

**Ce que l'élément fait.** Un long chemin en tirets blancs part de la lettre, en bas à gauche, monte en serpentant (quatre grands virages) et finit au petit satellite, en haut à droite. Le chemin se trace progressivement du pied de la lettre vers le satellite ; les tirets avancent ensuite lentement vers le satellite (effet de marche).

**Entrée.** Points de passage en % de l'image du plan, dans l'ordre : (21 %, 86 %) → (70 %, 66 %) → (36 %, 50 %) → (80 %, 35 %) → (50 %, 23 %) → (79 %, 14 %), courbe lisse (spline) passant par ces points ; les virages extrêmes sont à x = 36 % et x = 80 %.

**Paramètres modifiables**
| Paramètre | Valeur |
| --- | --- |
| Couleur | #FFFFFF, opacité 0,95 |
| Tirets | longueur 2,7 % de la largeur, vide 1,5 % de la largeur, épaisseur 1,5 % de la hauteur, extrémités arrondies |
| Durée du tracé | 2,4 s, ease-in-out, du point de départ vers le satellite |
| Vitesse des tirets | 20 px/s vers le satellite, après le tracé |
| Début du plan | 0,6 s |

**Position et taille.** Le tracé occupe x de 21 % à 80 %, y de 14 % à 86 % de l'image. Il part du côté droit de la lettre (sous le sablier, à droite) et s'arrête à 1,5 % du satellite.

**Entrée et sortie dans le plan.** Entrée à 0,6 s, tracé complet à 3 s, tirets qui avancent jusqu'à 4 s.

**Sortie attendue.** Animation de 4 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo.
