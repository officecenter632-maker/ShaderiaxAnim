# Fiche de code : croix rouges du calendrier (Plan20)

**Ce que l'élément fait.** Les huit cases vides du calendrier se barrent d'une croix rouge, une par une, de plus en plus vite. Chaque croix se trace en deux traits (diagonale descendante, puis diagonale montante). La huitième croix clôt l'animation.

**Entrée.** Centres des huit cases, en % de l'image du plan (rangée du haut puis rangée du bas, de gauche à droite).

| Case | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| x | 33,4 % | 44,4 % | 55,5 % | 66,5 % | 33,4 % | 44,4 % | 55,5 % | 66,5 % |
| y | 48 % | 48 % | 48 % | 48 % | 68 % | 68 % | 68 % | 68 % |
| Début (s) | 0,4 | 0,85 | 1,25 | 1,6 | 1,9 | 2,15 | 2,35 | 2,5 |
| Durée du tracé (s) | 0,22 | 0,2 | 0,18 | 0,16 | 0,14 | 0,12 | 0,1 | 0,1 |

**Paramètres modifiables**
| Paramètre | Valeur par défaut |
| --- | --- |
| Couleur | #D81E1E |
| Épaisseur du trait | 1 % de la hauteur de l'image (environ 9 px), extrémités arrondies |
| Taille d'une croix | 70 % de la largeur d'une case (une case fait environ 10 % de la largeur de l'image) |
| Courbe de tracé | ease-out |
| Sortie | les croix restent visibles jusqu'à la fin du plan (3 s) |

**Sortie attendue.** Animation de 3 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Pas de lueur ni d'ombre. Le texte « PLUS D'UNE SEMAINE » et le voile sombre qui monte à partir de 2,6 s sont du montage.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo ; mêmes couleurs que le plan.
