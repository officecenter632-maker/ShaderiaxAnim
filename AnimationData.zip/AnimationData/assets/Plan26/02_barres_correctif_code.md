# Fiche de code : barres du correctif (Plan26)

**Ce que l'élément fait.** Dans la fenêtre « CORRECTIF » (cadre vide généré), cinq barres arrondies figurent la liste. La première est d'abord rouge (la faille) ; une ligne la barre, puis elle est remplacée par une barre verte et une coche verte apparaît à droite. Les quatre autres barres blanches sont visibles dès le début. L'image du storyboard montre l'état final.

**Entrée.** Positions en % de l'image du plan ; fenêtre centrée en (50 %, 47,5 %), 55 % de large, 61 % de haut.

**Barres**
| Barre | Début x | Longueur | y (centre) | Couleur finale |
| --- | --- | --- | --- | --- |
| 1 (faille) | 26,4 % | 40,2 % | 36 % | rouge #E03A3E, puis vert #46C96F |
| 2 | 26,4 % | 35,6 % | 44 % | #F6F5F8 |
| 3 | 26,4 % | 40,2 % | 52,5 % | #F6F5F8 |
| 4 | 26,4 % | 39,8 % | 60,5 % | #F6F5F8 |
| 5 | 26,4 % | 29,4 % | 68,5 % | #F6F5F8 |

Épaisseur : 4 % de la hauteur de l'image, extrémités arrondies.

**Chronologie (4 s)**
| Temps | Action |
| --- | --- |
| 0 s | les cinq barres sont là ; la première est rouge |
| 0,8 s à 1,2 s | un trait noir bleuté #16274F barre la première barre de gauche à droite (0,4 s) |
| 1,6 s à 2,1 s | la barre rouge disparaît par la droite, la barre verte se déploie de gauche à droite à la même place (0,5 s, ease-out) |
| 2,2 s à 2,5 s | la coche verte #46C96F apparaît à droite (pop de 0,25 s), centre (71,5 %, 35 %), 6,5 % de large |
| 2,5 s à 4 s | état final maintenu |

**Sortie attendue.** Animation de 4 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Pas de lueur ni d'ombre.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo ; mêmes couleurs que le plan.
