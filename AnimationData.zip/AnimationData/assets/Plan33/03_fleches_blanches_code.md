# Fiche de code : flèches blanches à deux pointes entre les jetons (Plan33)

Complète la variante C de `Plan22/02_trace_fleche_courbe_code.md` : mêmes paramètres communs (trait de 1 % de la hauteur de l'image, extrémités arrondies, courbe quadratique, ease-out, aplat sans ombre), avec une pointe à **chaque bout**.

**Ce que l'élément fait.** Trois arcs blancs relient les trois jetons deux à deux, en triangle. Chaque arc se trace du centre vers les deux bouts, puis les deux pointes triangulaires apparaissent.

**Arcs (en % de l'image du plan, mesurés sur l'image)**
| Arc | Départ | Arrivée | Point de contrôle | Début | Tracé |
| --- | --- | --- | --- | --- | --- |
| Gauche (rouge vers bleu) | (46 %, 8 %) | (26 %, 68,5 %) | (15,5 %, 49 %) | 3,0 s | 0,6 s |
| Droite (rouge vers jaune) | (54 %, 8 %) | (74 %, 68,5 %) | (84,5 %, 49 %) | 3,4 s | 0,6 s |
| Bas (bleu vers jaune) | (31,5 %, 79,5 %) | (68,5 %, 79,5 %) | (50 %, 96,5 %) | 3,8 s | 0,6 s |

Les arcs gauche et droit s'écartent vers l'extérieur du triangle (leur point le plus éloigné est à x = 25,8 % et x = 74,6 %) ; l'arc du bas descend jusqu'à y = 88 %.

**Paramètres modifiables.** Couleur #FFFFFF ; pointe : triangle de 3 % de la largeur de l'image, aux deux bouts ; les arcs restent visibles jusqu'à la fin du plan (8 s).

**Sortie attendue.** Animation de 8 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Pas de lueur ni d'ombre.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo.
