# Fiche de code : câble « nerf » du casque au satellite (Plan10)

**Ce que l'élément fait.** Un câble épais blanc-bleu, comme un nerf, part du casque du soldat et monte en courbe souple (forme de S) jusqu'au satellite en haut de l'image. Il se trace du casque vers le satellite, puis pulse lentement : une vague de lumière plus claire remonte le long du câble, en boucle.

**Entrée.** Point de départ : sommet du casque du soldat. Point d'arrivée : base du satellite.

**Paramètres modifiables**
| Paramètre | Valeur par défaut |
| --- | --- |
| Épaisseur | 1,2 % de la hauteur de l'image (environ 11 px) |
| Couleur du câble | #DCEBFF |
| Couleur de la vague | #FFFFFF, largeur 8 % de la longueur du câble |
| Courbe | spline à deux inflexions, amplitude 3 % de la largeur de l'image |
| Durée du tracé | 0,8 s |
| Période de la pulsation | 1,6 s, boucle |
| Entrée | 0,4 s |
| Sortie | maintenu jusqu'à la fin du plan (4 s) |

**Position et taille.** Départ : x = 50 %, y = 52 % de l'image (casque). Arrivée : x = 50 %, y = 16 %. Longueur totale environ 36 % de la hauteur.

**Sortie attendue.** Animation de 4 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Pas de lueur ni de halo (le recul de caméra est fait au montage).

**Style.** Aplats, aucune ombre, aucun texte, aucun logo ; mêmes couleurs que le plan.
