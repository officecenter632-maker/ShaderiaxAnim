# Fiche de code : cœurs qui montent de la foule (Plan57)

**Ce que l'élément fait.** Des cœurs rouges naissent au-dessus de la foule et montent vers la carte blanche en haut, en grossissant légèrement, avec une dérive latérale douce, puis s'effacent juste sous la carte. Ils partent en continu, par vagues, jusqu'à la fin du plan.

**Entrée.** L'image du cœur est celle générée dans `Plan57/01_groupe_foule_bras_coeur` (le cœur du groupe), copiée à tailles variées. Zone de départ en % de l'image du plan : bande y = 62 % à 66 %, x de 8 % à 92 %. Zone d'arrivée : y = 36 % (bord bas de la carte vide ; ne jamais passer dessus).

**Paramètres modifiables**
| Paramètre | Valeur |
| --- | --- |
| Nombre de cœurs | 14 à l'écran en même temps |
| Tailles | de 3,5 % à 14,4 % de la hauteur de l'image (le plus grand au centre, x de 40 % à 62 %) ; répartition : 2 grands, 4 moyens, 8 petits |
| Montée | 2,4 s, ease-out, de y = 64 % à y de 36 % à 52 % selon la taille (les grands montent le plus haut) |
| Dérive | de −2 % à +2 % de la largeur, sens alterné |
| Rotation | de −12° à +12° |
| Apparition | échelonnée de 0,12 s ; nouvelle vague toutes les 2,4 s |
| Disparition | fondu de 0,3 s à l'arrivée |
| Début du plan | 1,0 s |

**Position et taille.** Les cœurs occupent la bande x de 8 % à 92 %, y de 36 % à 66 % de l'image. Les traînées claires verticales derrière chaque cœur sont du montage.

**Entrée et sortie dans le plan.** Début à 1,0 s, en continu jusqu'à 6 s.

**Sortie attendue.** Animation de 6 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie, graine aléatoire fixe.

**Style.** Aplats, mêmes reflets que le cœur généré, aucune ombre, aucun texte, aucun logo.
