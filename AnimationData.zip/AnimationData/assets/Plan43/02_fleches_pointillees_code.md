# Fiche de code : flèches pointillées à deux pointes (Plan43)

Complète la variante D de `Plan22/02_trace_fleche_courbe_code.md` : mêmes paramètres communs, mais le trait est **en pointillé** et chaque flèche a une pointe à **chaque bout**.

**Ce que l'élément fait.** Trois flèches droites relient les trois cadres deux à deux, en triangle. Chacune se trace du centre vers les deux bouts, puis les deux pointes apparaissent. Un « ? » blanc (texte de montage) apparaît au milieu de chaque flèche.

**Flèches (en % de l'image du plan, mesurées sur l'image)**
| Flèche | Départ | Arrivée | Courbure | Début | Tracé |
| --- | --- | --- | --- | --- | --- |
| Haut gauche (cadre gauche vers cadre du haut) | (28,3 %, 28,9 %) | (40,5 %, 15,9 %) | aucune (droite) | 1,5 s | 0,5 s |
| Haut droite (cadre du haut vers cadre droit) | (59,3 %, 15,9 %) | (72,1 %, 28,9 %) | aucune (droite) | 2,0 s | 0,5 s |
| Bas (cadre gauche vers cadre droit) | (33,7 %, 42,8 %) | (66,3 %, 42,8 %) | aucune (droite) | 2,5 s | 0,5 s |

**Paramètres modifiables.** Couleur #FFFFFF ; épaisseur 0,8 % de la hauteur de l'image ; pointillé : segments de 1,6 % de la largeur, espaces de 1 % ; pointe : triangle de 2,5 % de la largeur aux deux bouts ; les flèches restent visibles jusqu'à la fin du plan (5 s). Positions des « ? » (texte de montage) : (30,4 %, 19,6 %), (69,5 %, 19,6 %), (50 %, 39,4 %).

**Sortie attendue.** Animation de 5 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie. Pas de lueur ni d'ombre.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo.
