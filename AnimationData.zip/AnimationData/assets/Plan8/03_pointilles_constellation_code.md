# Fiche de code : liaisons pointillées de la constellation (Plan8, repris au Plan54)

**Ce que l'élément fait.** Des lignes pointillées gris-bleu relient chaque satellite de la constellation à l'Ukraine : elles se tracent depuis le pays vers chaque satellite, puis les pointillés avancent lentement vers le haut (effet de flux de données). Les pointillés sont fins et pâles.

**Entrée.** Positions du centre de chaque satellite et du point d'accroche sur la carte, en % de l'image du plan.

**Paramètres modifiables**
| Paramètre | Plan8 | Plan54 |
| --- | --- | --- |
| Nombre de liaisons | 10 | 1 |
| Style | pointillé (6 px trait, 8 px vide) | **trait plein** (fil de 3 px) |
| Couleur | #9AA7B8 | #5B6B80 |
| Durée du tracé | 1,2 s, décalage de 0,1 s entre liaisons | 0,8 s |
| Vitesse des pointillés | 30 px/s vers le satellite | sans objet (trait plein) |
| Point d'accroche | sommet de la carte, x répartis de 38 % à 62 % de la largeur, y = 62 % | sommet de la carte, x = 50 %, y = 62 % |

**Position et taille.** Les satellites sont répartis en arc, x de 24 % à 77 %, y de 12 % à 32 % de la hauteur (deux rangées de 5, Plan8) ; les liaisons descendent jusqu'au pays (y ≈ 60 %).

**Entrée et sortie dans le plan.** Plan8 : apparition à 2,5 s, visibles jusqu'à 7 s. (Le Plan54 réutilise la même fiche avec « trait plein ».)

**Sortie attendue.** Animation sur fond transparent, 7 s, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie.

**Style.** Aplats, traits fins, aucune ombre, aucun texte, aucun logo.
