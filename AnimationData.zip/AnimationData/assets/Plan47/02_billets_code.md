# Fiche de code : billets qui tombent (Plan47)

**Ce que l'élément fait.** Du panneau vide en haut de la pile de caisses, des billets verts tombent en tournoyant vers la pile, en continu jusqu'à la fin du plan.

**Entrée.** Zone de chute en % de l'image du plan : départ sous le panneau (centre (70 %, 26 %), 8 % de large) ; arrivée sur la pile (centre (70 %, 70 %)).

**Paramètres**
| Paramètre | Valeur |
| --- | --- |
| Nombre de billets | 12 à l'écran en même temps |
| Forme | rectangle arrondi vert #39B54A de 3,8 % de la largeur sur 5 % de la hauteur, anneau intérieur #7FD98B, sans texte |
| Départ | x de 65 % à 76 %, y = 26 %, apparition échelonnée de 0,15 s |
| Chute | 1,2 s, accélération (ease-in), dérive horizontale de −6 % à +14 % de la largeur |
| Rotation | de ±20° au départ à ±70° à l'arrivée, sens aléatoire par billet |
| Arrivée | s'arrête à y de 70 % à 88 % (sur et devant la pile) puis disparaît en 0,2 s ; un nouveau billet repart |
| Début du plan | 0,8 s |

**Sortie attendue.** Animation de 6 s sur fond transparent, 30 images par seconde, 1672 × 941 px, SVG animé ou Lottie, graine aléatoire fixe. Pas d'ombre ni de lueur.

**Style.** Aplats, aucune ombre, aucun texte, aucun logo.
