# Fiche de code : pixellisation progressive de l'écran central (Plan2)

**Ce que l'élément fait.** La carte du drone sur l'écran central de l'opérateur se dégrade : l'image nette se découpe en gros carrés de couleur moyenne, d'abord fins, puis de plus en plus gros. Le drone posé sur la carte se pixellise avec elle. La ligne de front en pointillés rouges devient à peine lisible. Effet de mauvaise connexion, sans mouvement de la carte.

**Entrée.** Image de la carte (`Plan1/03_carte_ecran_central`) avec le drone par-dessus (`Plan25/01_groupe_contrat_drone_dessus`, vue de dessus, réduit), composés en une seule image.

**Paramètres modifiables**
| Paramètre | Valeur par défaut |
| --- | --- |
| Durée de la dégradation | 1,2 s |
| Taille de bloc de départ | 2 px |
| Taille de bloc d'arrivée | 28 px (sur une image de 560 px de large) |
| Courbe | ease-in (lente au début, rapide à la fin) |
| Instabilité | 3 images « sautées » : bloc recalculé avec un décalage de 1 bloc, pour un effet de saccade |
| Début dans le plan | 0,3 s |
| Maintien de l'état final | jusqu'à la fin du plan (3 s) |

**Position et taille.** Centre de l'écran central : x = 50 % de la largeur, y = 27 % de la hauteur ; largeur 33 %, hauteur 24 % de l'image du plan, aux coins droits.

**Entrée et sortie dans le plan.** Entrée à 0,3 s (début de la dégradation, l'image est encore nette), fin de la dégradation à 1,5 s, état pixellisé maintenu jusqu'à 3 s.

**Sortie attendue.** Animation de 3 s, 30 images par seconde, fond opaque (c'est l'écran lui-même), 560 × 400 px, en SVG ou canvas JavaScript ou shader du logiciel de montage ; exportable en suite d'images PNG ou en WebM.

**Style.** Aplats et couleurs de l'image d'entrée, aucune couleur ajoutée, aucun texte, aucun logo. Le halo rouge et les barres de signal sont faits au montage, pas ici.
